from __future__ import annotations

import json
from typing import Any, Dict, List

from .config import OPENAI_MODEL
from .dev_agent_tools import apply_patch, read_file, search_project
from .openai_service import extract_response_text, openai_chat

TOOLS = {
    "read_file": read_file,
    "search_project": search_project,
    "apply_patch": apply_patch,
}

MAX_AGENT_STEPS = 5

AGENT_SYSTEM_INSTRUCTION = """
You are Nova's coding agent.

You may either:
1. answer normally
2. call exactly one tool by responding with JSON only

Tool call format:
{
  "tool": "read_file",
  "args": {
    "path": "backend/main.py"
  }
}

Available tools:
- read_file(path)
- search_project(term)
- apply_patch(path, new_content)

Rules:
- If codebase context is needed, use search_project first.
- If exact file contents are needed, use read_file.
- Only use apply_patch when you already know the full corrected file content.
- If no tool is needed, answer normally.
- Do not wrap JSON in markdown fences.
""".strip()


def build_model_call_from_openai(
    system_prompt: str,
    messages: List[Dict[str, Any]],
    attachment_context: str = "",
) -> List[Dict[str, str]]:
    final_system_prompt = (system_prompt or "").strip()

    if attachment_context:
        final_system_prompt = f"{final_system_prompt}\n\nATTACHMENT CONTEXT:\n{attachment_context}".strip()

    payload: List[Dict[str, str]] = []

    if final_system_prompt:
        payload.append(
            {
                "role": "system",
                "content": final_system_prompt,
            }
        )

    for message in messages or []:
        role = str(message.get("role", "user"))
        content = str(message.get("content", ""))

        if not content.strip():
            continue

        if role not in {"system", "user", "assistant", "tool"}:
            role = "user"

        payload.append(
            {
                "role": role,
                "content": content,
            }
        )

    return payload


def _parse_tool_call(text: str) -> Dict[str, Any] | None:
    text = (text or "").strip()

    if not text:
        return None

    try:
        data = json.loads(text)
    except Exception:
        return None

    if not isinstance(data, dict):
        return None

    tool_name = data.get("tool")
    args = data.get("args", {})

    if not isinstance(tool_name, str) or not tool_name.strip():
        return None

    if not isinstance(args, dict):
        return None

    return {
        "tool": tool_name.strip(),
        "args": args,
    }


def run_agent_loop(
    system_prompt: str,
    messages: List[Dict[str, Any]],
    model: str | None = None,
    max_steps: int = MAX_AGENT_STEPS,
) -> str:
    history = list(messages or [])
    active_model = model or OPENAI_MODEL
    combined_system_prompt = f"{system_prompt}\n\n{AGENT_SYSTEM_INSTRUCTION}".strip()

    for _step in range(max_steps):
        response = openai_chat(
            model=active_model,
            messages=build_model_call_from_openai(
                system_prompt=combined_system_prompt,
                messages=history,
            ),
        )

        text = extract_response_text(response).strip()

        tool_call = _parse_tool_call(text)

        if not tool_call:
            return text

        tool_name = tool_call["tool"]
        args = tool_call["args"]

        if tool_name not in TOOLS:
            return f"Nova tool error: unknown tool '{tool_name}'"

        tool_fn = TOOLS[tool_name]

        try:
            result = tool_fn(**args)
        except Exception as exc:
            result = f"Tool error from {tool_name}: {exc}"

        history.append(
            {
                "role": "assistant",
                "content": text,
            }
        )
        history.append(
            {
                "role": "tool",
                "content": str(result),
            }
        )

    return "Nova agent stopped after max steps."