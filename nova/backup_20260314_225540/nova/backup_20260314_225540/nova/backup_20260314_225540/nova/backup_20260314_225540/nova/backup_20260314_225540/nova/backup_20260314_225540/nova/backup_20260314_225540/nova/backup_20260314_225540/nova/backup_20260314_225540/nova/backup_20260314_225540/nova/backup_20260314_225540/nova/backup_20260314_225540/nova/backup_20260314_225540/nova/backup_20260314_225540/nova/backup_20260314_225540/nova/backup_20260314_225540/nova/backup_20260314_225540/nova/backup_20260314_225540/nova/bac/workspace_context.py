from typing import List
import os

PROJECT_ROOT = r"C:\Users\Owner\nova"

MAX_FILE_MATCHES = 6
MAX_SNIPPET_LINES = 40


def _is_text_file(path: str) -> bool:
    return any(
        path.endswith(ext)
        for ext in (
            ".py",
            ".js",
            ".css",
            ".html",
            ".json",
            ".txt",
            ".md",
            ".yml",
            ".yaml",
        )
    )


def _safe_read(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception:
        return ""


def _normalize_search_terms(search_terms) -> List[str]:
    if search_terms is None:
        return []

    if isinstance(search_terms, str):
        value = search_terms.strip()
        return [value] if value else []

    if not isinstance(search_terms, (list, tuple, set)):
        return []

    normalized: List[str] = []

    for item in search_terms:
        if item is None:
            continue

        value = str(item).strip()
        if not value:
            continue

        normalized.append(value)

    return normalized


def _score_file(content: str, terms: List[str]) -> int:
    score = 0
    lower = content.lower()

    for term in terms:
        score += lower.count(term.lower())

    return score


def _extract_snippet(content: str, terms: List[str]) -> str:
    lines = content.splitlines()

    if not terms:
        return "\n".join(lines[:MAX_SNIPPET_LINES])

    for i, line in enumerate(lines):
        for term in terms:
            if term.lower() in line.lower():
                start = max(i - 5, 0)
                end = min(i + 10, len(lines))
                snippet = lines[start:end]
                return "\n".join(snippet[:MAX_SNIPPET_LINES])

    return "\n".join(lines[:MAX_SNIPPET_LINES])


def build_workspace_context(search_terms) -> str:
    terms = _normalize_search_terms(search_terms)

    if not terms:
        return ""

    candidates = []

    for root, dirs, files in os.walk(PROJECT_ROOT):
        if "runtime" in root:
            continue

        for name in files:
            path = os.path.join(root, name)

            if not _is_text_file(path):
                continue

            content = _safe_read(path)

            if not content:
                continue

            score = _score_file(content, terms)

            if score <= 0:
                continue

            candidates.append((score, path, content))

    candidates.sort(reverse=True, key=lambda x: x[0])

    top = candidates[:MAX_FILE_MATCHES]

    blocks = []

    for score, path, content in top:
        snippet = _extract_snippet(content, terms)

        block = f"""
FILE: {path}
MATCH SCORE: {score}

{snippet}
"""
        blocks.append(block.strip())

    return "\n\n".join(blocks).strip()