from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

PROJECT_ROOT = Path(__file__).resolve().parent.parent

TEXT_EXTENSIONS = {
    ".py",
    ".js",
    ".ts",
    ".tsx",
    ".jsx",
    ".html",
    ".css",
    ".json",
    ".md",
    ".txt",
    ".yml",
    ".yaml",
    ".toml",
    ".ini",
    ".xml",
    ".sql",
    ".ps1",
    ".sh",
    ".bat",
    ".java",
    ".cpp",
    ".c",
    ".go",
    ".rs",
    ".php",
    ".rb",
    ".log",
}

SKIP_DIRS = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    "node_modules",
    ".mypy_cache",
    ".pytest_cache",
    ".idea",
    ".vscode",
    "dist",
    "build",
}

MAX_SCAN_FILES = 400

_cached_files: List[Path] | None = None


def _should_skip_dir(path: Path) -> bool:
    parts = {part.lower() for part in path.parts}
    return any(part in SKIP_DIRS for part in parts)


def _iter_project_files() -> List[Path]:
    global _cached_files

    if _cached_files is not None:
        return _cached_files

    files: List[Path] = []

    preferred_roots = [
        PROJECT_ROOT / "backend",
        PROJECT_ROOT / "static",
        PROJECT_ROOT / "templates",
    ]

    for root in preferred_roots:
        if not root.exists():
            continue

        for path in root.rglob("*"):
            if not path.is_file():
                continue

            if _should_skip_dir(path):
                continue

            if path.suffix.lower() not in TEXT_EXTENSIONS:
                continue

            files.append(path)

            if len(files) >= MAX_SCAN_FILES:
                _cached_files = files
                return _cached_files

    if len(files) < MAX_SCAN_FILES:
        for path in PROJECT_ROOT.rglob("*"):
            if not path.is_file():
                continue

            if _should_skip_dir(path):
                continue

            if path.suffix.lower() not in TEXT_EXTENSIONS:
                continue

            if path in files:
                continue

            files.append(path)

            if len(files) >= MAX_SCAN_FILES:
                break

    _cached_files = files
    return _cached_files


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""


def _make_snippet(content: str, term: str, radius: int = 180) -> str:
    if not content:
        return ""

    lowered_content = content.lower()
    lowered_term = term.lower()

    index = lowered_content.find(lowered_term)
    if index < 0:
        snippet = content[: radius * 2]
        return " ".join(snippet.split())

    start = max(0, index - radius)
    end = min(len(content), index + len(term) + radius)
    snippet = content[start:end]
    return " ".join(snippet.split())


def search_project(term: str, max_results: int = 5) -> List[Dict[str, Any]]:
    query = str(term or "").strip()
    if not query:
        return []

    lowered_query = query.lower()
    results: List[Dict[str, Any]] = []

    for path in _iter_project_files():
        rel_path = path.relative_to(PROJECT_ROOT).as_posix()
        rel_lower = rel_path.lower()

        score = 0
        content = ""

        if lowered_query in rel_lower:
            score += 10

        if path.name.lower() == lowered_query:
            score += 25

        if path.stem.lower() == lowered_query:
            score += 20

        if score < 10:
            content = _read_text(path)
            if not content:
                continue

            if lowered_query not in content.lower():
                continue

            score += 5
        else:
            content = _read_text(path)

        snippet = _make_snippet(content, query)

        results.append(
            {
                "file": rel_path,
                "snippet": snippet,
                "score": score,
            }
        )

    results.sort(
        key=lambda item: (
            -int(item.get("score", 0)),
            str(item.get("file", "")).lower(),
        )
    )
    return results[:max_results]


def clear_project_search_cache() -> None:
    global _cached_files
    _cached_files = None