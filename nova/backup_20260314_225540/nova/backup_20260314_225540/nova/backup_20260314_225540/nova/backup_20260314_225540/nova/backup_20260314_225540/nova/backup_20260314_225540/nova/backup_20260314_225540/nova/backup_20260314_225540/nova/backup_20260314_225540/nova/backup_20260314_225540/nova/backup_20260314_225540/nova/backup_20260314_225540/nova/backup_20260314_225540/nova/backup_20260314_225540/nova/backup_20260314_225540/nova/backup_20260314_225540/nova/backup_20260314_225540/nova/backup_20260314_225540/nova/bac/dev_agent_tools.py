import os
import difflib

PROJECT_ROOT = r"C:\Users\Owner\nova"


def _safe_path(path: str):

    full = os.path.abspath(os.path.join(PROJECT_ROOT, path))

    if not full.startswith(PROJECT_ROOT):
        raise Exception("Invalid path outside project")

    return full


def read_file(path: str):

    full = _safe_path(path)

    try:
        with open(full, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as e:
        return f"ERROR reading file: {e}"


def search_project(term: str):

    results = []

    for root, dirs, files in os.walk(PROJECT_ROOT):

        if "runtime" in root:
            continue

        for name in files:

            if not name.endswith((".py", ".js", ".css", ".html", ".json", ".txt", ".md")):
                continue

            path = os.path.join(root, name)

            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()

                if term.lower() in content.lower():

                    snippet = content[:600]

                    results.append(f"{path}\n\n{snippet}")

            except Exception:
                pass

    return "\n\n---\n\n".join(results[:5])


def apply_patch(path: str, new_content: str):

    full = _safe_path(path)

    if not os.path.exists(full):
        return "File not found"

    try:

        with open(full, "r", encoding="utf-8", errors="ignore") as f:
            old = f.read()

        diff = difflib.unified_diff(
            old.splitlines(),
            new_content.splitlines(),
            fromfile="old",
            tofile="new",
            lineterm=""
        )

        diff_text = "\n".join(diff)

        with open(full, "w", encoding="utf-8") as f:
            f.write(new_content)

        return f"PATCH APPLIED\n\n{diff_text}"

    except Exception as e:
        return f"ERROR applying patch: {e}"