from __future__ import annotations

import traceback

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

from .brain import process_chat_turn
from .chat_store import (
    append_message,
    clear_chat_messages,
    create_chat,
    delete_chat,
    get_chat,
    list_chats,
)

router = APIRouter()


@router.get("/api/chats")
async def api_list_chats():
    chats = list_chats()

    summaries = []
    for chat in chats:
        summaries.append(
            {
                "id": chat.get("id"),
                "title": chat.get("title"),
                "created_at": chat.get("created_at"),
                "updated_at": chat.get("updated_at"),
                "message_count": len(chat.get("messages", [])),
            }
        )

    return {
        "ok": True,
        "chats": summaries,
    }


@router.post("/api/chats")
async def api_create_chat(request: Request):
    data = (
        await request.json()
        if request.headers.get("content-type", "").startswith("application/json")
        else {}
    )

    title = str((data or {}).get("title") or "New Chat").strip()
    chat = create_chat(title)

    return {
        "ok": True,
        "chat": chat,
    }


@router.get("/api/chats/{chat_id}")
async def api_get_chat(chat_id: str):
    chat = get_chat(chat_id)

    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")

    return {
        "ok": True,
        "chat": chat,
    }


@router.delete("/api/chats/{chat_id}")
async def api_delete_chat(chat_id: str):
    deleted = delete_chat(chat_id)

    if not deleted:
        raise HTTPException(status_code=404, detail="Chat not found")

    return {
        "ok": True,
    }


@router.post("/api/chats/{chat_id}/clear")
async def api_clear_chat(chat_id: str):
    chat = get_chat(chat_id)

    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")

    clear_chat_messages(chat_id)
    refreshed_chat = get_chat(chat_id)

    return {
        "ok": True,
        "chat": refreshed_chat,
    }


@router.get("/api/memory")
async def api_memory():
    return {
        "ok": True,
        "memory_items": [],
    }


@router.post("/api/chat")
async def api_chat(request: Request):
    try:
        data = await request.json()
    except Exception:
        return JSONResponse(
            status_code=400,
            content={
                "ok": False,
                "error": "Invalid JSON payload.",
            },
        )

    try:
        chat_id = str(data.get("chat_id") or "").strip()
        message = str(data.get("message") or "").strip()
        model = str(data.get("model") or "").strip()
        attachments = data.get("attachments") or []

        if model == "gpt-5.3":
            model = ""

        has_attachments = isinstance(attachments, list) and len(attachments) > 0

        if not message and not has_attachments:
            return JSONResponse(
                status_code=400,
                content={
                    "ok": False,
                    "error": "Message cannot be empty.",
                },
            )

        chat = get_chat(chat_id)

        if not chat:
            chat = create_chat("New Chat")
            chat_id = str(chat.get("id") or "").strip()

        chat = get_chat(chat_id) or chat
        existing_history = list(chat.get("messages", [])) if isinstance(chat, dict) else []

        user_content = message if message else "[Attachment]"

        append_message(chat_id, "user", user_content)

        result = process_chat_turn(
            user_text=user_content,
            history=existing_history,
            model=model,
        )

        if isinstance(result, dict):
            assistant_text = str(result.get("reply") or "").strip() or "No response returned."
        else:
            assistant_text = str(result or "").strip() or "No response returned."

        append_message(chat_id, "assistant", assistant_text)

        refreshed_chat = get_chat(chat_id) or {
            "id": chat_id,
            "title": "New Chat",
            "messages": [
                {"role": "user", "content": user_content},
                {"role": "assistant", "content": assistant_text},
            ],
        }

        return {
            "ok": True,
            "chat_id": chat_id,
            "assistant": {
                "role": "assistant",
                "content": assistant_text,
            },
            "chat": refreshed_chat,
            "messages": refreshed_chat.get("messages", []),
            "memory_items": [],
        }

    except Exception as exc:
        return JSONResponse(
            status_code=500,
            content={
                "ok": False,
                "error": f"{type(exc).__name__}: {exc}",
                "trace": traceback.format_exc(),
            },
        )