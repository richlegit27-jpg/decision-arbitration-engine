from typing import Optional


FAST_PATTERNS = {
    "hi": "Hello. What do you want to build today?",
    "hello": "Hello. What are we working on?",
    "thanks": "You're welcome.",
}


def try_fast_reply(user_text: str) -> Optional[str]:

    text = user_text.lower().strip()

    for k, v in FAST_PATTERNS.items():

        if text == k:
            return v

    return None