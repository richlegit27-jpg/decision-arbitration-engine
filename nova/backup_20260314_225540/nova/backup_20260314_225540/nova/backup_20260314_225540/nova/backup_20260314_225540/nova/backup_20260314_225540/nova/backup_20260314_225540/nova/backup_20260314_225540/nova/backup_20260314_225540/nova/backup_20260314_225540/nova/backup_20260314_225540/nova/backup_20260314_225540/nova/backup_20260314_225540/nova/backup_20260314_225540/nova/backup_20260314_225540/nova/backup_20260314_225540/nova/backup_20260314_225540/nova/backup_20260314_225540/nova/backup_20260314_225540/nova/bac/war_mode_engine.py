from typing import List, Dict

from .openai_service import openai_chat, extract_response_text
from .config import OPENAI_MODEL


WAR_PROMPT = """
You are Nova operating in WAR MODE.

Your job is to help the user win in competitive technology development.

Focus on:
- strategic advantage
- faster iteration
- system upgrades
- identifying weaknesses
- outperforming competing AI tools

Always provide:
1. strategic insight
2. upgrade opportunities
3. practical implementation suggestions
"""


def run_war_mode(messages: List[Dict]):

    response = openai_chat(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": WAR_PROMPT},
            *messages
        ]
    )

    return extract_response_text(response)