from typing import Dict, List

from .brain_memory_bridge import inject_memory, update_after_response
from .task_bridge import inject_tasks
from .improvement_bridge import inject_adaptive_prompt, record_after_response
from .brain_agent_bridge import run_agent


def build_system_prompt(base_prompt: str, user_text: str):

    prompt = base_prompt

    prompt = inject_memory(prompt, user_text)
    prompt = inject_tasks(prompt)
    prompt = inject_adaptive_prompt(prompt)

    return prompt


def run_nova_core(system_prompt: str, messages: List[Dict], user_text: str):

    final_prompt = build_system_prompt(system_prompt, user_text)

    result = run_agent(final_prompt, messages)

    return result


def finalize_turn(user_text: str, assistant_text: str):

    update_after_response(user_text, assistant_text)

    record_after_response(user_text, assistant_text)