from __future__ import annotations

import re
from typing import Any, Dict, List, Optional


FILE_PATH_PATTERN = re.compile(
    r"(?:[A-Za-z]:[\\/][^\n\r\t\"']+|[A-Za-z0-9_\-./]+?\.(?:py|js|ts|tsx|jsx|html|css|json|md|txt|yml|yaml|toml|ini|xml|sql|ps1|sh|bat|java|cpp|c|go|rs|php|rb|log))",
    flags=re.IGNORECASE,
)


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _unique_keep_order(values: List[str], limit: int) -> List[str]:
    seen = set()
    result: List[str] = []

    for value in values:
        clean = _clean_text(value)
        lowered = clean.lower()
        if not clean or lowered in seen:
            continue
        seen.add(lowered)
        result.append(clean)
        if len(result) >= limit:
            break

    return result


def _extract_file_paths(*chunks: Optional[str], limit: int = 8) -> List[str]:
    found: List[str] = []

    for chunk in chunks:
        text = _clean_text(chunk)
        if not text:
            continue
        for match in FILE_PATH_PATTERN.findall(text):
            found.append(_clean_text(match))

    return _unique_keep_order(found, limit=limit)


def _infer_likely_cause(user_text: str, route: Optional[Dict[str, Any]], project_search_text: str, reply: str) -> str:
    lowered = _clean_text(user_text).lower()

    if "login" in lowered and any(token in lowered for token in ["bug", "fix", "broken", "auth", "session"]):
        return "Auth flow, session handling, or login route mismatch is the most likely cause."

    if "memory" in lowered and "panel" in lowered:
        return "Panel state, close button binding, or DOM selector mismatch is the most likely cause."

    if any(token in lowered for token in ["attachment", "upload", "file send"]):
        return "Attachment state sync, upload endpoint handling, or missing UI binding is the most likely cause."

    if "sidebar" in lowered:
        return "Sidebar toggle state or missing event wiring is the most likely cause."

    if "send" in lowered and "chat" in lowered:
        return "Composer submit flow or backend chat endpoint wiring is the most likely cause."

    if project_search_text:
        return "The issue is most likely in the files surfaced by project search."

    if reply.lower().startswith("nova ai error:"):
        return "The backend model call or context assembly failed before a clean answer was generated."

    return "The most likely cause is in the primary files and handlers related to the request."


def _infer_next_action(user_text: str, route: Optional[Dict[str, Any]], project_search_text: str, reply: str) -> str:
    lowered = _clean_text(user_text).lower()

    if any(token in lowered for token in ["fix", "debug", "broken", "bug", "error", "fails", "failing"]):
        return "Inspect the top suggested files first, confirm the event or route path, then patch the failing handler."

    if route and route.get("use_project_search"):
        return "Open the suggested files and trace the request flow from UI trigger to backend handler."

    if route and route.get("use_web_search"):
        return "Use the fresh docs result to verify the current API contract before changing code."

    if route and route.get("use_uploaded_files"):
        return "Read the uploaded file context first and patch only the referenced code path."

    if reply:
        return "Use the returned answer as the primary direction and verify the first suggested file."

    return "Trace the relevant code path and patch the first high-probability target."


def _infer_command(user_text: str, suggested_files: List[str]) -> str:
    lowered = _clean_text(user_text).lower()

    if any(token in lowered for token in ["fix", "debug", "bug", "broken", "error", "fails"]):
        return "python -m uvicorn backend.main:app --reload --port 8000"

    if suggested_files:
        first_file = suggested_files[0]
        return f"notepad {first_file}"

    return "python -m uvicorn backend.main:app --reload --port 8000"


def build_answer_actions(
    *,
    user_text: str,
    reply: str,
    route: Optional[Dict[str, Any]] = None,
    project_search_text: Optional[str] = None,
    uploaded_file_text: Optional[str] = None,
    web_search_text: Optional[str] = None,
) -> Dict[str, Any]:
    clean_reply = _clean_text(reply)
    clean_project = _clean_text(project_search_text)
    clean_uploaded = _clean_text(uploaded_file_text)
    clean_web = _clean_text(web_search_text)

    suggested_files = _extract_file_paths(clean_project, clean_uploaded, clean_reply, limit=8)

    primary_source = "chat"
    if route:
        if route.get("use_uploaded_files"):
            primary_source = "uploaded_files"
        elif route.get("use_project_search"):
            primary_source = "project_search"
        elif route.get("use_web_search"):
            primary_source = "web_search"

    patch_target = suggested_files[0] if suggested_files else ""
    likely_cause = _infer_likely_cause(user_text, route, clean_project, clean_reply)
    next_action = _infer_next_action(user_text, route, clean_project, clean_reply)
    command = _infer_command(user_text, suggested_files)

    return {
        "primary_source": primary_source,
        "likely_cause": likely_cause,
        "next_action": next_action,
        "suggested_files": suggested_files,
        "patch_target": patch_target or None,
        "command": command,
    }