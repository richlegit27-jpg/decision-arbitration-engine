from __future__ import annotations

import mimetypes
import os
import shutil
from pathlib import Path
from typing import List

from fastapi import APIRouter, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse

from .config import RUNTIME_UPLOADS_DIR

router = APIRouter()

UPLOAD_DIR = Path(RUNTIME_UPLOADS_DIR)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

DEV_AUTH_BYPASS = os.getenv("NOVA_DEV_AUTH_BYPASS", "1").strip().lower() in {
    "1",
    "true",
    "yes",
    "on",
}

TEXT_EXTENSIONS = {
    ".py",
    ".js",
    ".ts",
    ".tsx",
    ".jsx",
    ".html",
    ".css",
    ".json",
    ".md",
    ".txt",
    ".yml",
    ".yaml",
    ".toml",
    ".ini",
    ".xml",
    ".sql",
    ".ps1",
    ".sh",
    ".bat",
}


def require_auth(request: Request) -> dict:
    if DEV_AUTH_BYPASS:
        return {
            "id": "local-dev",
            "email": "local@nova.dev",
            "name": "Local Dev",
        }

    user = request.session.get("user")
    if not user:
        raise HTTPException(status_code=401, detail="Authentication required")
    return user


def _safe_name(name: str) -> str:
    cleaned = os.path.basename(str(name or "").strip())
    cleaned = cleaned.replace("\x00", "")
    return cleaned or "upload.bin"


def _is_text_file(path: Path) -> bool:
    return path.suffix.lower() in TEXT_EXTENSIONS


def _trim_content(content: str, max_chars: int = 12000) -> str:
    text = str(content or "")
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + "\n\n... [truncated]"


def _read_text_file(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        try:
            return path.read_text(encoding="utf-8-sig")
        except Exception:
            return None
    except Exception:
        return None


def _guess_content_type(path: Path) -> str:
    guessed, _ = mimetypes.guess_type(str(path))
    return guessed or "application/octet-stream"


def _file_record(path: Path) -> dict:
    stat = path.stat()
    return {
        "name": path.name,
        "path": str(path),
        "size": stat.st_size,
        "modified_at": stat.st_mtime,
        "content_type": _guess_content_type(path),
        "is_text": _is_text_file(path),
    }


def _resolve_file(filename: str) -> Path:
    safe_filename = _safe_name(filename)
    target = UPLOAD_DIR / safe_filename

    if not target.exists() or not target.is_file():
        raise HTTPException(status_code=404, detail="File not found.")

    return target


# ---------------------------
# LIST FILES
# supports:
#   GET /files
#   GET /api/files
# ---------------------------

@router.get("/files")
@router.get("/api/files")
async def api_list_files(request: Request):
    require_auth(request)

    files: List[dict] = []
    for path in sorted(
        UPLOAD_DIR.iterdir(),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    ):
        if path.is_file():
            files.append(_file_record(path))

    return {
        "ok": True,
        "files": files,
        "count": len(files),
    }


# ---------------------------
# GET FILE DETAILS / TEXT CONTENT
# supports:
#   GET /files/{filename}
#   GET /api/files/{filename}
# ---------------------------

@router.get("/files/{filename}")
@router.get("/api/files/{filename}")
async def api_get_file(filename: str, request: Request):
    require_auth(request)

    try:
        target = _resolve_file(filename)
    except HTTPException:
        return JSONResponse(
            status_code=404,
            content={
                "ok": False,
                "error": "File not found.",
            },
        )

    payload = {
        "ok": True,
        "file": _file_record(target),
        "content": "",
        "truncated": False,
    }

    if _is_text_file(target):
        content = _read_text_file(target)
        if content is not None:
            trimmed = _trim_content(content, max_chars=12000)
            payload["content"] = trimmed
            payload["truncated"] = len(trimmed) < len(content)

    return payload


# ---------------------------
# DOWNLOAD / OPEN RAW FILE
# supports:
#   GET /files/{filename}/download
#   GET /api/files/{filename}/download
# ---------------------------

@router.get("/files/{filename}/download")
@router.get("/api/files/{filename}/download")
async def api_download_file(filename: str, request: Request):
    require_auth(request)

    try:
        target = _resolve_file(filename)
    except HTTPException:
        return JSONResponse(
            status_code=404,
            content={
                "ok": False,
                "error": "File not found.",
            },
        )

    return FileResponse(
        path=target,
        filename=target.name,
        media_type=_guess_content_type(target),
    )


# ---------------------------
# UPLOAD FILE
# supports:
#   POST /files
#   POST /api/files
# ---------------------------

@router.post("/files")
@router.post("/api/files")
async def api_upload_file(request: Request, file: UploadFile = File(...)):
    require_auth(request)

    if file is None:
        return JSONResponse(
            status_code=400,
            content={
                "ok": False,
                "error": "No file uploaded.",
            },
        )

    original_name = _safe_name(file.filename or "upload.bin")
    target = UPLOAD_DIR / original_name

    base = target.stem
    suffix = target.suffix
    index = 1

    while target.exists():
        target = UPLOAD_DIR / f"{base}_{index}{suffix}"
        index += 1

    try:
        with target.open("wb") as f:
            shutil.copyfileobj(file.file, f)
    except Exception as exc:
        return JSONResponse(
            status_code=500,
            content={
                "ok": False,
                "error": f"Upload failed: {exc}",
            },
        )
    finally:
        await file.close()

    return {
        "ok": True,
        "file": _file_record(target),
    }


# ---------------------------
# DELETE FILE
# supports:
#   DELETE /files/{filename}
#   DELETE /api/files/{filename}
# ---------------------------

@router.delete("/files/{filename}")
@router.delete("/api/files/{filename}")
async def api_delete_file(filename: str, request: Request):
    require_auth(request)

    try:
        target = _resolve_file(filename)
    except HTTPException:
        return JSONResponse(
            status_code=404,
            content={
                "ok": False,
                "error": "File not found.",
            },
        )

    try:
        target.unlink()
    except Exception as exc:
        return JSONResponse(
            status_code=500,
            content={
                "ok": False,
                "error": f"Delete failed: {exc}",
            },
        )

    return {
        "ok": True,
        "deleted": target.name,
    }