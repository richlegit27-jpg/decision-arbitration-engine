import os
import hashlib
import secrets
from datetime import datetime, timedelta

USERS = {
    "owner": {
        "password": hashlib.sha256("nova".encode()).hexdigest()
    }
}

SESSIONS = {}

SESSION_DURATION_HOURS = 12


def _hash(password: str):
    return hashlib.sha256(password.encode()).hexdigest()


def authenticate(username: str, password: str):

    user = USERS.get(username)

    if not user:
        return None

    if user["password"] != _hash(password):
        return None

    token = secrets.token_hex(32)

    expires = datetime.utcnow() + timedelta(hours=SESSION_DURATION_HOURS)

    SESSIONS[token] = {
        "username": username,
        "expires": expires
    }

    return token


def get_session(token: str):

    if token not in SESSIONS:
        return None

    session = SESSIONS[token]

    if datetime.utcnow() > session["expires"]:
        del SESSIONS[token]
        return None

    return session


def destroy_session(token: str):

    if token in SESSIONS:
        del SESSIONS[token]