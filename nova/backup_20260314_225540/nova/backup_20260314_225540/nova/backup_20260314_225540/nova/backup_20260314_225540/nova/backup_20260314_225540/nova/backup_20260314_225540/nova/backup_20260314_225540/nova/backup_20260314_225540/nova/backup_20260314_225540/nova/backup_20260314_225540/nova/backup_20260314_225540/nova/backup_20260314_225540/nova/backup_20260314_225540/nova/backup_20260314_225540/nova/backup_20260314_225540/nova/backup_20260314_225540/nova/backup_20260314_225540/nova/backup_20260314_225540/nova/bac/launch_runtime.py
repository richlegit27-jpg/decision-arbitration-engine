import os

RUNTIME_ROOT = r"C:\Users\Owner\nova\runtime"

DIRECTORIES = [
    "uploads",
    "memory",
    "tasks",
    "logs",
    "backups"
]


def ensure_runtime():

    os.makedirs(RUNTIME_ROOT, exist_ok=True)

    for d in DIRECTORIES:

        os.makedirs(
            os.path.join(RUNTIME_ROOT, d),
            exist_ok=True
        )