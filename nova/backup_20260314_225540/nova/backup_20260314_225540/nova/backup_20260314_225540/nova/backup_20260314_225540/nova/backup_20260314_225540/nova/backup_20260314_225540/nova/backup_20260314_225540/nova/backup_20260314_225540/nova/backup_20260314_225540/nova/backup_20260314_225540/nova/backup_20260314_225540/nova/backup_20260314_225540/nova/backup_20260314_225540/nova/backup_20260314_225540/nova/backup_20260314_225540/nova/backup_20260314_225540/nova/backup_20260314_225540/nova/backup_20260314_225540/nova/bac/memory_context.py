from typing import List

from .memory_retrieval import retrieve_memory


def build_memory_context(user_text: str):

    memories = retrieve_memory(user_text)

    if not memories:
        return ""

    block = "RELEVANT LONG TERM MEMORY:\n\n"

    for m in memories:
        block += f"- {m}\n"

    return block