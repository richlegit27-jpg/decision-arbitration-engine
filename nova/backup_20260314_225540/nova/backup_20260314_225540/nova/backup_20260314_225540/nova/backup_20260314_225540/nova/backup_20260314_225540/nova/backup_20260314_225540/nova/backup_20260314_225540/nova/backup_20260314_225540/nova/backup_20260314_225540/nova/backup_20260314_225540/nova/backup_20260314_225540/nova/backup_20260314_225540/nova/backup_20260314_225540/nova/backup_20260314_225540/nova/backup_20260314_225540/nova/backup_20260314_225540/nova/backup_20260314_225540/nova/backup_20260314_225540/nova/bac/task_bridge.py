from .task_planner_engine import plan_goal
from .task_manager import create_task
from .task_context import build_task_context


def create_plan(goal: str):

    steps = plan_goal(goal)

    task = create_task(goal, steps)

    return task


def inject_tasks(system_prompt: str):

    context = build_task_context()

    if not context:
        return system_prompt

    return f"{system_prompt}\n\n{context}"