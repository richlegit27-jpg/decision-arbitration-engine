from .memory_context import build_memory_context
from .memory_writer import update_memory


def inject_memory(system_prompt: str, user_text: str):

    memory = build_memory_context(user_text)

    if not memory:
        return system_prompt

    return f"{system_prompt}\n\n{memory}"


def update_after_response(user_text: str, assistant_text: str):

    update_memory(user_text, assistant_text)