from typing import List, Dict

FAST_MODEL = "gpt-4o-mini"
REASONING_MODEL = "gpt-4o"
CODE_MODEL = "gpt-4o"

FAST_TASKS = [
    "greeting",
    "simple_question",
]

CODE_TASKS = [
    "code",
    "debug",
    "fix",
    "patch",
]


def classify_task(user_text: str):

    text = user_text.lower()

    for word in CODE_TASKS:
        if word in text:
            return "code"

    if len(text) < 30:
        return "fast"

    return "reasoning"


def choose_model(user_text: str):

    task = classify_task(user_text)

    if task == "fast":
        return FAST_MODEL

    if task == "code":
        return CODE_MODEL

    return REASONING_MODEL