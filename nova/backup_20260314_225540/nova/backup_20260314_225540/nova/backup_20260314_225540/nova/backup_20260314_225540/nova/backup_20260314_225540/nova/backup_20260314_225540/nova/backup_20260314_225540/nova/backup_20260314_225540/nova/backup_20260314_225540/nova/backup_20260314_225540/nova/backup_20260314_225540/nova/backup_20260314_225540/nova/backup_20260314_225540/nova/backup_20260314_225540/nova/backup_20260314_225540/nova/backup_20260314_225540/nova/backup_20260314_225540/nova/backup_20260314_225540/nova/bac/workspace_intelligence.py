import os

PROJECT_ROOT = r"C:\Users\Owner\nova"


def get_project_structure():

    tree = []

    for root, dirs, files in os.walk(PROJECT_ROOT):

        if "runtime" in root:
            continue

        level = root.replace(PROJECT_ROOT, "").count(os.sep)

        indent = "  " * level

        tree.append(f"{indent}{os.path.basename(root)}/")

        for f in files:
            tree.append(f"{indent}  {f}")

    return "\n".join(tree)