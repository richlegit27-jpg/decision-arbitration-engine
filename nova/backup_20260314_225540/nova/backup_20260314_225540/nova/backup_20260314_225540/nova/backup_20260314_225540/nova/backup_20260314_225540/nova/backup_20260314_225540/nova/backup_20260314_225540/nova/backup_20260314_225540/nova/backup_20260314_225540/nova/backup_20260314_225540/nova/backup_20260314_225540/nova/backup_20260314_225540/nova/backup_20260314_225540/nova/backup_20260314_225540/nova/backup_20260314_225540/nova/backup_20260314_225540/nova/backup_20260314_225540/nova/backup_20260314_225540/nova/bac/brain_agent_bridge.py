from .dev_agent_loop import run_dev_agent
from .agent_instruction import AGENT_INSTRUCTION


def run_agent(system_prompt, messages):

    final_prompt = f"{system_prompt}\n\n{AGENT_INSTRUCTION}"

    return run_dev_agent(
        system_prompt=final_prompt,
        messages=messages
    )