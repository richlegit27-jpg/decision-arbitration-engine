from .context_optimizer import optimize_context
from .fast_reply_engine import try_fast_reply


def apply_advantage_layer(messages, user_text):

    fast = try_fast_reply(user_text)

    if fast:
        return fast, messages

    optimized = optimize_context(messages)

    return None, optimized