from .task_manager import get_tasks


def build_task_context():

    tasks = get_tasks()

    if not tasks:
        return ""

    text = "ACTIVE TASKS:\n\n"

    for t in tasks:

        text += f"GOAL: {t['goal']}\n"

        for i, step in enumerate(t["steps"]):

            status = "✓" if step["done"] else "•"

            text += f"{status} {step['step']}\n"

        text += "\n"

    return text