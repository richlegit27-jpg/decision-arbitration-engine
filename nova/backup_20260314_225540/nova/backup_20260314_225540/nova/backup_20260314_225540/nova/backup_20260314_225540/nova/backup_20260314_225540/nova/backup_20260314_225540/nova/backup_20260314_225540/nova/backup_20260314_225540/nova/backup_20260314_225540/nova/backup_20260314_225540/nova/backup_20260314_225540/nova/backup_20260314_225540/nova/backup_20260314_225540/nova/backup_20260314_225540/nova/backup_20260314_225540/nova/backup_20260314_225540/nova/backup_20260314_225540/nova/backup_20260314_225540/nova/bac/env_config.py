import os

OPENAI_MODEL = os.getenv("NOVA_MODEL", "gpt-4o")
NOVA_ENV = os.getenv("NOVA_ENV", "development")

PORT = int(os.getenv("NOVA_PORT", "8000"))

DEBUG = NOVA_ENV == "development"