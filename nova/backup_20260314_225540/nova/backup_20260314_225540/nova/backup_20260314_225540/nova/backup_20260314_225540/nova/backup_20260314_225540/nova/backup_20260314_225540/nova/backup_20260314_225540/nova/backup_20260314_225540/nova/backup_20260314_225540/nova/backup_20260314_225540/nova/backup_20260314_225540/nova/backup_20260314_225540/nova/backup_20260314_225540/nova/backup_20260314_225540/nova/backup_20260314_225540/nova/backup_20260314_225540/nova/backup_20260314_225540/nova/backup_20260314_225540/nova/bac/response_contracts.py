from typing import Any, Dict, List


def _clean(value: Any) -> str:
    return str(value or "").strip()


def _clean_list(values: Any) -> List[str]:
    if not isinstance(values, list):
        return []

    results: List[str] = []
    seen = set()

    for item in values:
        text = _clean(item)
        if not text:
            continue
        key = text.lower()
        if key in seen:
            continue
        seen.add(key)
        results.append(text)

    return results


def _section(title: str, lines: List[str]) -> str:
    cleaned = [str(line).rstrip() for line in lines if _clean(line)]
    if not cleaned:
        return ""
    return f"{title}:\n" + "\n".join(cleaned)


def format_locate_code_response(locate_result: Dict[str, Any], user_message: str = "") -> str:
    if not isinstance(locate_result, dict) or locate_result.get("ok") != "true":
        return "I could not find a strong project file match for that request."

    primary = locate_result.get("primary_match") or {}
    supporting = locate_result.get("supporting_matches") or []

    primary_path = _clean(primary.get("path"))
    if not primary_path:
        return "I found some project evidence, but not a reliable primary file."

    symbols = _clean_list(primary.get("matched_symbols"))
    snippets = _clean_list(primary.get("snippets"))

    score = int(primary.get("score", 0) or 0)
    path_score = int(primary.get("path_score", 0) or 0)
    content_score = int(primary.get("content_score", 0) or 0)

    parts: List[str] = []
    parts.append(f"Primary file: {primary_path}")

    if symbols:
        parts.append("Functions/symbols involved: " + ", ".join(symbols[:8]))
    else:
        parts.append("Functions/symbols involved: no strong symbol hit, but this is still the strongest file match.")

    parts.append(
        "Why: "
        f"best overall match score={score}, "
        f"path_score={path_score}, "
        f"content_score={content_score}."
    )

    if supporting:
        support_lines: List[str] = []
        for item in supporting[:4]:
            path = _clean(item.get("path"))
            if not path:
                continue

            item_score = int(item.get("score", 0) or 0)
            item_symbols = _clean_list(item.get("matched_symbols"))
            if item_symbols:
                support_lines.append(
                    f"- {path} — score={item_score} — symbols: {', '.join(item_symbols[:6])}"
                )
            else:
                support_lines.append(f"- {path} — score={item_score}")

        block = _section("Supporting files", support_lines)
        if block:
            parts.append("")
            parts.append(block)

    if snippets:
        evidence_lines: List[str] = []
        for snippet in snippets[:2]:
            evidence_lines.append("```")
            evidence_lines.append(snippet)
            evidence_lines.append("```")

        block = _section("Evidence", evidence_lines)
        if block:
            parts.append("")
            parts.append(block)

    return "\n".join(parts).strip()


def format_explain_code_response(explanation: Dict[str, Any], user_message: str = "") -> str:
    if not isinstance(explanation, dict) or explanation.get("ok") != "true":
        return "I could not build a grounded explanation for that file."

    path = _clean(explanation.get("path"))
    content = _clean(explanation.get("content"))
    symbols = _clean_list(explanation.get("symbols"))
    snippets = _clean_list(explanation.get("snippets"))

    parts: List[str] = []
    parts.append(f"File: {path}")
    parts.append("")
    parts.append("What this file does:")
    parts.append("- This file is part of Nova's project runtime and should be interpreted from the visible code below.")
    parts.append("- The strongest grounded explanation comes from its symbols, imports, and control flow shown in the file context.")

    if content:
        import_lines: List[str] = []
        for raw_line in content.splitlines():
            line = raw_line.strip()
            if line.startswith("import ") or line.startswith("from "):
                import_lines.append(f"- {line}")
            if len(import_lines) >= 16:
                break

        block = _section("Main imports/dependencies", import_lines)
        if block:
            parts.append("")
            parts.append(block)

    if symbols:
        function_lines: List[str] = []
        for symbol in symbols[:12]:
            function_lines.append(f"- {symbol}")
        block = _section("Key functions/symbols", function_lines)
        if block:
            parts.append("")
            parts.append(block)

    parts.append("")
    parts.append("Runtime flow:")
    parts.append("- Read top to bottom: imports, helpers, orchestration, then exported/runtime entry behavior.")
    parts.append("- Use the visible symbols and snippets as the source of truth.")

    if snippets:
        snippet_lines: List[str] = []
        for snippet in snippets[:3]:
            snippet_lines.append("```")
            snippet_lines.append(snippet)
            snippet_lines.append("```")

        block = _section("Relevant snippets", snippet_lines)
        if block:
            parts.append("")
            parts.append(block)

    parts.append("")
    parts.append("Weak spots / risks:")
    parts.append("- If this file mixes helpers, orchestration, and formatting, it may be taking on too much responsibility.")
    parts.append("- Any explanation beyond the visible code should be treated as a likely inference, not certainty.")

    return "\n".join(parts).strip()


def format_debug_response(
    problem: str,
    root_cause: str,
    fix: str,
    steps: List[str] | None = None,
    commands: List[str] | None = None,
) -> str:
    parts: List[str] = []

    parts.append(_section("Problem", [f"- {problem}"]))
    parts.append(_section("Root cause", [f"- {root_cause}"]))
    parts.append(_section("Fix", [f"- {fix}"]))

    step_lines = [f"- {item}" for item in _clean_list(steps or [])]
    block = _section("Next steps", step_lines)
    if block:
        parts.append(block)

    command_list = _clean_list(commands or [])
    if command_list:
        command_lines = ["```powershell"] + command_list + ["```"]
        block = _section("PowerShell", command_lines)
        if block:
            parts.append(block)

    return "\n\n".join(part for part in parts if part).strip()


def format_build_response(
    objective: str,
    files: List[str] | None = None,
    implementation_order: List[str] | None = None,
    risks: List[str] | None = None,
    commands: List[str] | None = None,
) -> str:
    parts: List[str] = []

    parts.append(_section("Objective", [f"- {objective}"]))

    file_lines = [f"- {item}" for item in _clean_list(files or [])]
    block = _section("Files in play", file_lines)
    if block:
        parts.append(block)

    order_lines = [f"- {item}" for item in _clean_list(implementation_order or [])]
    block = _section("Implementation order", order_lines)
    if block:
        parts.append(block)

    risk_lines = [f"- {item}" for item in _clean_list(risks or [])]
    block = _section("Risks", risk_lines)
    if block:
        parts.append(block)

    command_list = _clean_list(commands or [])
    if command_list:
        command_lines = ["```powershell"] + command_list + ["```"]
        block = _section("PowerShell", command_lines)
        if block:
            parts.append(block)

    return "\n\n".join(part for part in parts if part).strip()


def format_summary_response(
    decisions: List[str] | None = None,
    progress: List[str] | None = None,
    blockers: List[str] | None = None,
    next_steps: List[str] | None = None,
) -> str:
    parts: List[str] = []

    decision_lines = [f"- {item}" for item in _clean_list(decisions or [])]
    progress_lines = [f"- {item}" for item in _clean_list(progress or [])]
    blocker_lines = [f"- {item}" for item in _clean_list(blockers or [])]
    next_lines = [f"- {item}" for item in _clean_list(next_steps or [])]

    for title, lines in [
        ("Decisions", decision_lines),
        ("Progress", progress_lines),
        ("Blockers", blocker_lines),
        ("Next steps", next_lines),
    ]:
        block = _section(title, lines)
        if block:
            parts.append(block)

    if not parts:
        return "No strong summary items were available."

    return "\n\n".join(parts).strip()