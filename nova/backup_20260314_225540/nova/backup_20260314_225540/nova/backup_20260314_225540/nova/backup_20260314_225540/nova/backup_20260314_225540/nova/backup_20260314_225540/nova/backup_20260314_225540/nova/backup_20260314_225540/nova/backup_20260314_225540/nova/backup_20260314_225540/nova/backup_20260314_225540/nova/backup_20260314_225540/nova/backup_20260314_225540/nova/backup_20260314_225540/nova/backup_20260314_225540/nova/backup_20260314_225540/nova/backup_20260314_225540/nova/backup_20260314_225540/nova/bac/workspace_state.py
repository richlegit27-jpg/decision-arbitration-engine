from __future__ import annotations

import json
import re
from typing import Any, Dict, List

from .config import WORKSPACE_STATE_FILE

MAX_RECENT_FILES = 12
MAX_RECENT_TASKS = 12


def _default_state() -> Dict[str, Any]:
    return {
        "active_project": "Nova",
        "current_subsystem": "",
        "current_task": "",
        "current_blocker": "",
        "next_step": "",
        "files_in_play": [],
        "recent_tasks": [],
        "last_user_intent": "",
        "last_mode": "",
    }


def _normalize_string_list(values: Any, limit: int) -> List[str]:
    if not isinstance(values, list):
        return []

    output: List[str] = []
    seen = set()

    for value in values:
        text = str(value or "").strip()
        if not text:
            continue

        key = text.lower()
        if key in seen:
            continue

        seen.add(key)
        output.append(text)

        if len(output) >= limit:
            break

    return output


def _prepend_unique(values: List[str], new_value: str, limit: int) -> List[str]:
    clean_new = str(new_value or "").strip()
    if not clean_new:
        return _normalize_string_list(values, limit)

    output = [clean_new]

    for item in values:
        clean_item = str(item or "").strip()
        if not clean_item:
            continue

        if clean_item.lower() == clean_new.lower():
            continue

        output.append(clean_item)

        if len(output) >= limit:
            break

    return output


def load_workspace_state() -> Dict[str, Any]:
    try:
        with open(WORKSPACE_STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, dict):
            return _default_state()

        state = _default_state()
        state.update(data)

        state["files_in_play"] = _normalize_string_list(
            state.get("files_in_play", []),
            MAX_RECENT_FILES,
        )
        state["recent_tasks"] = _normalize_string_list(
            state.get("recent_tasks", []),
            MAX_RECENT_TASKS,
        )

        if not state.get("active_project"):
            state["active_project"] = "Nova"

        return state
    except Exception:
        return _default_state()


def save_workspace_state(state: Dict[str, Any]) -> None:
    normalized = _default_state()
    normalized.update(state or {})

    normalized["files_in_play"] = _normalize_string_list(
        normalized.get("files_in_play", []),
        MAX_RECENT_FILES,
    )
    normalized["recent_tasks"] = _normalize_string_list(
        normalized.get("recent_tasks", []),
        MAX_RECENT_TASKS,
    )

    if not normalized.get("active_project"):
        normalized["active_project"] = "Nova"

    try:
        with open(WORKSPACE_STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(normalized, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


def _extract_files_from_text(text: str) -> List[str]:
    value = str(text or "")

    patterns = [
        r"[A-Za-z]:\\[^\n\r\t\"']+",
        r"(?:[A-Za-z0-9_\-\.]+\\)+[A-Za-z0-9_\-\.]+\.[A-Za-z0-9_]+",
        r"(?:[A-Za-z0-9_\-\.]+/)+[A-Za-z0-9_\-\.]+\.[A-Za-z0-9_]+",
        r"\b[A-Za-z0-9_\-]+\.(?:py|js|ts|tsx|jsx|html|css|json|md|txt|yml|yaml|xml|sql|ps1|sh|bat|java|cpp|c|go|rs|php|rb)\b",
    ]

    matches: List[str] = []
    seen = set()

    for pattern in patterns:
        for match in re.findall(pattern, value):
            cleaned = str(match).strip().strip("`")
            lowered = cleaned.lower()

            if not cleaned or lowered in seen:
                continue

            seen.add(lowered)
            matches.append(cleaned)

            if len(matches) >= MAX_RECENT_FILES:
                return matches

    return matches


def _extract_subsystem(text: str) -> str:
    value = str(text or "").lower()

    mapping = [
        ("backend", ["backend", "fastapi", "flask", "api", "server", "route", "endpoint"]),
        ("frontend", ["frontend", "ui", "css", "html", "layout", "render", "sidebar", "composer"]),
        ("memory", ["memory", "recall", "summary", "context", "history"]),
        ("attachments", ["attachment", "upload", "file preview", "preview bug", "image upload", "document upload", "files"]),
        ("streaming", ["stream", "sse", "streaming", "token stream"]),
        ("voice", ["voice", "mic", "speech", "audio", "transcript"]),
        ("images", ["image", "vision", "photo", "picture"]),
        ("chat", ["chat", "message", "conversation", "thread", "title"]),
    ]

    for subsystem, signals in mapping:
        if any(signal in value for signal in signals):
            return subsystem

    return ""


def _infer_intent(user_message: str, mode: str) -> str:
    text = str(user_message or "").lower()
    clean_mode = str(mode or "").strip().lower()

    if clean_mode == "debug" or any(word in text for word in ["fix", "debug", "broken", "error", "issue", "bug"]):
        return "fix_issue"

    if clean_mode == "build" or any(word in text for word in ["build", "make", "create", "implement", "add", "wire", "refactor"]):
        return "build_feature"

    if clean_mode == "summarize" or any(word in text for word in ["summarize", "recap", "what did we do", "tldr", "tl;dr"]):
        return "summarize_work"

    if clean_mode in {"vision", "analyze_file"}:
        return "analyze_input"

    return "general_chat"


def _extract_current_task(user_message: str, assistant_message: str, mode: str) -> str:
    user_text = str(user_message or "").strip()
    assistant_text = str(assistant_message or "").strip()
    clean_mode = str(mode or "").strip()

    if user_text:
        return re.sub(r"\s+", " ", user_text)[:220]

    if assistant_text:
        return re.sub(r"\s+", " ", assistant_text)[:220]

    return clean_mode[:220]


def _extract_blocker(user_message: str, assistant_message: str, mode: str) -> str:
    text = f"{user_message}\n{assistant_message}\n{mode}".lower()

    blocker_signals = [
        "404",
        "500",
        "not found",
        "not working",
        "broken",
        "failing",
        "error",
        "exception",
        "traceback",
        "load local resource",
        "cannot",
        "failed",
    ]

    found = [signal for signal in blocker_signals if signal in text]

    if not found:
        return ""

    return f"Active blocker signals: {', '.join(found[:4])}"


def _extract_next_step(assistant_message: str) -> str:
    text = str(assistant_message or "").strip()
    if not text:
        return ""

    lines = [line.strip("-• \t") for line in text.splitlines() if line.strip()]
    if not lines:
        return ""

    for line in lines:
        lowered = line.lower()
        if lowered.startswith(("next", "do this", "replace", "create", "edit", "update", "wire")):
            return line[:220]

    return lines[0][:220]


def update_workspace_state(
    user_message: str,
    assistant_message: str,
    attachments: List[Dict[str, Any]] | None = None,
    mode: str = "",
) -> Dict[str, Any]:
    state = load_workspace_state()

    attachment_names: List[str] = []
    for attachment in attachments or []:
        name = str(attachment.get("name") or attachment.get("filename") or "").strip()
        if name:
            attachment_names.append(name)

    intent = _infer_intent(user_message, mode)
    subsystem = _extract_subsystem(f"{user_message}\n{' '.join(attachment_names)}")
    current_task = _extract_current_task(user_message, assistant_message, mode)
    blocker = _extract_blocker(user_message, assistant_message, mode)
    next_step = _extract_next_step(assistant_message)

    file_hits = _extract_files_from_text(user_message)
    file_hits.extend(_extract_files_from_text(assistant_message))
    file_hits.extend(attachment_names)

    files_in_play = state.get("files_in_play", [])
    for file_path in file_hits:
        files_in_play = _prepend_unique(files_in_play, file_path, MAX_RECENT_FILES)

    recent_tasks = _prepend_unique(
        state.get("recent_tasks", []),
        current_task,
        MAX_RECENT_TASKS,
    )

    if subsystem:
        state["current_subsystem"] = subsystem

    state["active_project"] = state.get("active_project") or "Nova"
    state["current_task"] = current_task
    state["current_blocker"] = blocker
    state["next_step"] = next_step
    state["files_in_play"] = files_in_play
    state["recent_tasks"] = recent_tasks
    state["last_user_intent"] = intent
    state["last_mode"] = str(mode or "").strip()

    save_workspace_state(state)
    return state


def build_workspace_context() -> str:
    state = load_workspace_state()

    lines: List[str] = ["Workspace state:"]

    if state.get("active_project"):
        lines.append(f"- active_project: {state['active_project']}")

    if state.get("current_subsystem"):
        lines.append(f"- current_subsystem: {state['current_subsystem']}")

    if state.get("current_task"):
        lines.append(f"- current_task: {state['current_task']}")

    if state.get("current_blocker"):
        lines.append(f"- current_blocker: {state['current_blocker']}")

    if state.get("next_step"):
        lines.append(f"- next_step: {state['next_step']}")

    if state.get("last_user_intent"):
        lines.append(f"- last_user_intent: {state['last_user_intent']}")

    if state.get("last_mode"):
        lines.append(f"- last_mode: {state['last_mode']}")

    files_in_play = state.get("files_in_play", [])
    if files_in_play:
        lines.append("- files_in_play:")
        for item in files_in_play[:8]:
            lines.append(f"  - {item}")

    recent_tasks = state.get("recent_tasks", [])
    if recent_tasks:
        lines.append("- recent_tasks:")
        for item in recent_tasks[:6]:
            lines.append(f"  - {item}")

    return "\n".join(lines)