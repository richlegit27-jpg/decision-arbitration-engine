from typing import List, Dict

from .dev_agent_loop import run_dev_agent
from .intelligence_core import run_intelligence_step


MAX_SUPERVISOR_STEPS = 4


def run_supervised_agent(system_prompt: str, messages: List[Dict]):

    history = list(messages)

    for step in range(MAX_SUPERVISOR_STEPS):

        result = run_intelligence_step(system_prompt, history)

        if not result:
            return "No response"

        if result.startswith("{"):
            return run_dev_agent(system_prompt, history)

        history.append({
            "role": "assistant",
            "content": result
        })

        return result

    return "Supervisor stopped"