from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from .config import RUNTIME_UPLOADS_DIR


BASE_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = BASE_DIR
UPLOAD_DIR = Path(RUNTIME_UPLOADS_DIR)

LIKELY_UPLOAD_DIRS = [
    UPLOAD_DIR,
    PROJECT_ROOT / "uploads",
    PROJECT_ROOT / "data" / "uploads",
    PROJECT_ROOT / "storage" / "uploads",
    PROJECT_ROOT / "backend" / "uploads",
]

TEXT_EXTENSIONS = {
    ".txt",
    ".md",
    ".json",
    ".csv",
    ".log",
    ".py",
    ".js",
    ".ts",
    ".jsx",
    ".tsx",
    ".html",
    ".htm",
    ".css",
    ".xml",
    ".yaml",
    ".yml",
    ".ini",
    ".cfg",
    ".toml",
    ".sql",
    ".sh",
    ".ps1",
    ".bat",
}


def _first_existing_upload_dir() -> Path:
    for directory in LIKELY_UPLOAD_DIRS:
        if directory.exists() and directory.is_dir():
            return directory
    return LIKELY_UPLOAD_DIRS[0]


def _is_text_file(path: Path) -> bool:
    return path.suffix.lower() in TEXT_EXTENSIONS


def _safe_read_text(path: Path, max_chars: int = 4000) -> str:
    try:
        raw = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""

    text = raw.strip()
    if not text:
        return ""

    if len(text) > max_chars:
        return text[:max_chars].rstrip() + "\n...[truncated]"
    return text


def _normalize_filename(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/").split("/")[-1]


def _extract_candidate_names(uploaded_files: Any) -> List[str]:
    candidates: List[str] = []

    if not uploaded_files:
        return candidates

    if isinstance(uploaded_files, (str, Path)):
        name = _normalize_filename(uploaded_files)
        if name:
            candidates.append(name)
        return candidates

    if isinstance(uploaded_files, dict):
        for key in ("name", "filename", "path"):
            if key in uploaded_files:
                name = _normalize_filename(uploaded_files.get(key))
                if name:
                    candidates.append(name)
        return candidates

    if isinstance(uploaded_files, Iterable):
        for item in uploaded_files:
            if isinstance(item, (str, Path)):
                name = _normalize_filename(item)
                if name:
                    candidates.append(name)
                continue

            if isinstance(item, dict):
                for key in ("name", "filename", "path"):
                    if key in item:
                        name = _normalize_filename(item.get(key))
                        if name:
                            candidates.append(name)
                            break

    deduped: List[str] = []
    seen = set()
    for name in candidates:
        lowered = name.lower()
        if lowered in seen:
            continue
        seen.add(lowered)
        deduped.append(name)

    return deduped


def _resolve_uploaded_file(name: str) -> Optional[Path]:
    clean = _normalize_filename(name)
    if not clean:
        return None

    for upload_dir in LIKELY_UPLOAD_DIRS:
        candidate = Path(upload_dir) / clean
        if candidate.exists() and candidate.is_file():
            return candidate

    return None


def list_uploaded_files() -> List[Dict[str, Any]]:
    upload_dir = _first_existing_upload_dir()
    if not upload_dir.exists():
        return []

    items: List[Dict[str, Any]] = []

    for path in sorted(upload_dir.glob("*"), key=lambda p: p.stat().st_mtime, reverse=True):
        if not path.is_file():
            continue

        stat = path.stat()
        items.append(
            {
                "name": path.name,
                "size": stat.st_size,
                "modified_at": int(stat.st_mtime),
                "path": str(path),
                "is_text": _is_text_file(path),
            }
        )

    return items


def build_uploaded_file_context(
    uploaded_files: Any = None,
    max_files: int = 6,
    max_chars_per_file: int = 3000,
    max_total_chars: int = 12000,
) -> str:
    candidates = _extract_candidate_names(uploaded_files)

    if not candidates:
        recent = list_uploaded_files()
        candidates = [item["name"] for item in recent[:max_files]]

    if not candidates:
        return ""

    sections: List[str] = []
    total_chars = 0

    for name in candidates[:max_files]:
        resolved = _resolve_uploaded_file(name)
        if not resolved:
            sections.append(f"File: {name}\nStatus: uploaded file not found on disk")
            continue

        stat = resolved.stat()
        header = [
            f"File: {resolved.name}",
            f"Size: {stat.st_size} bytes",
            f"Modified: {int(stat.st_mtime)}",
        ]

        if not _is_text_file(resolved):
            block = "\n".join(header + ["Content: binary or unsupported preview type"])
            if total_chars + len(block) > max_total_chars:
                break
            sections.append(block)
            total_chars += len(block)
            continue

        content = _safe_read_text(resolved, max_chars=max_chars_per_file)
        if not content:
            block = "\n".join(header + ["Content: empty or unreadable"])
        else:
            block = "\n".join(header + ["Content:", content])

        if total_chars + len(block) > max_total_chars:
            remaining = max_total_chars - total_chars
            if remaining <= 0:
                break
            block = block[:remaining].rstrip() + "\n...[context truncated]"
            sections.append(block)
            total_chars = max_total_chars
            break

        sections.append(block)
        total_chars += len(block)

    if not sections:
        return ""

    return "\n\n---\n\n".join(sections)


def read_project_file(path: str, max_chars: int = 12000) -> str:
    raw_path = str(path or "").strip()
    if not raw_path:
        return ""

    candidate = Path(raw_path)
    if not candidate.is_absolute():
        candidate = PROJECT_ROOT / raw_path

    try:
        candidate = candidate.resolve()
    except Exception:
        return ""

    try:
        candidate.relative_to(PROJECT_ROOT.resolve())
    except Exception:
        return ""

    if not candidate.exists() or not candidate.is_file():
        return ""

    return _safe_read_text(candidate, max_chars=max_chars)


def search_project_content(
    query: str,
    root_dir: str | None = None,
    max_results: int = 20,
    max_file_size: int = 512_000,
) -> List[Dict[str, Any]]:
    text_query = str(query or "").strip().lower()
    if not text_query:
        return []

    search_root = Path(root_dir).resolve() if root_dir else PROJECT_ROOT.resolve()
    if not search_root.exists():
        return []

    results: List[Dict[str, Any]] = []

    skip_dirs = {
        ".git",
        "__pycache__",
        ".venv",
        "venv",
        "node_modules",
        ".mypy_cache",
        ".pytest_cache",
        "dist",
        "build",
    }

    for path in search_root.rglob("*"):
        if len(results) >= max_results:
            break

        if not path.is_file():
            continue

        if any(part in skip_dirs for part in path.parts):
            continue

        try:
            size = path.stat().st_size
        except Exception:
            continue

        if size > max_file_size:
            continue

        if not _is_text_file(path):
            continue

        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        lowered = content.lower()
        if text_query not in lowered:
            continue

        index = lowered.find(text_query)
        start = max(0, index - 160)
        end = min(len(content), index + 260)
        snippet = content[start:end].strip().replace("\r", "")

        try:
            relative_path = str(path.resolve().relative_to(PROJECT_ROOT.resolve()))
        except Exception:
            relative_path = str(path)

        results.append(
            {
                "path": relative_path,
                "snippet": snippet,
                "size": size,
            }
        )

    return results