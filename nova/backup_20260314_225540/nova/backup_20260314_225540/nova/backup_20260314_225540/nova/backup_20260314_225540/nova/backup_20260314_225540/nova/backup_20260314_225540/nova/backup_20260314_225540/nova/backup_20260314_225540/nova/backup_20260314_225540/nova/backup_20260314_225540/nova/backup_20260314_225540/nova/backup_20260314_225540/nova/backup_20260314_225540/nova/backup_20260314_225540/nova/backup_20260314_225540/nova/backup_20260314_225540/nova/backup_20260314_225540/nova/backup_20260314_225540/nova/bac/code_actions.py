import os

PROJECT_ROOT = r"C:\Users\Owner\nova"


def _safe_path(path: str) -> str:
    full = os.path.abspath(os.path.join(PROJECT_ROOT, path))

    if not full.startswith(PROJECT_ROOT):
        raise Exception("Invalid path outside project")

    return full


def read_file(path: str) -> str:
    full = _safe_path(path)

    try:
        with open(full, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as e:
        return f"ERROR reading file: {e}"


def write_file(path: str, content: str) -> str:
    full = _safe_path(path)

    try:
        os.makedirs(os.path.dirname(full), exist_ok=True)

        with open(full, "w", encoding="utf-8") as f:
            f.write(content)

        return f"File written: {path}"
    except Exception as e:
        return f"ERROR writing file: {e}"


def append_file(path: str, content: str) -> str:
    full = _safe_path(path)

    try:
        os.makedirs(os.path.dirname(full), exist_ok=True)

        with open(full, "a", encoding="utf-8") as f:
            f.write(content)

        return f"File appended: {path}"
    except Exception as e:
        return f"ERROR appending file: {e}"