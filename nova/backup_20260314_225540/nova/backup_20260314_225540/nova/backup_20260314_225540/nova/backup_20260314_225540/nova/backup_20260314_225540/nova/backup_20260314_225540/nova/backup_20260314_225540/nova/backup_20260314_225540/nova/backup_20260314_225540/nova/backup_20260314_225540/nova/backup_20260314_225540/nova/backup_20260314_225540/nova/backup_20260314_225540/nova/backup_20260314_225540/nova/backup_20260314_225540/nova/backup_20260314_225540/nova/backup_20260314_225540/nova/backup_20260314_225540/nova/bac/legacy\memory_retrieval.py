from typing import List
import re

from .strategic_memory import get_memory


def _tokenize(text: str):

    return re.findall(r"[a-zA-Z0-9]+", text.lower())


def retrieve_memory(user_text: str):

    tokens = set(_tokenize(user_text))

    results = []

    for item in get_memory():

        score = 0

        for token in tokens:

            if token in item["text"].lower():
                score += 1

        if score > 0:
            results.append((score, item["text"]))

    results.sort(reverse=True)

    return [x[1] for x in results[:5]]