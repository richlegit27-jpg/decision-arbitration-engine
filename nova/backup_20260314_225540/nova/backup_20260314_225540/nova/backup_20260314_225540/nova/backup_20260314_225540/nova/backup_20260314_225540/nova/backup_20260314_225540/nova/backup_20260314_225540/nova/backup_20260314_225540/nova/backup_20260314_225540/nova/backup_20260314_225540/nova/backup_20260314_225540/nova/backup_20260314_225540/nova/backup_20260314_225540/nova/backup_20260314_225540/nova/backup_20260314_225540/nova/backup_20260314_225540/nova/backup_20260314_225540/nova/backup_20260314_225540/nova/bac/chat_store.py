from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .config import CHAT_STORE_FILE


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load_store() -> Dict[str, Any]:
    try:
        with open(CHAT_STORE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and "chats" in data and isinstance(data["chats"], dict):
            return data
    except Exception:
        pass

    return {"chats": {}}


def _save_store(store: Dict[str, Any]) -> None:
    try:
        with open(CHAT_STORE_FILE, "w", encoding="utf-8") as f:
            json.dump(store, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


def _make_chat_id() -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S%f")
    return f"chat_{stamp}"


def list_chats() -> List[Dict[str, Any]]:
    store = _load_store()
    chats = list(store.get("chats", {}).values())

    chats.sort(
        key=lambda item: str(item.get("updated_at") or item.get("created_at") or ""),
        reverse=True,
    )
    return chats


def get_chat(chat_id: str) -> Optional[Dict[str, Any]]:
    if not chat_id:
        return None

    store = _load_store()
    chat = store.get("chats", {}).get(chat_id)
    return chat if isinstance(chat, dict) else None


def create_chat(title: str = "New Chat") -> Dict[str, Any]:
    store = _load_store()
    chat_id = _make_chat_id()
    timestamp = now_iso()

    chat = {
        "id": chat_id,
        "title": str(title or "New Chat").strip() or "New Chat",
        "created_at": timestamp,
        "updated_at": timestamp,
        "messages": [],
    }

    store["chats"][chat_id] = chat
    _save_store(store)
    return chat


def delete_chat(chat_id: str) -> bool:
    store = _load_store()
    chats = store.get("chats", {})

    if chat_id not in chats:
        return False

    del chats[chat_id]
    _save_store(store)
    return True


def append_message(chat_id: str, role: str, content: str) -> Optional[Dict[str, Any]]:
    store = _load_store()
    chat = store.get("chats", {}).get(chat_id)

    if not isinstance(chat, dict):
        return None

    message = {
        "id": f"msg_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}",
        "role": str(role or "user").strip() or "user",
        "content": str(content or ""),
        "created_at": now_iso(),
    }

    chat.setdefault("messages", []).append(message)
    chat["updated_at"] = now_iso()

    _save_store(store)
    return chat


def clear_chat_messages(chat_id: str) -> Optional[Dict[str, Any]]:
    store = _load_store()
    chat = store.get("chats", {}).get(chat_id)

    if not isinstance(chat, dict):
        return None

    chat["messages"] = []
    chat["updated_at"] = now_iso()

    _save_store(store)
    return chat