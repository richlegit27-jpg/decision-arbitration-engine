# ===============================
# Auto-Package Nova Endgame Script
# ===============================

$basePath = "C:\Users\Owner\nova-endgame-final"
$zipPath  = "C:\Users\Owner\nova-endgame-final.zip"

# 1️⃣ Remove any existing folder
if(Test-Path $basePath){ Remove-Item $basePath -Recurse -Force }

# 2️⃣ Create folder structure
New-Item -ItemType Directory -Path "$basePath\templates" -Force
New-Item -ItemType Directory -Path "$basePath\static\js" -Force
New-Item -ItemType Directory -Path "$basePath\static\css" -Force

# 3️⃣ Write HTML
$html = @"
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Nova</title>
<link rel="stylesheet" href="../static/css/base.css">
<link rel="stylesheet" href="../static/css/layout.css">
<link rel="stylesheet" href="../static/css/nova-polish-full.css">
<link rel="stylesheet" href="../static/css/nova-mobile.css">
</head>
<body class="chat-bg-dark sidebar-open">
<header id="heroStrip"><h1>Nova</h1><p>Your AI workspace with memory, files, and persistent conversations.</p></header>
<div class="layout">
<aside id="sidebar"><ul id="chatList"></ul><button id="newChatBtn">+ New Chat</button></aside>
<main class="workspace">
<form id="composerForm"><textarea id="composerInput"></textarea><button id="sendBtn">Send</button></form>
<aside id="memoryPanel"><h3>Memory</h3></aside>
<aside id="filesPanel"><h3>Files</h3></aside>
</main>
</div>
<footer><button id="themeToggleBtn">Theme</button><button id="sidebarToggleBtn">☰</button><button id="logoutBtn">Logout</button></footer>
<script src="../js/nova-bindings.js"></script>
</body>
</html>
"@
Set-Content -Path "$basePath\templates\index.html" -Value $html

# 4️⃣ Write example CSS files
$cssFiles = @{
    "base.css" = "body{margin:0;font-family:Inter,sans-serif;}"
    "layout.css" = ".layout{display:flex;height:100vh;}"
    "nova-polish-full.css" = "body{background:#0b0f14;color:#e7edf5;} button{border-radius:8px;}"
    "nova-mobile.css" = "@media(max-width:980px){.layout{flex-direction:column;}}"
}

foreach($f in $cssFiles.Keys){
    Set-Content -Path "$basePath\static\css\$f" -Value $cssFiles[$f]
}

# 5️⃣ Write JS bindings placeholder
$jsBindings = @"
// Nova Bindings placeholder
console.log('Nova JS bindings loaded');
"
Set-Content -Path "$basePath\static\js\nova-bindings.js" -Value $jsBindings

# 6️⃣ Write stress-test.js
$stressTest = @"
// Stress-test placeholder
console.log('Stress-test loaded');
"
Set-Content -Path "$basePath\static\js\stress-test.js" -Value $stressTest

# 7️⃣ Write deploy script
$deploy = @"
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
Start-Process 'http://127.0.0.1:8000/'
Write-Host 'Nova endgame folder ready. Copy backend files separately.'
"@
Set-Content -Path "$basePath\deploy-nova.ps1" -Value $deploy

# 8️⃣ Create ZIP
if(Test-Path $zipPath){ Remove-Item $zipPath -Force }
Compress-Archive -Path "$basePath\*" -DestinationPath $zipPath -Force

Write-Host "✅ Nova endgame folder and ZIP created at $basePath and $zipPath"