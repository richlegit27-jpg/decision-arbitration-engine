import os
from typing import Any, Dict, List


TEXT_PREVIEW_LIMIT = 4000
CODE_EXTENSIONS = {
    ".py",
    ".js",
    ".ts",
    ".tsx",
    ".jsx",
    ".html",
    ".css",
    ".json",
    ".md",
    ".txt",
    ".yml",
    ".yaml",
    ".xml",
    ".sql",
    ".sh",
    ".ps1",
    ".bat",
    ".java",
    ".c",
    ".cpp",
    ".h",
    ".hpp",
    ".go",
    ".rs",
    ".php",
    ".rb",
}
DOCUMENT_EXTENSIONS = {
    ".pdf",
    ".doc",
    ".docx",
    ".rtf",
    ".odt",
}
TEXT_EXTENSIONS = {
    ".txt",
    ".md",
    ".json",
    ".csv",
    ".log",
    ".yml",
    ".yaml",
    ".xml",
}
IMAGE_EXTENSIONS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".webp",
    ".bmp",
    ".svg",
}


def _safe_str(value: Any) -> str:
    if value is None:
        return ""
    return str(value)


def _normalize_filename(name: str) -> str:
    return os.path.basename(_safe_str(name).strip())


def _extension_of(name: str) -> str:
    return os.path.splitext(name.lower())[1]


def _looks_like_code_text(text: str) -> bool:
    sample = (text or "")[:1500].lower()

    code_signals = [
        "def ",
        "class ",
        "import ",
        "from ",
        "function ",
        "const ",
        "let ",
        "var ",
        "return ",
        "#include",
        "public class",
        "console.log",
        "async ",
        "await ",
        "try:",
        "except",
        "{",
        "}",
        "</",
        "select ",
        "insert ",
        "update ",
        "delete ",
    ]

    hits = sum(1 for signal in code_signals if signal in sample)
    return hits >= 2


def _truncate_text(text: str, limit: int = TEXT_PREVIEW_LIMIT) -> str:
    value = _safe_str(text)
    if len(value) <= limit:
        return value
    return value[:limit].rstrip() + "\n...[truncated]"


def classify_attachment_kind(attachment: Dict[str, Any]) -> str:
    mime_type = _safe_str(attachment.get("mime_type")).lower()
    name = _normalize_filename(attachment.get("name", ""))
    ext = _extension_of(name)
    extracted_text = _safe_str(
        attachment.get("text")
        or attachment.get("content")
        or attachment.get("extracted_text")
        or attachment.get("ocr_text")
        or attachment.get("transcript")
        or ""
    )

    if mime_type.startswith("image/") or ext in IMAGE_EXTENSIONS:
        return "image"

    if (
        mime_type.startswith("text/")
        or "json" in mime_type
        or "javascript" in mime_type
        or "python" in mime_type
        or "html" in mime_type
        or "css" in mime_type
        or "xml" in mime_type
        or ext in CODE_EXTENSIONS
    ):
        if ext in CODE_EXTENSIONS or _looks_like_code_text(extracted_text):
            return "code"
        return "text"

    if "pdf" in mime_type or "word" in mime_type or ext in DOCUMENT_EXTENSIONS:
        return "document"

    if ext in TEXT_EXTENSIONS:
        if _looks_like_code_text(extracted_text):
            return "code"
        return "text"

    if extracted_text.strip():
        if _looks_like_code_text(extracted_text):
            return "code"
        return "text"

    return "binary"


def normalize_attachment(attachment: Dict[str, Any]) -> Dict[str, Any]:
    name = _normalize_filename(attachment.get("name", "attachment"))
    mime_type = _safe_str(attachment.get("mime_type")).lower()
    kind = classify_attachment_kind(attachment)

    extracted_text = _safe_str(
        attachment.get("text")
        or attachment.get("content")
        or attachment.get("extracted_text")
        or attachment.get("ocr_text")
        or attachment.get("transcript")
        or ""
    )

    caption = _safe_str(
        attachment.get("caption")
        or attachment.get("vision_caption")
        or attachment.get("description")
        or ""
    )

    preview = _truncate_text(extracted_text)

    return {
        "id": _safe_str(attachment.get("id")),
        "name": name,
        "mime_type": mime_type,
        "kind": kind,
        "size": attachment.get("size", 0),
        "text_preview": preview,
        "vision_caption": caption,
        "raw_path": _safe_str(attachment.get("path") or attachment.get("url") or ""),
        "is_code_like": kind == "code",
        "has_text": bool(preview.strip()),
    }


def normalize_attachments(attachments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    normalized: List[Dict[str, Any]] = []

    for attachment in attachments or []:
        if not isinstance(attachment, dict):
            continue
        normalized.append(normalize_attachment(attachment))

    return normalized


def detect_attachment_mode(attachments: List[Dict[str, Any]]) -> str:
    if not attachments:
        return "chat"

    normalized = normalize_attachments(attachments)
    kinds = {item["kind"] for item in normalized}

    if "image" in kinds and len(kinds) == 1:
        return "vision"

    if "code" in kinds:
        return "analyze_code"

    if "document" in kinds:
        return "analyze_document"

    if "text" in kinds:
        return "analyze_file"

    return "analyze_file"


def build_attachment_context(attachments: List[Dict[str, Any]]) -> str:
    normalized = normalize_attachments(attachments)

    if not normalized:
        return ""

    lines: List[str] = []
    lines.append("Current attachment context:")

    for index, item in enumerate(normalized, start=1):
        lines.append(f"- attachment_{index}:")
        lines.append(f"  name: {item['name']}")
        lines.append(f"  mime_type: {item['mime_type'] or 'unknown'}")
        lines.append(f"  kind: {item['kind']}")
        lines.append(f"  size: {item['size']}")

        if item["vision_caption"]:
            lines.append("  vision_caption:")
            lines.append(_indent_block(item["vision_caption"], 4))

        if item["text_preview"]:
            lines.append("  text_preview:")
            lines.append(_indent_block(item["text_preview"], 4))

    return "\n".join(lines)


def _indent_block(text: str, spaces: int) -> str:
    prefix = " " * spaces
    return "\n".join(f"{prefix}{line}" for line in _safe_str(text).splitlines() or [""])


def get_attachment_instruction_block(attachments: List[Dict[str, Any]]) -> str:
    normalized = normalize_attachments(attachments)

    if not normalized:
        return ""

    kinds = {item["kind"] for item in normalized}

    if "code" in kinds:
        return (
            "Attachment instructions:\n"
            "- Treat attached content as code or technical implementation context.\n"
            "- Focus on debugging, architecture, and direct code-aware guidance.\n"
            "- Quote only small relevant snippets when needed.\n"
            "- Prefer root-cause analysis over generic advice."
        )

    if "image" in kinds and len(kinds) == 1:
        return (
            "Attachment instructions:\n"
            "- Treat attached content as image input.\n"
            "- Focus on visible details, extracted meaning, and user intent.\n"
            "- Do not invent details that are not supported by the attachment metadata."
        )

    if "document" in kinds:
        return (
            "Attachment instructions:\n"
            "- Treat attached content as document context.\n"
            "- Focus on summarizing, extracting key facts, and answering from the document.\n"
            "- Use the attachment text preview as the source of truth when available."
        )

    return (
        "Attachment instructions:\n"
        "- Treat attached content as file context relevant to the user's request.\n"
        "- Use the file details to guide the answer.\n"
        "- Stay specific to the attachment instead of answering generically."
    )