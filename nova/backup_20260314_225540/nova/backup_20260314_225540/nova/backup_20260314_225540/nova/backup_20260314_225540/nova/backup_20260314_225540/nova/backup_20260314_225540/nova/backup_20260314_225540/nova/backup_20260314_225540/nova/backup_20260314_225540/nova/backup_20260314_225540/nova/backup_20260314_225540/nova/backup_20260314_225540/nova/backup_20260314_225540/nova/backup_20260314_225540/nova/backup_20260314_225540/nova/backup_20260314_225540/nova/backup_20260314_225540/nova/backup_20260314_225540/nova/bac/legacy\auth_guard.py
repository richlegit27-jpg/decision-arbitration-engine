from fastapi import Request
from fastapi.responses import RedirectResponse

from .auth_engine import get_session


async def require_auth(request: Request):

    token = request.cookies.get("nova_session")

    session = get_session(token)

    if not session:
        return RedirectResponse("/login")

    return None