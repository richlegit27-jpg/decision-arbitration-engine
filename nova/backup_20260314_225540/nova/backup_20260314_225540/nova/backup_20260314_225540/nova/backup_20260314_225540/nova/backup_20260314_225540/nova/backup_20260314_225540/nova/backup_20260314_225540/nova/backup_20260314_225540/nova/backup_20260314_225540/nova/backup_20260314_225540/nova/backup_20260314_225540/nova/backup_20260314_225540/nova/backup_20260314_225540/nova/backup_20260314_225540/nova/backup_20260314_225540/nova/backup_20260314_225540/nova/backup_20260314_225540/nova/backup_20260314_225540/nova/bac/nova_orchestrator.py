from typing import Dict, List

from .strategic_controller import run_nova_core, finalize_turn


def process_nova_request(system_prompt: str, messages: List[Dict], user_text: str):

    assistant_text = run_nova_core(
        system_prompt=system_prompt,
        messages=messages,
        user_text=user_text
    )

    finalize_turn(user_text, assistant_text)

    return assistant_text