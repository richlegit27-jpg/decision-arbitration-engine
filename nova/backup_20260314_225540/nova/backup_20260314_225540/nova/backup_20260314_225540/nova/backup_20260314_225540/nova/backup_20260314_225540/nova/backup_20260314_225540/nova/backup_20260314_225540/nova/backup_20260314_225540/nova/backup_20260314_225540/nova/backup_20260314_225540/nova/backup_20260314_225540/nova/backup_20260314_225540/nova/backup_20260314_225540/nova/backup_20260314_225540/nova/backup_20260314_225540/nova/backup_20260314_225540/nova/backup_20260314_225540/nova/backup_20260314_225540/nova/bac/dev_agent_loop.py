from typing import Dict, List
import json

from .openai_service import openai_chat, extract_response_text
from .config import OPENAI_MODEL
from .dev_agent_tools import read_file, search_project, apply_patch

TOOLS = {
    "read_file": read_file,
    "search_project": search_project,
    "apply_patch": apply_patch,
}

MAX_STEPS = 5


def _parse_tool_call(text: str):

    try:
        data = json.loads(text)
    except Exception:
        return None

    if not isinstance(data, dict):
        return None

    if "tool" not in data:
        return None

    return data


def run_dev_agent(system_prompt: str, messages: List[Dict[str, str]]):

    history = list(messages)

    for step in range(MAX_STEPS):

        response = openai_chat(
            model=OPENAI_MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                *history
            ]
        )

        text = extract_response_text(response)

        tool_call = _parse_tool_call(text)

        if not tool_call:
            return text

        tool = tool_call.get("tool")
        args = tool_call.get("args", {})

        if tool not in TOOLS:
            return f"Unknown tool: {tool}"

        try:
            result = TOOLS[tool](**args)
        except Exception as e:
            result = f"Tool error: {e}"

        history.append(
            {
                "role": "assistant",
                "content": text
            }
        )

        history.append(
            {
                "role": "tool",
                "content": str(result)
            }
        )

    return "Agent stopped after max steps"