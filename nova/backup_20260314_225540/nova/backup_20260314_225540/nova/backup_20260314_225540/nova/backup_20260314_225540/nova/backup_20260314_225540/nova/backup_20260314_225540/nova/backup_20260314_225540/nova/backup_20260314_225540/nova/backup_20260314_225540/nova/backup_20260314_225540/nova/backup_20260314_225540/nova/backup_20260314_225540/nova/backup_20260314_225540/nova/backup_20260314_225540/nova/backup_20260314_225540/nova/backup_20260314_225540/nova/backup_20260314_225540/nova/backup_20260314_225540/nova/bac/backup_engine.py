import os
import shutil
from datetime import datetime

PROJECT_ROOT = r"C:\Users\Owner\nova"
BACKUP_DIR = r"C:\Users\Owner\nova\runtime\backups"

EXCLUDE_DIRS = {
    "runtime\\backups",
    "__pycache__",
    ".git",
}


def _should_skip(path: str) -> bool:
    for skip in EXCLUDE_DIRS:
        if skip in path:
            return True
    return False


def create_restore_point(label: str = "snapshot") -> str:

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = f"{timestamp}_{label}"

    backup_path = os.path.join(BACKUP_DIR, name)

    os.makedirs(BACKUP_DIR, exist_ok=True)

    for root, dirs, files in os.walk(PROJECT_ROOT):

        if _should_skip(root):
            continue

        rel = os.path.relpath(root, PROJECT_ROOT)
        target_dir = os.path.join(backup_path, rel)

        os.makedirs(target_dir, exist_ok=True)

        for file in files:

            src = os.path.join(root, file)

            if "runtime\\backups" in src:
                continue

            dst = os.path.join(target_dir, file)

            try:
                shutil.copy2(src, dst)
            except Exception:
                pass

    return backup_path


def list_restore_points():

    if not os.path.exists(BACKUP_DIR):
        return []

    items = os.listdir(BACKUP_DIR)

    items.sort(reverse=True)

    return items


def restore_point(name: str):

    path = os.path.join(BACKUP_DIR, name)

    if not os.path.exists(path):
        return "Backup not found"

    for root, dirs, files in os.walk(path):

        rel = os.path.relpath(root, path)
        target = os.path.join(PROJECT_ROOT, rel)

        os.makedirs(target, exist_ok=True)

        for file in files:

            src = os.path.join(root, file)
            dst = os.path.join(target, file)

            try:
                shutil.copy2(src, dst)
            except Exception:
                pass

    return f"Restored: {name}"