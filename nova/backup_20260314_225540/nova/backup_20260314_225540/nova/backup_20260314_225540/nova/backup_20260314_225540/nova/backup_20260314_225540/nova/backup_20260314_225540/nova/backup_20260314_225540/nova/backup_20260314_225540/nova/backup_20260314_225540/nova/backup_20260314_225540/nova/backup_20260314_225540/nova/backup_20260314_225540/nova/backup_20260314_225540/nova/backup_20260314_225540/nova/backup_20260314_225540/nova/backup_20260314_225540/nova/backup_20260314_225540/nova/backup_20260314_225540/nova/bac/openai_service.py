from __future__ import annotations

from typing import Any, Dict, List, Optional

from .config import OPENAI_API_KEY

try:
    from openai import OpenAI
except Exception:
    OpenAI = None


def has_openai() -> bool:
    return bool(OPENAI_API_KEY) and OpenAI is not None


def get_openai_client():
    if not has_openai():
        return None
    return OpenAI(api_key=OPENAI_API_KEY)


def openai_chat(
    *,
    model: str,
    messages: List[Dict[str, str]],
    max_tokens: int = 700,
) -> Dict[str, Any]:
    client = get_openai_client()
    if client is None:
      raise RuntimeError("OpenAI client is not available. Set OPENAI_API_KEY and install openai.")

    response = client.chat.completions.create(
        model=model,
        messages=messages,
        max_tokens=max_tokens,
    )

    return response.model_dump()


def openai_generate_image(
    *,
    prompt: str,
    size: str = "1024x1024",
    quality: str = "auto",
    output_format: str = "png",
    background: str = "auto",
    model: str = "gpt-image-1",
) -> Dict[str, Any]:
    client = get_openai_client()
    if client is None:
        raise RuntimeError("OpenAI client is not available. Set OPENAI_API_KEY and install openai.")

    clean_prompt = str(prompt or "").strip()
    if not clean_prompt:
        raise RuntimeError("Image prompt is required.")

    response = client.images.generate(
        model=model,
        prompt=clean_prompt,
        size=size,
        quality=quality,
        output_format=output_format,
        background=background,
    )

    return response.model_dump()


def extract_response_text(response: Dict[str, Any]) -> str:
    try:
        choices = response.get("choices") or []
        if not choices:
            return ""

        message = choices[0].get("message") or {}
        content = message.get("content")

        if isinstance(content, str):
            return content.strip()

        if isinstance(content, list):
            parts: List[str] = []
            for item in content:
                if isinstance(item, dict) and item.get("type") == "text":
                    text_value = item.get("text")
                    if text_value:
                        parts.append(str(text_value))
            return "\n".join(parts).strip()

        return str(content or "").strip()
    except Exception:
        return ""


def extract_image_payload(response: Dict[str, Any]) -> Dict[str, Optional[str]]:
    try:
        data = response.get("data") or []
        if not data:
            return {
                "image_url": None,
                "b64_json": None,
                "revised_prompt": None,
            }

        first = data[0] or {}

        return {
            "image_url": first.get("url"),
            "b64_json": first.get("b64_json"),
            "revised_prompt": first.get("revised_prompt"),
        }
    except Exception:
        return {
            "image_url": None,
            "b64_json": None,
            "revised_prompt": None,
        }