from typing import Dict, List
import json

from .openai_service import openai_chat, extract_response_text
from .config import OPENAI_MODEL


INTELLIGENCE_PROMPT = """
You are Nova's Intelligence Core.

Before answering the user you must:

1. Diagnose the request
2. Decide if tools are needed
3. Create a short execution plan
4. Execute the plan

If tools are required output JSON:

{
 "tool": "tool_name",
 "args": { }
}

Otherwise answer normally.

Always prefer:
- fixing root cause
- minimal changes
- safe patches
"""


def build_intelligence_prompt(system_prompt: str):

    return f"""
{system_prompt}

{INTELLIGENCE_PROMPT}
"""


def run_intelligence_step(system_prompt: str, messages: List[Dict]):

    prompt = [
        {"role": "system", "content": build_intelligence_prompt(system_prompt)},
        *messages
    ]

    response = openai_chat(
        model=OPENAI_MODEL,
        messages=prompt
    )

    return extract_response_text(response)