from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional

import requests


SERPAPI_URL = "https://serpapi.com/search.json"
DEFAULT_TIMEOUT = 20


def has_web_search() -> bool:
    return bool(os.getenv("SERPAPI_API_KEY", "").strip())


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _normalize_result(item: Dict[str, Any]) -> Dict[str, Any]:
    title = _clean_text(item.get("title"))
    link = _clean_text(item.get("link"))
    snippet = _clean_text(item.get("snippet"))
    source = _clean_text(item.get("source"))

    if not source and link:
        source = link.split("/")[2] if "://" in link else link

    return {
        "title": title,
        "link": link,
        "snippet": snippet,
        "source": source,
    }


def search_web(query: str, max_results: int = 5) -> List[Dict[str, Any]]:
    clean_query = _clean_text(query)
    if not clean_query:
        return []

    api_key = os.getenv("SERPAPI_API_KEY", "").strip()
    if not api_key:
        return []

    params = {
        "engine": "google",
        "q": clean_query,
        "api_key": api_key,
        "num": max(1, min(int(max_results or 5), 10)),
    }

    response = requests.get(SERPAPI_URL, params=params, timeout=DEFAULT_TIMEOUT)
    response.raise_for_status()

    payload = response.json()
    organic_results = payload.get("organic_results") or []

    results: List[Dict[str, Any]] = []
    for item in organic_results[:max_results]:
        normalized = _normalize_result(item)
        if normalized["title"] or normalized["snippet"] or normalized["link"]:
            results.append(normalized)

    return results


def format_web_results(results: Optional[List[Dict[str, Any]]]) -> str:
    if not results:
        return ""

    lines: List[str] = []
    for index, item in enumerate(results, start=1):
        title = _clean_text(item.get("title"))
        link = _clean_text(item.get("link"))
        snippet = " ".join(_clean_text(item.get("snippet")).split())
        source = _clean_text(item.get("source"))

        line_parts = [f"{index}."]
        if title:
            line_parts.append(title)
        if source:
            line_parts.append(f"({source})")
        if link:
            line_parts.append(f"- {link}")

        lines.append(" ".join(line_parts).strip())

        if snippet:
            lines.append(f"   {snippet[:400]}")

    return "\n".join(lines).strip()


def search_web_context(query: str, max_results: int = 5) -> str:
    try:
        results = search_web(query=query, max_results=max_results)
    except Exception as exc:
        return f"Web search error: {exc}"

    return format_web_results(results)