from __future__ import annotations

import os
from pathlib import Path


# =========================================================
# BASE PATHS
# =========================================================

BASE_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = BASE_DIR
ROOT_DIR = BASE_DIR
BASE_PATH = BASE_DIR

BACKEND_DIR = BASE_DIR / "backend"
STATIC_DIR = BASE_DIR / "static"
TEMPLATES_DIR = BASE_DIR / "templates"


# =========================================================
# RUNTIME DIRECTORIES
# =========================================================

RUNTIME_DIR = BASE_DIR / "runtime"
BASE_RUNTIME_DIR = RUNTIME_DIR

RUNTIME_UPLOADS_DIR = RUNTIME_DIR / "uploads"
RUNTIME_LOGS_DIR = RUNTIME_DIR / "logs"
RUNTIME_DATA_DIR = RUNTIME_DIR / "data"
RUNTIME_MEMORY_DIR = RUNTIME_DIR / "memory"
RUNTIME_CACHE_DIR = RUNTIME_DIR / "cache"
RUNTIME_EXPORTS_DIR = RUNTIME_DIR / "exports"
RUNTIME_TASKS_DIR = RUNTIME_DIR / "tasks"
RUNTIME_BACKUPS_DIR = RUNTIME_DIR / "backups"

UPLOADS_DIR = RUNTIME_UPLOADS_DIR
LOGS_DIR = RUNTIME_LOGS_DIR
DATA_DIR = RUNTIME_DATA_DIR
MEMORY_DIR = RUNTIME_MEMORY_DIR
CACHE_DIR = RUNTIME_CACHE_DIR
EXPORTS_DIR = RUNTIME_EXPORTS_DIR
TASKS_DIR = RUNTIME_TASKS_DIR
BACKUPS_DIR = RUNTIME_BACKUPS_DIR


# =========================================================
# CREATE DIRECTORIES
# =========================================================

for directory in [
    RUNTIME_DIR,
    RUNTIME_UPLOADS_DIR,
    RUNTIME_LOGS_DIR,
    RUNTIME_DATA_DIR,
    RUNTIME_MEMORY_DIR,
    RUNTIME_CACHE_DIR,
    RUNTIME_EXPORTS_DIR,
    RUNTIME_TASKS_DIR,
    RUNTIME_BACKUPS_DIR,
]:
    directory.mkdir(parents=True, exist_ok=True)


# =========================================================
# APP FLAGS
# =========================================================

APP_NAME = os.getenv("NOVA_APP_NAME", "nova")
APP_ENV = os.getenv("NOVA_ENV", "development")
APP_DEBUG = os.getenv("NOVA_DEBUG", "1").strip().lower() in {"1", "true", "yes", "on"}
DEBUG = APP_DEBUG

DEV_AUTH_BYPASS = os.getenv("NOVA_DEV_AUTH_BYPASS", "1").strip().lower() in {
    "1",
    "true",
    "yes",
    "on",
}


# =========================================================
# NETWORK
# =========================================================

HOST = os.getenv("NOVA_HOST", "127.0.0.1")
PORT = int(os.getenv("NOVA_PORT", "8000"))
API_PREFIX = os.getenv("NOVA_API_PREFIX", "/api")


# =========================================================
# CHAT / MEMORY LIMITS
# =========================================================

MAX_HISTORY_MESSAGES = int(os.getenv("NOVA_MAX_HISTORY_MESSAGES", "40"))
MAX_MESSAGE_CHARS = int(os.getenv("NOVA_MAX_MESSAGE_CHARS", "12000"))
MAX_TITLE_CHARS = int(os.getenv("NOVA_MAX_TITLE_CHARS", "120"))
MAX_MEMORY_ITEMS = int(os.getenv("NOVA_MAX_MEMORY_ITEMS", "200"))
MAX_MEMORY_TEXT_CHARS = int(os.getenv("NOVA_MAX_MEMORY_TEXT_CHARS", "2000"))


# =========================================================
# FILE LIMITS
# =========================================================

MAX_UPLOAD_BYTES = int(os.getenv("NOVA_MAX_UPLOAD_BYTES", str(25 * 1024 * 1024)))
MAX_FILE_PREVIEW_CHARS = int(os.getenv("NOVA_MAX_FILE_PREVIEW_CHARS", "12000"))


# =========================================================
# OPENAI / MODEL SETTINGS
# =========================================================

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
OPENAI_MAX_TOKENS = int(os.getenv("OPENAI_MAX_TOKENS", "1200"))
OPENAI_TEMPERATURE = float(os.getenv("OPENAI_TEMPERATURE", "0.2"))

MODEL_NAME = OPENAI_MODEL
MODEL_MAX_TOKENS = OPENAI_MAX_TOKENS


# =========================================================
# AUTH / SESSION
# =========================================================

SESSION_SECRET = os.getenv("NOVA_SESSION_SECRET", "nova-dev-secret-change-me")
LOGIN_USERNAME = os.getenv("NOVA_USERNAME", "admin")
LOGIN_PASSWORD = os.getenv("NOVA_PASSWORD", "admin123")


# =========================================================
# LOGGING
# =========================================================

LOG_FILE = RUNTIME_LOGS_DIR / "nova.log"
ERROR_LOG_FILE = RUNTIME_LOGS_DIR / "nova-error.log"


# =========================================================
# STORAGE FILES
# =========================================================

CHAT_STORE_FILE = RUNTIME_DATA_DIR / "chats.json"
MEMORY_STORE_FILE = RUNTIME_DATA_DIR / "memory.json"
TASKS_STORE_FILE = RUNTIME_DATA_DIR / "tasks.json"
WORKSPACE_STATE_FILE = RUNTIME_DATA_DIR / "workspace_state.json"

CHATS_FILE = CHAT_STORE_FILE
MEMORY_FILE = MEMORY_STORE_FILE
SETTINGS_FILE = RUNTIME_DATA_DIR / "settings.json"
STATE_FILE = RUNTIME_DATA_DIR / "state.json"