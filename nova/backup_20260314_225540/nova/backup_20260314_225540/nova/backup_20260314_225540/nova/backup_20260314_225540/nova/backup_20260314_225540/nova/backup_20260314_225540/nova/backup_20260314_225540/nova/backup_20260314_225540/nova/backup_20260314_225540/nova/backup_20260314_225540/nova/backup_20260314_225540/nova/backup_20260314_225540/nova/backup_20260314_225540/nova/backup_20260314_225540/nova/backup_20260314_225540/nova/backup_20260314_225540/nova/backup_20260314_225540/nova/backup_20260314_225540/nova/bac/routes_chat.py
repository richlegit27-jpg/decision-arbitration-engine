import json
import time
from typing import Any, Dict, List

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse

from .brain import run_brain
from .config import OPENAI_MODEL, SUMMARY_RECENT_MESSAGES, SUMMARY_TRIGGER_MESSAGES
from .chat_store import (
    append_message,
    build_chat_payload,
    chat_summary,
    ensure_chat,
    get_chat_or_404,
    load_chats_store,
    now_iso,
    new_chat_id,
    normalize_chat_record,
    pick_chat_id,
    pick_message,
    pick_system_prompt,
    save_chats_store,
    sorted_chat_summaries,
    update_chat_summary,
    update_chat_title,
)
from .memory_store import get_relevant_memory_text, update_memory_items
from .openai_service import sse
from .summary_engine import safe_build_summary
from .title_engine import generate_chat_title, should_update_title


router = APIRouter()


# ---------------------------------------------------
# CHAT
# ---------------------------------------------------


@router.post("/api/chat")
async def chat(request: Request):

    body = await request.json()

    user_text = pick_message(body)
    chat_id = pick_chat_id(body) or new_chat_id()

    if not user_text:
        raise HTTPException(status_code=400, detail="Message required")

    ensure_chat(chat_id)

    with request.app.state.chats_lock:

        store = load_chats_store()
        chat = get_chat_or_404(store, chat_id)

        append_message(chat, "user", user_text)

        conversation_messages = chat.get("messages", [])

    # -------------------------
    # MEMORY CONTEXT
    # -------------------------

    memory_text = get_relevant_memory_text(user_text)

    if memory_text:
        conversation_messages = [
            {
                "role": "system",
                "content": f"Relevant memory:\n{memory_text}",
            }
        ] + conversation_messages

    # -------------------------
    # BRAIN EXECUTION
    # -------------------------

    brain_result = run_brain(
        user_text=user_text,
        conversation_messages=conversation_messages,
        model=OPENAI_MODEL,
    )

    reply = brain_result.get("reply", "")

    # -------------------------
    # SAVE RESULT
    # -------------------------

    with request.app.state.chats_lock:

        store = load_chats_store()
        chat = get_chat_or_404(store, chat_id)

        append_message(chat, "assistant", reply)

        update_memory_items(user_text, reply)

        # summary update

        if len(chat["messages"]) >= SUMMARY_TRIGGER_MESSAGES:

            summary = safe_build_summary(
                chat["messages"][-SUMMARY_RECENT_MESSAGES:]
            )

            if summary:
                update_chat_summary(chat, summary)

        # title update

        if should_update_title(chat):

            title = generate_chat_title(chat)

            if title:
                update_chat_title(chat, title)

        save_chats_store(store)

    return JSONResponse(
        {
            "chat_id": chat_id,
            "reply": reply,
            "tool_runs": brain_result.get("tool_runs", []),
        }
    )


# ---------------------------------------------------
# STREAM CHAT
# ---------------------------------------------------


@router.post("/api/chat/stream")
async def chat_stream(request: Request):

    body = await request.json()

    user_text = pick_message(body)
    chat_id = pick_chat_id(body) or new_chat_id()

    if not user_text:
        raise HTTPException(status_code=400, detail="Message required")

    ensure_chat(chat_id)

    with request.app.state.chats_lock:

        store = load_chats_store()
        chat = get_chat_or_404(store, chat_id)

        append_message(chat, "user", user_text)

        conversation_messages = chat.get("messages", [])

    # -------------------------
    # MEMORY
    # -------------------------

    memory_text = get_relevant_memory_text(user_text)

    if memory_text:
        conversation_messages = [
            {
                "role": "system",
                "content": f"Relevant memory:\n{memory_text}",
            }
        ] + conversation_messages

    # -------------------------
    # RUN BRAIN
    # -------------------------

    brain_result = run_brain(
        user_text=user_text,
        conversation_messages=conversation_messages,
        model=OPENAI_MODEL,
    )

    reply = brain_result.get("reply", "")

    async def stream():

        yield sse("start", {"chat_id": chat_id})

        for chunk in reply.split():

            yield sse("delta", {"content": chunk + " "})
            time.sleep(0.02)

        yield sse("done", {"chat_id": chat_id})

    with request.app.state.chats_lock:

        store = load_chats_store()
        chat = get_chat_or_404(store, chat_id)

        append_message(chat, "assistant", reply)

        update_memory_items(user_text, reply)

        save_chats_store(store)

    return StreamingResponse(
        stream(),
        media_type="text/event-stream",
    )