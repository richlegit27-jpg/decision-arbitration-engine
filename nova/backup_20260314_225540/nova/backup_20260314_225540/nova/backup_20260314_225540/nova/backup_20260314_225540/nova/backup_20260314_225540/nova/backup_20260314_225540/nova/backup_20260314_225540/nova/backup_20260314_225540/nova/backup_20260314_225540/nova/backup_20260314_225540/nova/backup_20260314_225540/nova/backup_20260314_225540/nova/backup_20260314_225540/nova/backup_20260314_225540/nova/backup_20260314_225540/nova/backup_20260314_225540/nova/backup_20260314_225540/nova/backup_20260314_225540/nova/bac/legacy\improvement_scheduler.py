import threading
import time

from .self_improvement_engine import update_adaptive_prompt


INTERVAL_HOURS = 6


def improvement_loop():

    while True:

        try:
            update_adaptive_prompt()
        except Exception:
            pass

        time.sleep(INTERVAL_HOURS * 3600)


def start_improvement_thread():

    thread = threading.Thread(target=improvement_loop, daemon=True)
    thread.start()