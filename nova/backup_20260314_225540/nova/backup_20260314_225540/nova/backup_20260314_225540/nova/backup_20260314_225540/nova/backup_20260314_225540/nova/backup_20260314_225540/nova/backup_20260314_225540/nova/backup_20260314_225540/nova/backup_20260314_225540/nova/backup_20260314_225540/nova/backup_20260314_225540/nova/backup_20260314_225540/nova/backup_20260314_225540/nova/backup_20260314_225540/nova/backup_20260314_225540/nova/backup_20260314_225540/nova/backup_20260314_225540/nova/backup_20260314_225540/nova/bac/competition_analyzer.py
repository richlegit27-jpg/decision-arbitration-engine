from typing import Dict


COMPETITOR_FEATURES = {
    "chatgpt": [
        "memory",
        "reasoning",
        "tools",
        "plugins"
    ],
    "cursor": [
        "code agent",
        "workspace awareness"
    ],
    "devin": [
        "autonomous coding",
        "task execution"
    ]
}


def analyze_competition():

    report = {}

    for competitor, features in COMPETITOR_FEATURES.items():

        report[competitor] = {
            "features": features
        }

    return report