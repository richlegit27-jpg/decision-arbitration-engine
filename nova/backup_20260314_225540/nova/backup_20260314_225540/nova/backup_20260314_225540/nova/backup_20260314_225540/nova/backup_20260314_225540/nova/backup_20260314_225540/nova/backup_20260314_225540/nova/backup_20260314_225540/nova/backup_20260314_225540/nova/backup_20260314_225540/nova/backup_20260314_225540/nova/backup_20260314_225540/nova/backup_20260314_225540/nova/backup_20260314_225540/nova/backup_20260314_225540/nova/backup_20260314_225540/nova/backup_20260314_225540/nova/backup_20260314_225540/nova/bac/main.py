from __future__ import annotations

import logging
import os
import time
import uuid
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

from .bootstrap_runtime import bootstrap_runtime
from .chat_routes import router as chat_router
from .config import DEBUG, LOG_FILE
from .file_routes import router as file_router

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"
TEMPLATES_DIR = BASE_DIR / "templates"

app = FastAPI(title="Nova Backend", version="1.0")
bootstrap_runtime()

SESSION_SECRET = os.getenv("NOVA_SESSION_SECRET", "nova-dev-secret-change-me")
LOGIN_USERNAME = os.getenv("NOVA_USERNAME", "admin")
LOGIN_PASSWORD = os.getenv("NOVA_PASSWORD", "admin123")
DEV_AUTH_BYPASS = os.getenv("NOVA_DEV_AUTH_BYPASS", "1").strip().lower() in {
    "1",
    "true",
    "yes",
    "on",
}

LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

logger = logging.getLogger("nova")
if not logger.handlers:
    logger.setLevel(logging.DEBUG if DEBUG else logging.INFO)

    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

app.add_middleware(
    SessionMiddleware,
    secret_key=SESSION_SECRET,
    same_site="lax",
    https_only=False,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


def get_current_user(request: Request):
    if DEV_AUTH_BYPASS:
        return {"username": "local-dev"}
    return request.session.get("user")


def is_authenticated(request: Request) -> bool:
    if DEV_AUTH_BYPASS:
        return True
    return bool(get_current_user(request))


def render_index(request: Request, status_code: int = 200):
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "user": get_current_user(request),
            "authenticated": is_authenticated(request),
        },
        status_code=status_code,
    )


@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    request_id = uuid.uuid4().hex[:12]
    start = time.perf_counter()

    try:
        response = await call_next(request)
        duration_ms = round((time.perf_counter() - start) * 1000, 2)
        logger.info(
            "%s | %s %s | %s | %sms",
            request_id,
            request.method,
            request.url.path,
            response.status_code,
            duration_ms,
        )
        response.headers["X-Request-ID"] = request_id
        return response
    except Exception:
        duration_ms = round((time.perf_counter() - start) * 1000, 2)
        logger.exception(
            "%s | %s %s | unhandled_exception | %sms",
            request_id,
            request.method,
            request.url.path,
            duration_ms,
        )
        raise


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    request_id = uuid.uuid4().hex[:12]
    logger.exception(
        "%s | %s %s | fatal_exception",
        request_id,
        request.method,
        request.url.path,
    )

    return JSONResponse(
        status_code=500,
        content={
            "ok": False,
            "error": "Internal server error.",
            "request_id": request_id,
        },
    )


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return render_index(request)


@app.get("/health")
@app.get("/api/health")
async def api_health(request: Request):
    return {
        "ok": True,
        "app": "nova",
        "status": "healthy",
        "authenticated": is_authenticated(request),
    }


@app.get("/api/session")
async def api_session(request: Request):
    user = get_current_user(request)
    return {
        "ok": True,
        "authenticated": bool(user),
        "user": user,
    }


@app.post("/api/login")
async def api_login(request: Request):
    username = ""
    password = ""

    try:
        data = await request.json()
        username = str(data.get("username") or "").strip()
        password = str(data.get("password") or "")
    except Exception:
        pass

    if not username or not password:
        try:
            form = await request.form()
            username = str(form.get("username") or "").strip()
            password = str(form.get("password") or "")
        except Exception:
            pass

    if not username or not password:
        return JSONResponse(
            status_code=400,
            content={
                "ok": False,
                "error": "Username and password are required.",
            },
        )

    if username != LOGIN_USERNAME or password != LOGIN_PASSWORD:
        logger.warning("login_failed | username=%s", username)
        return JSONResponse(
            status_code=401,
            content={
                "ok": False,
                "error": "Invalid username or password.",
            },
        )

    request.session.clear()
    request.session["user"] = {"username": username}
    logger.info("login_success | username=%s", username)

    return {
        "ok": True,
        "authenticated": True,
        "user": {"username": username},
    }


@app.post("/api/logout")
async def api_logout(request: Request):
    request.session.clear()
    logger.info("logout_success")

    response = JSONResponse(
        content={
            "ok": True,
            "authenticated": False,
        }
    )
    response.delete_cookie("session")
    return response


# route files already define /api/... paths where needed
app.include_router(chat_router)
app.include_router(file_router)