from typing import List, Dict, Any
import json

from .openai_service import openai_chat, extract_response_text
from .config import OPENAI_MODEL


def build_reasoning_prompt(system_prompt: str, messages: List[Dict[str, str]]):

    reasoning_instruction = """
You are Nova, an AI coding assistant.

Before answering the user, produce a short internal reasoning plan.

Steps:
1. Understand the request
2. Decide if tools are needed
3. If tools are needed, output a JSON tool call
4. Otherwise answer directly

When calling a tool respond ONLY with JSON:

{
  "tool": "tool_name",
  "args": {...}
}

If no tool is required, respond normally.
"""

    return [
        {"role": "system", "content": system_prompt},
        {"role": "system", "content": reasoning_instruction},
        *messages
    ]


def run_reasoning_step(system_prompt: str, messages: List[Dict[str, str]]) -> str:

    prompt = build_reasoning_prompt(system_prompt, messages)

    response = openai_chat(
        model=OPENAI_MODEL,
        messages=prompt
    )

    return extract_response_text(response)