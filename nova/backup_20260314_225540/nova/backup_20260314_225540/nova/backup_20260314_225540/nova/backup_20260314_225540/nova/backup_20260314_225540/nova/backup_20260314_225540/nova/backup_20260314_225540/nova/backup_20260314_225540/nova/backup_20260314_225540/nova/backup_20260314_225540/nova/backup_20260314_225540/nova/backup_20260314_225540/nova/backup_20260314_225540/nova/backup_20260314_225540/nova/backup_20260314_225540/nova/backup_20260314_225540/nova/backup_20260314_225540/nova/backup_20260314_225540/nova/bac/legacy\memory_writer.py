from .openai_service import openai_extract_memory
from .strategic_memory import add_memory


def update_memory(user_text: str, assistant_text: str):

    try:

        items = openai_extract_memory(user_text, assistant_text)

        for item in items:
            add_memory(item)

    except Exception:
        pass