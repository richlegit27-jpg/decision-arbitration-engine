from typing import List
from .openai_service import openai_chat, extract_response_text
from .config import OPENAI_MODEL


PLANNER_PROMPT = """
You are Nova's Task Planner.

When the user describes a large goal:
1. Break the goal into clear steps
2. Each step should be short and actionable
3. Return steps as a numbered list
"""


def plan_goal(goal: str):

    response = openai_chat(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": PLANNER_PROMPT},
            {"role": "user", "content": goal}
        ]
    )

    text = extract_response_text(response)

    steps = []

    for line in text.split("\n"):
        line = line.strip()

        if line and line[0].isdigit():
            steps.append(line)

    return steps