from typing import List, Dict

from .openai_service import openai_chat, extract_response_text
from .config import OPENAI_MODEL


SUMMARY_PROMPT = """
Summarize the following conversation into key technical points.
Focus on code, decisions, and user intent.
"""


def compress_conversation(messages: List[Dict]):

    text = ""

    for m in messages:

        role = m.get("role")
        content = m.get("content", "")

        text += f"{role}: {content}\n"

    response = openai_chat(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": SUMMARY_PROMPT},
            {"role": "user", "content": text}
        ]
    )

    return extract_response_text(response)