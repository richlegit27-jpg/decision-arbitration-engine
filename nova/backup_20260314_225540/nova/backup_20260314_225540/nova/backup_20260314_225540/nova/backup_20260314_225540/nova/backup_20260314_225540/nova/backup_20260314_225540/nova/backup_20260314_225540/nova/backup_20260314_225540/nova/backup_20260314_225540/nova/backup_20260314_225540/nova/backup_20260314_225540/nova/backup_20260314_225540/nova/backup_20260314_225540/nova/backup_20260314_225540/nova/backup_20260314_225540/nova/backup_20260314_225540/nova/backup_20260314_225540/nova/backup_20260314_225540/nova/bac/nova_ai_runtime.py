from typing import List, Dict

from .model_bridge import run_model
from .strategic_controller import build_system_prompt


def run_nova_ai(system_prompt: str, messages: List[Dict], user_text: str):

    final_prompt = build_system_prompt(system_prompt, user_text)

    response = run_model(
        messages=[
            {"role": "system", "content": final_prompt},
            *messages
        ],
        user_text=user_text
    )

    return response