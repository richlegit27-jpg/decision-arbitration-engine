from fastapi import APIRouter, Request, Response

from .auth_engine import authenticate, get_session, destroy_session

router = APIRouter()


@router.post("/api/login")
async def login(request: Request, response: Response):

    data = await request.json()

    username = data.get("username", "")
    password = data.get("password", "")

    token = authenticate(username, password)

    if not token:
        return {"ok": False, "error": "Invalid credentials"}

    response.set_cookie(
        key="nova_session",
        value=token,
        httponly=True,
        samesite="lax"
    )

    return {"ok": True}


@router.post("/api/logout")
async def logout(request: Request, response: Response):

    token = request.cookies.get("nova_session")

    if token:
        destroy_session(token)

    response.delete_cookie("nova_session")

    return {"ok": True}


@router.get("/api/session")
async def session(request: Request):

    token = request.cookies.get("nova_session")

    session = get_session(token)

    if not session:
        return {"ok": False}

    return {
        "ok": True,
        "username": session["username"]
    }