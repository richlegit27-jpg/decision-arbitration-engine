import json
import os
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Tuple


MEMORY_FILE = os.path.join(os.path.dirname(__file__), "runtime_memory.json")

MAX_MEMORY_ITEMS = 200
MAX_RETURN_ITEMS = 8

DEFAULT_KIND = "general"

VALID_KINDS = {
    "preference",
    "project",
    "goal",
    "workflow",
    "session",
    "general",
}

KIND_PRIORITY = {
    "preference": 100,
    "workflow": 90,
    "goal": 80,
    "project": 70,
    "session": 50,
    "general": 40,
}

PREFERENCE_HINTS = [
    "prefer",
    "always",
    "never",
    "full file",
    "full files",
    "full path",
    "full paths",
    "file path",
    "file paths",
    "notepad",
    "direct",
    "do not waste time",
    "don't waste time",
    "no unnecessary steps",
    "smff",
]

WORKFLOW_HINTS = [
    "workflow",
    "how we work",
    "go-go-go",
    "fastest path",
    "implementation first",
    "full file",
    "full files",
]

GOAL_HINTS = [
    "goal",
    "trying to",
    "working on",
    "building",
    "launch",
    "finish",
]

PROJECT_HINTS = [
    "project",
    "nova",
    "backend",
    "frontend",
    "ui",
    "routes",
    "brain",
    "agent",
    "tool",
    "memory",
]


# ---------------------------------------------------
# HELPERS
# ---------------------------------------------------

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "").strip())


def _tokenize(text: str) -> List[str]:
    return re.findall(r"[a-z0-9_]+", str(text or "").lower())


def _text_key(text: str) -> str:
    return _normalize_text(text).lower()


def _contains_any(text: str, hints: List[str]) -> bool:
    lowered = str(text or "").lower()
    return any(hint in lowered for hint in hints)


def _infer_kind(text: str) -> str:
    lowered = str(text or "").lower()

    if _contains_any(lowered, PREFERENCE_HINTS):
        return "preference"
    if _contains_any(lowered, WORKFLOW_HINTS):
        return "workflow"
    if _contains_any(lowered, GOAL_HINTS):
        return "goal"
    if _contains_any(lowered, PROJECT_HINTS):
        return "project"

    return DEFAULT_KIND


def _boost_score_for_kind(kind: str) -> int:
    return KIND_PRIORITY.get(kind, KIND_PRIORITY[DEFAULT_KIND])


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


# ---------------------------------------------------
# LOAD / SAVE
# ---------------------------------------------------

def _load_memory() -> List[Dict[str, Any]]:
    if not os.path.exists(MEMORY_FILE):
        return []

    try:
        with open(MEMORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            return []

        normalized: List[Dict[str, Any]] = []

        for item in data:
            if not isinstance(item, dict):
                continue

            text = _normalize_text(item.get("text", ""))
            if not text:
                continue

            kind = str(item.get("kind") or _infer_kind(text)).strip().lower()
            if kind not in VALID_KINDS:
                kind = DEFAULT_KIND

            normalized.append(
                {
                    "text": text,
                    "kind": kind,
                    "priority": _safe_int(item.get("priority"), _boost_score_for_kind(kind)),
                    "created_at": str(item.get("created_at") or _now_iso()),
                    "updated_at": str(item.get("updated_at") or item.get("created_at") or _now_iso()),
                    "hits": _safe_int(item.get("hits"), 0),
                }
            )

        return normalized

    except Exception:
        return []


def _save_memory(items: List[Dict[str, Any]]):
    try:
        with open(MEMORY_FILE, "w", encoding="utf-8") as f:
            json.dump(items[:MAX_MEMORY_ITEMS], f, indent=2, ensure_ascii=False)
    except Exception:
        pass


# ---------------------------------------------------
# DEDUPE / NORMALIZE
# ---------------------------------------------------

def _dedupe_items(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}

    for item in items:
        text = _normalize_text(item.get("text", ""))
        if not text:
            continue

        key = _text_key(text)
        kind = str(item.get("kind") or _infer_kind(text)).strip().lower()
        if kind not in VALID_KINDS:
            kind = DEFAULT_KIND

        priority = max(
            _safe_int(item.get("priority"), _boost_score_for_kind(kind)),
            _boost_score_for_kind(kind),
        )

        candidate = {
            "text": text,
            "kind": kind,
            "priority": priority,
            "created_at": str(item.get("created_at") or _now_iso()),
            "updated_at": str(item.get("updated_at") or _now_iso()),
            "hits": _safe_int(item.get("hits"), 0),
        }

        existing = merged.get(key)
        if not existing:
            merged[key] = candidate
            continue

        existing["priority"] = max(_safe_int(existing.get("priority"), 0), candidate["priority"])
        existing["hits"] = max(_safe_int(existing.get("hits"), 0), candidate["hits"])
        existing["updated_at"] = candidate["updated_at"]

        existing_kind = str(existing.get("kind") or DEFAULT_KIND)
        if KIND_PRIORITY.get(candidate["kind"], 0) > KIND_PRIORITY.get(existing_kind, 0):
            existing["kind"] = candidate["kind"]

    result = list(merged.values())

    result.sort(
        key=lambda item: (
            _safe_int(item.get("priority"), 0),
            _safe_int(item.get("hits"), 0),
            str(item.get("updated_at", "")),
        ),
        reverse=True,
    )

    return result[:MAX_MEMORY_ITEMS]


# ---------------------------------------------------
# RANKING
# ---------------------------------------------------

def _score_memory(query_tokens: List[str], memory_item: Dict[str, Any]) -> int:
    text = str(memory_item.get("text", ""))
    kind = str(memory_item.get("kind") or DEFAULT_KIND)

    memory_tokens = set(_tokenize(text))
    query_token_set = set(query_tokens)

    overlap = query_token_set & memory_tokens
    overlap_score = len(overlap) * 20

    phrase_bonus = 0
    lowered_text = text.lower()
    lowered_query = " ".join(query_tokens)

    if lowered_query and lowered_query in lowered_text:
        phrase_bonus += 40

    kind_bonus = _boost_score_for_kind(kind)
    hit_bonus = min(_safe_int(memory_item.get("hits"), 0) * 3, 24)

    preference_bonus = 0
    if kind == "preference":
        preference_bonus += 40

    workflow_bonus = 0
    if kind == "workflow":
        workflow_bonus += 25

    return overlap_score + phrase_bonus + kind_bonus + hit_bonus + preference_bonus + workflow_bonus


def _rank_memory_items(query: str, items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    tokens = _tokenize(query)

    if not items:
        return []

    scored: List[Tuple[int, Dict[str, Any]]] = []

    for item in items:
        score = _score_memory(tokens, item)

        if score > 0 or str(item.get("kind")) in {"preference", "workflow"}:
            scored.append((score, item))

    scored.sort(
        key=lambda pair: (
            pair[0],
            _safe_int(pair[1].get("priority"), 0),
            _safe_int(pair[1].get("hits"), 0),
            str(pair[1].get("updated_at", "")),
        ),
        reverse=True,
    )

    return [item for _, item in scored[:MAX_RETURN_ITEMS]]


# ---------------------------------------------------
# PUBLIC API
# ---------------------------------------------------

def list_memory_items() -> List[Dict[str, Any]]:
    return _dedupe_items(_load_memory())


def clear_memory_items() -> None:
    _save_memory([])


def get_relevant_memory_text(query: str) -> str:
    items = _dedupe_items(_load_memory())
    ranked = _rank_memory_items(query, items)

    if not ranked:
        return ""

    grouped: Dict[str, List[str]] = {
        "preference": [],
        "workflow": [],
        "goal": [],
        "project": [],
        "session": [],
        "general": [],
    }

    for item in ranked:
        text = _normalize_text(item.get("text", ""))
        kind = str(item.get("kind") or DEFAULT_KIND)

        if text and kind in grouped and text not in grouped[kind]:
            grouped[kind].append(text)

    lines: List[str] = []

    if grouped["preference"]:
        lines.append("Persistent user preferences:")
        for text in grouped["preference"]:
            lines.append(f"- {text}")

    if grouped["workflow"]:
        lines.append("Workflow rules:")
        for text in grouped["workflow"]:
            lines.append(f"- {text}")

    if grouped["goal"]:
        lines.append("Current goals:")
        for text in grouped["goal"]:
            lines.append(f"- {text}")

    if grouped["project"]:
        lines.append("Project facts:")
        for text in grouped["project"]:
            lines.append(f"- {text}")

    if grouped["session"]:
        lines.append("Session context:")
        for text in grouped["session"]:
            lines.append(f"- {text}")

    if grouped["general"]:
        lines.append("Other relevant memory:")
        for text in grouped["general"]:
            lines.append(f"- {text}")

    if ranked:
        all_items = _load_memory()
        keyed = {_text_key(item.get("text", "")): item for item in all_items if isinstance(item, dict)}

        for item in ranked:
            key = _text_key(item.get("text", ""))
            if key in keyed:
                keyed[key]["hits"] = _safe_int(keyed[key].get("hits"), 0) + 1
                keyed[key]["updated_at"] = _now_iso()

        _save_memory(_dedupe_items(list(keyed.values())))

    return "\n".join(lines).strip()


def update_memory_items(new_items: List[Any]):
    if not new_items:
        return

    existing = _load_memory()
    now = _now_iso()

    prepared: List[Dict[str, Any]] = list(existing)

    for item in new_items:
        if isinstance(item, str):
            text = _normalize_text(item)
            if not text:
                continue

            kind = _infer_kind(text)
            prepared.append(
                {
                    "text": text,
                    "kind": kind,
                    "priority": _boost_score_for_kind(kind),
                    "created_at": now,
                    "updated_at": now,
                    "hits": 0,
                }
            )
            continue

        if not isinstance(item, dict):
            continue

        text = _normalize_text(item.get("text", ""))
        if not text:
            continue

        kind = str(item.get("kind") or _infer_kind(text)).strip().lower()
        if kind not in VALID_KINDS:
            kind = DEFAULT_KIND

        priority = max(
            _safe_int(item.get("priority"), _boost_score_for_kind(kind)),
            _boost_score_for_kind(kind),
        )

        prepared.append(
            {
                "text": text,
                "kind": kind,
                "priority": priority,
                "created_at": str(item.get("created_at") or now),
                "updated_at": now,
                "hits": _safe_int(item.get("hits"), 0),
            }
        )

    final_items = _dedupe_items(prepared)
    _save_memory(final_items)