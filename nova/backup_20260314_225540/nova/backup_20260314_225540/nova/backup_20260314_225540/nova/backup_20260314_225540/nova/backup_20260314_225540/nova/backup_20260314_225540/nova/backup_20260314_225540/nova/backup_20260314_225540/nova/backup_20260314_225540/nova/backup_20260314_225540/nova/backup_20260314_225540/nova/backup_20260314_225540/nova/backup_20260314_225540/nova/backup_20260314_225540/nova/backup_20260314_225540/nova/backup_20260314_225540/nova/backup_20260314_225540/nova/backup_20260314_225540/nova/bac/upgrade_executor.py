from .dev_agent_tools import read_file, apply_patch


def execute_upgrade(path: str, new_code: str):

    old_code = read_file(path)

    if "ERROR" in old_code:
        return "Cannot locate file"

    result = apply_patch(path, new_code)

    return result
