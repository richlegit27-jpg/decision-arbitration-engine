import re
from typing import Any, Dict, List


# ---------------------------------------------------
# TOKEN ESTIMATION
# ---------------------------------------------------

def estimate_tokens(text: str) -> int:
    """
    Rough token estimation (≈ 4 characters per token).
    This keeps budgeting simple without importing a tokenizer.
    """
    if not text:
        return 0

    return max(1, int(len(text) / 4))


def message_tokens(message: Dict[str, Any]) -> int:
    role = str(message.get("role", ""))
    content = str(message.get("content", ""))

    return estimate_tokens(role) + estimate_tokens(content)


def total_tokens(messages: List[Dict[str, Any]]) -> int:
    return sum(message_tokens(m) for m in messages)


# ---------------------------------------------------
# BASIC TRIMMING
# ---------------------------------------------------

def trim_messages_to_budget(
    messages: List[Dict[str, Any]],
    max_tokens: int,
) -> List[Dict[str, Any]]:
    """
    Keeps system messages and newest conversation
    while respecting a token budget.
    """

    system_messages: List[Dict[str, Any]] = []
    conversation: List[Dict[str, Any]] = []

    for m in messages:
        if m.get("role") == "system":
            system_messages.append(m)
        else:
            conversation.append(m)

    result: List[Dict[str, Any]] = list(system_messages)

    running_tokens = total_tokens(result)

    # Walk newest → oldest
    for m in reversed(conversation):

        tokens = message_tokens(m)

        if running_tokens + tokens > max_tokens:
            break

        result.insert(len(system_messages), m)
        running_tokens += tokens

    return result


# ---------------------------------------------------
# PRIORITY TRIMMING
# ---------------------------------------------------

def prioritize_messages(
    messages: List[Dict[str, Any]],
    max_tokens: int,
) -> List[Dict[str, Any]]:
    """
    Keeps the most important context first.

    Priority order:

    1. system prompt
    2. workspace state
    3. relevant memory
    4. conversation summary
    5. attachment context
    6. latest conversation turns
    """

    system: List[Dict[str, Any]] = []
    workspace: List[Dict[str, Any]] = []
    memory: List[Dict[str, Any]] = []
    summary: List[Dict[str, Any]] = []
    attachments: List[Dict[str, Any]] = []
    conversation: List[Dict[str, Any]] = []

    for m in messages:

        role = m.get("role")
        content = str(m.get("content", "")).lower()

        if role != "system":
            conversation.append(m)
            continue

        if "workspace state" in content:
            workspace.append(m)

        elif "relevant memory" in content:
            memory.append(m)

        elif "conversation summary" in content:
            summary.append(m)

        elif "attachment context" in content:
            attachments.append(m)

        else:
            system.append(m)

    ordered_messages = (
        system
        + workspace
        + memory
        + summary
        + attachments
        + conversation
    )

    return trim_messages_to_budget(
        ordered_messages,
        max_tokens,
    )


# ---------------------------------------------------
# DEBUG TOOL (OPTIONAL)
# ---------------------------------------------------

def debug_context_stats(messages: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Useful for inspecting context size.
    """

    token_total = total_tokens(messages)

    return {
        "messages": len(messages),
        "estimated_tokens": token_total,
    }