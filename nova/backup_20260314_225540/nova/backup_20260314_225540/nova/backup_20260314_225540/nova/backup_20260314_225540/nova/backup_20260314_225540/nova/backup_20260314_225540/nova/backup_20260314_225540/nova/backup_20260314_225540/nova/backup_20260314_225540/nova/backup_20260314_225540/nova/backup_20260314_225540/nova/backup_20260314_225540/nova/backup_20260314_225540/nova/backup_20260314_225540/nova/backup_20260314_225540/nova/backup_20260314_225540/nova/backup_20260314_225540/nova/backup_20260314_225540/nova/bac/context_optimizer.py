from typing import List, Dict


MAX_CONTEXT_MESSAGES = 12


def optimize_context(messages: List[Dict]):

    if not messages:
        return []

    if len(messages) <= MAX_CONTEXT_MESSAGES:
        return messages

    recent = messages[-MAX_CONTEXT_MESSAGES:]

    return recent