from typing import Dict, List
import traceback


def diagnose_error(error_text: str):

    diagnostics = {
        "type": "unknown",
        "cause": "",
        "suggestion": ""
    }

    text = error_text.lower()

    if "importerror" in text:
        diagnostics["type"] = "import_error"
        diagnostics["suggestion"] = "check module path or missing file"

    elif "filenotfound" in text:
        diagnostics["type"] = "missing_file"
        diagnostics["suggestion"] = "verify file path"

    elif "attributeerror" in text:
        diagnostics["type"] = "attribute_error"
        diagnostics["suggestion"] = "check object property"

    elif "typeerror" in text:
        diagnostics["type"] = "type_error"
        diagnostics["suggestion"] = "check argument types"

    diagnostics["cause"] = error_text[:300]

    return diagnostics