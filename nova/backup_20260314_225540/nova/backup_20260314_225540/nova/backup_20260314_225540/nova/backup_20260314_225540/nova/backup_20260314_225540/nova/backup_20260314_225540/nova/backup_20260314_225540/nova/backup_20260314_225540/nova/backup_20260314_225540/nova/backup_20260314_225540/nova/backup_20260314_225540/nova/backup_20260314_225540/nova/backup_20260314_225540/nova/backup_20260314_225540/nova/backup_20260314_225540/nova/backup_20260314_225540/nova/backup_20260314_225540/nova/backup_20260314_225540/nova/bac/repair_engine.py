from .dev_agent_tools import read_file, apply_patch


def attempt_repair(path: str, new_code: str):

    old = read_file(path)

    if "ERROR" in old:
        return "Cannot repair missing file"

    result = apply_patch(path, new_code)

    return result