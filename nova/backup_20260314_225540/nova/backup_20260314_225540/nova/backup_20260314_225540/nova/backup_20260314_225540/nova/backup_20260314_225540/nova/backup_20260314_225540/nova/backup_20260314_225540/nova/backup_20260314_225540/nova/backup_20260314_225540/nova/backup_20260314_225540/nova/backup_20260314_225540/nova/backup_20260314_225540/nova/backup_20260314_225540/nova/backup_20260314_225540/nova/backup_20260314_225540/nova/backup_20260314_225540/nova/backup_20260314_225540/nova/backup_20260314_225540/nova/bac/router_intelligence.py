from __future__ import annotations

import re
from typing import Any, Dict, List


CODE_HINTS = {
    "fix",
    "bug",
    "error",
    "traceback",
    "issue",
    "broken",
    "not working",
    "login",
    "logout",
    "auth",
    "session",
    "cookie",
    "route",
    "routing",
    "api",
    "backend",
    "frontend",
    "css",
    "html",
    "js",
    "javascript",
    "python",
    "fastapi",
    "flask",
    "template",
    "file",
    "path",
    "import",
    "module",
    "server",
    "endpoint",
    "upload",
    "attachment",
    "memory",
    "sidebar",
    "button",
    "ui",
    "layout",
    "chat",
    "brain",
    "index.html",
    "main.py",
}

MEMORY_HINTS = {
    "remember",
    "memory",
    "you said before",
    "last time",
    "earlier",
    "previous",
    "we already did",
    "from before",
    "what did we do",
    "what did you say",
}

SEARCH_HINTS = {
    "compare",
    "summarize",
    "analyze",
    "search",
    "find",
    "look for",
    "scan",
    "check",
    "trace",
    "debug",
}

FILE_HINTS = {
    ".py",
    ".js",
    ".css",
    ".html",
    ".json",
    ".md",
    ".txt",
    ".yml",
    ".yaml",
    ".ts",
    ".tsx",
}


def _normalize_text(value: str) -> str:
    return (value or "").strip()


def _tokenize(text: str) -> List[str]:
    return re.findall(r"[a-zA-Z0-9_\-./:]+", (text or "").lower())


def _contains_phrase(text: str, phrases: set[str]) -> bool:
    lowered = (text or "").lower()
    return any(phrase in lowered for phrase in phrases)


def _has_file_hint(text: str) -> bool:
    lowered = (text or "").lower()
    return any(ext in lowered for ext in FILE_HINTS)


def _has_code_hint(text: str) -> bool:
    lowered = (text or "").lower()
    return any(hint in lowered for hint in CODE_HINTS)


def _has_search_hint(text: str) -> bool:
    lowered = (text or "").lower()
    return any(hint in lowered for hint in SEARCH_HINTS)


def _attachment_names(attachments: List[Dict[str, Any]]) -> List[str]:
    names: List[str] = []

    for item in attachments or []:
        if not isinstance(item, dict):
            continue

        for key in ("name", "filename", "file_name", "path"):
            value = item.get(key)
            if value:
                names.append(str(value))
                break

    return names


def classify_request(user_text: str, attachments: List[Dict[str, Any]] | None = None) -> Dict[str, Any]:
    text = _normalize_text(user_text)
    lowered = text.lower()
    tokens = _tokenize(text)
    attachments = attachments or []
    attachment_names = _attachment_names(attachments)

    mode = "chat"
    needs_memory = False
    needs_file_context = False
    needs_search = False
    needs_task_plan = False
    needs_code_focus = False

    if _contains_phrase(lowered, MEMORY_HINTS):
        needs_memory = True

    if _has_code_hint(lowered):
        mode = "code"
        needs_file_context = True
        needs_search = True
        needs_code_focus = True

    if _has_file_hint(lowered):
        needs_file_context = True

    if attachments:
        needs_file_context = True
        needs_search = True

    if attachment_names and any(_has_file_hint(name) for name in attachment_names):
        mode = "code"
        needs_code_focus = True

    if _has_search_hint(lowered):
        needs_search = True
        needs_task_plan = True

    if any(word in lowered for word in {"step-by-step", "steps", "plan", "todo", "next"}):
        needs_task_plan = True

    if any(word in lowered for word in {"fix", "repair", "patch", "broken", "error", "traceback"}):
        mode = "code"
        needs_code_focus = True
        needs_file_context = True
        needs_search = True

    priority_terms = search_terms_for_request(text)

    return {
        "mode": mode,
        "needs_memory": needs_memory,
        "needs_file_context": needs_file_context,
        "needs_search": needs_search,
        "needs_task_plan": needs_task_plan,
        "needs_code_focus": needs_code_focus,
        "tokens": tokens,
        "priority_terms": priority_terms,
        "attachment_names": attachment_names,
    }


def search_terms_for_request(user_text: str) -> List[str]:
    text = _normalize_text(user_text)
    tokens = _tokenize(text)

    stop_words = {
        "the",
        "a",
        "an",
        "and",
        "or",
        "to",
        "for",
        "of",
        "in",
        "on",
        "at",
        "it",
        "this",
        "that",
        "is",
        "are",
        "be",
        "with",
        "from",
        "before",
        "thing",
        "stuff",
        "please",
        "just",
        "now",
        "then",
        "than",
        "into",
        "onto",
        "about",
        "next",
        "help",
        "me",
        "we",
        "you",
        "our",
    }

    ranked: List[str] = []
    seen: set[str] = set()

    for token in tokens:
        if token in stop_words:
            continue
        if len(token) < 3:
            continue
        if token in seen:
            continue
        ranked.append(token)
        seen.add(token)

    return ranked[:12]


def build_request_planning_block(profile: Dict[str, Any], search_terms: List[str]) -> str:
    mode = str(profile.get("mode") or "chat").strip()
    needs_memory = bool(profile.get("needs_memory"))
    needs_file_context = bool(profile.get("needs_file_context"))
    needs_search = bool(profile.get("needs_search"))
    needs_task_plan = bool(profile.get("needs_task_plan"))
    needs_code_focus = bool(profile.get("needs_code_focus"))
    attachment_names = profile.get("attachment_names") or []

    lines = [
        "You are answering inside Nova.",
        f"REQUEST MODE: {mode}",
        f"NEEDS MEMORY: {'yes' if needs_memory else 'no'}",
        f"NEEDS FILE CONTEXT: {'yes' if needs_file_context else 'no'}",
        f"NEEDS SEARCH: {'yes' if needs_search else 'no'}",
        f"NEEDS TASK PLAN: {'yes' if needs_task_plan else 'no'}",
        f"NEEDS CODE FOCUS: {'yes' if needs_code_focus else 'no'}",
        f"SEARCH TERMS: {', '.join(search_terms) if search_terms else 'none'}",
        f"ATTACHMENTS: {', '.join(attachment_names) if attachment_names else 'none'}",
        "",
        "Rules:",
        "- Be direct.",
        "- Prefer concrete fixes over theory.",
        "- Use relevant prior context when the request refers to earlier work.",
        "- When debugging, prioritize root cause and exact file changes.",
        "- Avoid vague filler.",
    ]

    return "\n".join(lines).strip()