from .autonomous_builder import generate_upgrade_plan
from .workspace_intelligence import get_project_structure


def run_builder():

    structure = get_project_structure()

    plan = generate_upgrade_plan(structure)

    return plan