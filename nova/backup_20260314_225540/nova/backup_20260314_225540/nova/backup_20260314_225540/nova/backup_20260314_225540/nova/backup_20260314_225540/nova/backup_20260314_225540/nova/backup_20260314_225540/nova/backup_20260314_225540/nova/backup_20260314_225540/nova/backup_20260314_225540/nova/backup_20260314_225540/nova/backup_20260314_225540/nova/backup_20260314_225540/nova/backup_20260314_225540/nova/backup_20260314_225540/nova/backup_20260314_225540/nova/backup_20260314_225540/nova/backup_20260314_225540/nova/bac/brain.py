from __future__ import annotations

import re
import traceback
from typing import Any, Dict, List, Optional

from .answer_actions import build_answer_actions
from .config import OPENAI_MAX_TOKENS, OPENAI_MODEL
from .file_context import build_uploaded_file_context
from .memory_store import get_relevant_memory_text, update_memory_items
from .openai_service import (
    extract_image_payload,
    extract_response_text,
    has_openai,
    openai_chat,
    openai_generate_image,
)
from .project_search import search_project
from .router_intelligence import classify_request
from .web_search import has_web_search, search_web_context
from .workspace_state import build_workspace_context, update_workspace_state

SYSTEM_PROMPT = """
You are Nova, an engineering workspace AI.

Your job is to help build, debug, and ship software quickly.

Behavior rules:
- Assume the user wants execution, not clarification.
- When the user says fix, debug, or references a file, start diagnosing immediately.
- Do not ask basic clarification questions unless absolutely required.
- Provide concrete next steps, code fixes, or analysis.
- Treat file names, logs, and code as actionable debugging targets.
- Use uploaded file contents when available and ground your answer in them.
- Use project search context when available and ground your answer in it.
- Use web search context when available for current facts, libraries, APIs, releases, docs, and recent changes.
- Keep responses direct and practical.
- Prefer the most likely cause and next action over vague discussion.
- Prefer repo-grounded answers for repo questions.
- Prefer web-grounded answers for current-world questions.
- When possible, include likely cause, next action, suggested files, and a patch target.

Response style:
- Be direct.
- Prefer solutions over explanations.
- If uncertain, propose the most likely cause and investigation steps.
""".strip()

IMAGE_COMMAND_PATTERN = re.compile(r"^\s*/image\s+(.+?)\s*$", flags=re.IGNORECASE | re.DOTALL)
SEARCH_WORD_PATTERN = re.compile(r"[A-Za-z0-9_\-\.]{3,}")


def _fallback_reply(user_text: str) -> str:
    text = (user_text or "").strip().lower()

    if not text:
        return "Message is required."

    if text in {"hi", "hello", "hey"}:
        return "Nova here. What are we building?"

    if "login" in text and "fix" in text:
        return "Bypass auth until workspace is stable."

    if text == "next":
        return "Next: structured answer actions, then UI rendering for operator output."

    if "memory" in text:
        return "Memory matters, but launch stability matters first."

    if text.startswith("/image "):
        return "Image generation is not available because OpenAI is not configured."

    return f"Nova fallback mode active. Got: {user_text}"


def _extract_image_prompt(user_text: str) -> str:
    text = str(user_text or "")
    match = IMAGE_COMMAND_PATTERN.match(text)
    if not match:
        return ""
    return str(match.group(1) or "").strip()


def _extract_attachment_names(user_text: str) -> List[Dict[str, Any]]:
    text = str(user_text or "").strip()
    if not text:
        return []

    match = re.search(r"attached files:\s*(.+)", text, flags=re.IGNORECASE)
    if not match:
        return []

    tail = match.group(1).strip()
    if not tail:
        return []

    names: List[Dict[str, Any]] = []
    for raw in tail.split(","):
        cleaned = str(raw or "").strip()
        if cleaned:
            names.append({"name": cleaned})

    return names


def _extract_search_terms(user_text: str, candidate_file_names: List[str]) -> List[str]:
    text = str(user_text or "").strip()
    if not text:
        return []

    preferred_terms: List[str] = []
    seen = set()

    for name in candidate_file_names:
        clean = str(name or "").strip()
        lowered = clean.lower()
        if clean and lowered not in seen:
            seen.add(lowered)
            preferred_terms.append(clean)

    lowered_text = text.lower()

    boosted_words = [
        "login",
        "logout",
        "auth",
        "session",
        "memory",
        "files",
        "attachment",
        "composer",
        "sidebar",
        "panel",
        "chat",
        "model",
        "openai",
        "voice",
        "image",
        "send",
        "messages",
        "template",
        "static",
        "api",
    ]

    for word in boosted_words:
        if word in lowered_text and word not in seen:
            seen.add(word)
            preferred_terms.append(word)

    for token in SEARCH_WORD_PATTERN.findall(text):
        clean = str(token or "").strip().lower()
        if (
            clean
            and clean not in seen
            and clean not in {
                "the",
                "and",
                "for",
                "with",
                "from",
                "that",
                "this",
                "then",
                "next",
                "just",
                "into",
                "your",
                "have",
                "what",
                "when",
                "where",
                "which",
                "would",
                "should",
                "could",
            }
        ):
            seen.add(clean)
            preferred_terms.append(clean)

    return preferred_terms[:6]


def _build_project_search_context(user_text: str, candidate_file_names: List[str], enabled: bool) -> str:
    if not enabled:
        return ""

    terms = _extract_search_terms(user_text, candidate_file_names)
    if not terms:
        return ""

    lines: List[str] = []
    seen_files = set()

    for term in terms:
        try:
            matches = search_project(term, max_results=5)
        except Exception:
            continue

        if not matches:
            continue

        lines.append(f"Search term: {term}")

        for match in matches:
            rel_file = str(match.get("file") or "").strip()
            snippet = str(match.get("snippet") or "").strip()

            if not rel_file:
                continue

            if rel_file.lower() in seen_files:
                continue

            seen_files.add(rel_file.lower())
            compact_snippet = " ".join(snippet.split())
            lines.append(f"- {rel_file}: {compact_snippet[:300]}")

        if len(seen_files) >= 10:
            break

    return "\n".join(lines).strip()


def _build_web_search_context(user_text: str, enabled: bool) -> str:
    if not enabled:
        return ""

    if not has_web_search():
        return ""

    return search_web_context(user_text, max_results=5)


def _build_messages(
    user_text: str,
    history: Optional[List[Dict[str, str]]] = None,
    memory_text: Optional[str] = None,
    workspace_text: Optional[str] = None,
    uploaded_file_text: Optional[str] = None,
    project_search_text: Optional[str] = None,
    web_search_text: Optional[str] = None,
) -> List[Dict[str, str]]:
    messages: List[Dict[str, str]] = [
        {"role": "system", "content": SYSTEM_PROMPT}
    ]

    if memory_text:
        messages.append({"role": "system", "content": f"Memory context:\n{memory_text}"})

    if workspace_text:
        messages.append({"role": "system", "content": f"Workspace context:\n{workspace_text}"})

    if uploaded_file_text:
        messages.append({"role": "system", "content": f"Uploaded file context:\n{uploaded_file_text}"})

    if project_search_text:
        messages.append({"role": "system", "content": f"Project search context:\n{project_search_text}"})

    if web_search_text:
        messages.append({"role": "system", "content": f"Web search context:\n{web_search_text}"})

    for item in history or []:
        role = str(item.get("role", "user")).strip()
        content = str(item.get("content", "")).strip()

        if not content:
            continue

        if role not in {"system", "user", "assistant"}:
            role = "user"

        messages.append({"role": role, "content": content})

    messages.append({"role": "user", "content": user_text})
    return messages


def _build_memory_updates(user_text: str, assistant_reply: str) -> List[Dict[str, Any]]:
    updates: List[Dict[str, Any]] = []

    clean_user = str(user_text or "").strip()
    clean_reply = str(assistant_reply or "").strip()

    if not clean_user:
        return updates

    lowered = clean_user.lower()

    explicit_memory = (
        lowered.startswith("remember ")
        or lowered.startswith("remember that")
        or lowered.startswith("note that")
        or "my preference" in lowered
    )

    preference_memory = any(token in lowered for token in [
        "prefer",
        "always",
        "never",
        "full file",
        "full files",
        "full path",
        "file path",
        "notepad",
        "smff",
        "powershell",
        "don't waste time",
        "do not waste time",
        "no unnecessary steps",
    ])

    if explicit_memory:
        updates.append({
            "text": clean_user,
            "kind": "general",
        })
    elif preference_memory:
        updates.append({
            "text": clean_user,
            "kind": "preference",
        })
    else:
        updates.append({
            "text": clean_user,
            "kind": "session",
        })

    attachment_names = _extract_attachment_names(clean_user)
    for item in attachment_names:
        name = str(item.get("name") or "").strip()
        if name:
            updates.append({
                "text": f"Attached files: {name}",
                "kind": "session",
            })

    if clean_reply and clean_reply.lower().startswith("next:"):
        updates.append({
            "text": clean_reply,
            "kind": "workflow",
        })

    return updates


def _build_image_reply_markup(prompt: str, image_src: str) -> str:
    safe_prompt = str(prompt or "").strip()
    safe_src = str(image_src or "").strip()
    return f"[[image]]\nsrc: {safe_src}\nprompt: {safe_prompt}"


def _process_image_turn(
    *,
    user_text: str,
    mode: str,
    attachments: List[Dict[str, Any]],
    candidate_file_names: List[str],
) -> Dict[str, Any]:
    prompt = _extract_image_prompt(user_text)
    if not prompt:
        return {"reply": "Image prompt is required. Use /image followed by a prompt."}

    if not has_openai():
        reply = "Image generation is not available because OpenAI is not configured."
        update_memory_items(_build_memory_updates(user_text, reply))
        updated_workspace = update_workspace_state(
            user_message=user_text,
            assistant_message=reply,
            attachments=attachments,
            mode=mode,
        )
        return {
            "reply": reply,
            "used_memory": None,
            "workspace_context": build_workspace_context(),
            "workspace_state": updated_workspace,
            "mode": mode,
            "used_uploaded_files": candidate_file_names,
            "used_project_search": None,
            "used_web_search": None,
            "answer_actions": None,
            "selected_model": None,
        }

    try:
        response = openai_generate_image(prompt=prompt)
        image_payload = extract_image_payload(response)

        image_url = str(image_payload.get("image_url") or "").strip()
        b64_json = str(image_payload.get("b64_json") or "").strip()
        revised_prompt = str(image_payload.get("revised_prompt") or prompt).strip()

        image_src = ""
        if image_url:
            image_src = image_url
        elif b64_json:
            image_src = f"data:image/png;base64,{b64_json}"

        if not image_src:
            raise RuntimeError("Image generation returned no image payload.")

        reply = _build_image_reply_markup(revised_prompt, image_src)

        update_memory_items(_build_memory_updates(user_text, "Generated image"))
        updated_workspace = update_workspace_state(
            user_message=user_text,
            assistant_message=f"Generated image for prompt: {revised_prompt}",
            attachments=attachments,
            mode=mode,
        )

        return {
            "reply": reply,
            "used_memory": None,
            "workspace_context": build_workspace_context(),
            "workspace_state": updated_workspace,
            "mode": mode,
            "used_uploaded_files": candidate_file_names,
            "used_project_search": None,
            "used_web_search": None,
            "answer_actions": None,
            "selected_model": None,
            "image_url": image_url or None,
            "image_prompt": revised_prompt,
        }
    except Exception as exc:
        error_reply = f"Nova image error: {exc}"

        try:
            update_workspace_state(
                user_message=user_text,
                assistant_message=error_reply,
                attachments=attachments,
                mode="image",
            )
        except Exception:
            pass

        return {
            "reply": error_reply,
            "error_trace": traceback.format_exc(),
            "used_memory": None,
            "workspace_context": None,
            "workspace_state": None,
            "mode": "image",
            "used_uploaded_files": candidate_file_names,
            "used_project_search": None,
            "used_web_search": None,
            "answer_actions": None,
            "selected_model": None,
        }


def process_chat_turn(
    user_text: str,
    history: Optional[List[Dict[str, str]]] = None,
    workspace_state: Optional[Dict[str, Any]] = None,
    model: Optional[str] = None,
) -> Dict[str, Any]:
    text = (user_text or "").strip()

    if not text:
        return {"reply": "Message is required."}

    selected_model = str(model or OPENAI_MODEL).strip() or OPENAI_MODEL
    route = classify_request(text)
    mode = str(route.get("mode") or "chat")
    attachments = _extract_attachment_names(text)
    candidate_file_names = list(route.get("candidate_file_names") or [])

    uploaded_file_text = ""
    if route.get("use_uploaded_files"):
        uploaded_file_text = build_uploaded_file_context(
            candidate_file_names,
            max_files=3,
            max_chars_per_file=5000,
        )

    project_search_text = _build_project_search_context(
        text,
        candidate_file_names,
        enabled=bool(route.get("use_project_search")),
    )

    web_search_text = _build_web_search_context(
        text,
        enabled=bool(route.get("use_web_search")),
    )

    if mode == "image":
        return _process_image_turn(
            user_text=text,
            mode=mode,
            attachments=attachments,
            candidate_file_names=candidate_file_names,
        )

    if not has_openai():
        reply = _fallback_reply(text)

        update_memory_items(_build_memory_updates(text, reply))
        updated_workspace = update_workspace_state(
            user_message=text,
            assistant_message=reply,
            attachments=attachments,
            mode=mode,
        )

        answer_actions = build_answer_actions(
            user_text=text,
            reply=reply,
            route=route,
            project_search_text=project_search_text,
            uploaded_file_text=uploaded_file_text,
            web_search_text=web_search_text,
        )

        return {
            "reply": reply,
            "used_memory": None,
            "workspace_context": build_workspace_context(),
            "workspace_state": updated_workspace,
            "mode": mode,
            "used_uploaded_files": candidate_file_names,
            "used_project_search": project_search_text or None,
            "used_web_search": web_search_text or None,
            "route": route,
            "answer_actions": answer_actions,
            "selected_model": selected_model,
        }

    try:
        memory_text = get_relevant_memory_text(text)
        workspace_text = build_workspace_context()

        messages = _build_messages(
            text,
            history=history,
            memory_text=memory_text,
            workspace_text=workspace_text,
            uploaded_file_text=uploaded_file_text,
            project_search_text=project_search_text,
            web_search_text=web_search_text,
        )

        response = openai_chat(
            model=selected_model,
            messages=messages,
            max_tokens=OPENAI_MAX_TOKENS,
        )

        reply = extract_response_text(response).strip()
        if not reply:
            reply = "Nova returned an empty response."

        update_memory_items(_build_memory_updates(text, reply))

        updated_workspace = update_workspace_state(
            user_message=text,
            assistant_message=reply,
            attachments=attachments,
            mode=mode,
        )

        answer_actions = build_answer_actions(
            user_text=text,
            reply=reply,
            route=route,
            project_search_text=project_search_text,
            uploaded_file_text=uploaded_file_text,
            web_search_text=web_search_text,
        )

        return {
            "reply": reply,
            "used_memory": memory_text,
            "workspace_context": build_workspace_context(),
            "workspace_state": updated_workspace,
            "mode": mode,
            "used_uploaded_files": candidate_file_names,
            "used_project_search": project_search_text or None,
            "used_web_search": web_search_text or None,
            "route": route,
            "answer_actions": answer_actions,
            "selected_model": selected_model,
        }

    except Exception as exc:
        error_reply = f"Nova AI error: {exc}"

        try:
            update_workspace_state(
                user_message=text,
                assistant_message=error_reply,
                attachments=attachments,
                mode="debug",
            )
        except Exception:
            pass

        answer_actions = build_answer_actions(
            user_text=text,
            reply=error_reply,
            route=route,
            project_search_text=project_search_text,
            uploaded_file_text=uploaded_file_text,
            web_search_text=web_search_text,
        )

        return {
            "reply": error_reply,
            "error_trace": traceback.format_exc(),
            "used_memory": None,
            "workspace_context": None,
            "workspace_state": None,
            "mode": "debug",
            "used_uploaded_files": candidate_file_names,
            "used_project_search": project_search_text or None,
            "used_web_search": web_search_text or None,
            "route": route,
            "answer_actions": answer_actions,
            "selected_model": selected_model,
        }