import os
import json
from typing import List, Dict

MEMORY_FILE = r"C:\Users\Owner\nova\runtime\strategic_memory.json"

MAX_MEMORY_ITEMS = 50


def _load():

    if not os.path.exists(MEMORY_FILE):
        return []

    try:
        with open(MEMORY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _save(data):

    os.makedirs(os.path.dirname(MEMORY_FILE), exist_ok=True)

    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def add_memory(text: str):

    items = _load()

    items.append({
        "text": text
    })

    if len(items) > MAX_MEMORY_ITEMS:
        items = items[-MAX_MEMORY_ITEMS:]

    _save(items)


def get_memory() -> List[Dict]:

    return _load()