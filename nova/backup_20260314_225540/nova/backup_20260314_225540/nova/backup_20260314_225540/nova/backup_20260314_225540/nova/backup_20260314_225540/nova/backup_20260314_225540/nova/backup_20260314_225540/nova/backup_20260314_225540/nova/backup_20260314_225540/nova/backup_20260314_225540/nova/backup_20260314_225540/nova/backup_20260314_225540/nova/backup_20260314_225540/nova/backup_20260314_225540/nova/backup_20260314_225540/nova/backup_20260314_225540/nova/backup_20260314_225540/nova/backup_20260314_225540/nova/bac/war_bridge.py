from .war_mode_engine import run_war_mode
from .competition_analyzer import analyze_competition
from .upgrade_planner import generate_upgrade_plan


def run_war_analysis(messages):

    war_output = run_war_mode(messages)

    competitors = analyze_competition()

    upgrades = generate_upgrade_plan()

    return {
        "strategy": war_output,
        "competition": competitors,
        "upgrade_plan": upgrades
    }