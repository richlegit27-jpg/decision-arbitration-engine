from .self_improvement_engine import (
    record_interaction,
    get_adaptive_prompt,
)


def inject_adaptive_prompt(system_prompt: str):

    adaptive = get_adaptive_prompt()

    if not adaptive:
        return system_prompt

    return f"{system_prompt}\n\nSYSTEM IMPROVEMENTS:\n{adaptive}"


def record_after_response(user_text: str, assistant_text: str):

    record_interaction(user_text, assistant_text)