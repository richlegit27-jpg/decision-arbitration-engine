from typing import List, Dict

from .openai_service import openai_chat, extract_response_text
from .config import OPENAI_MODEL


BUILDER_PROMPT = """
You are Nova's Autonomous Builder.

Your job is to improve the Nova system.

When given the current architecture you should:

1. identify weaknesses
2. propose system upgrades
3. generate implementation steps
4. recommend files to modify

Focus on:
- performance
- reliability
- developer productivity
- competitive advantage

Return your answer as:

UPGRADE IDEA
WHY IT MATTERS
IMPLEMENTATION STEPS
FILES TO MODIFY
"""


def generate_upgrade_plan(system_description: str):

    response = openai_chat(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": BUILDER_PROMPT},
            {"role": "user", "content": system_description}
        ]
    )

    return extract_response_text(response)