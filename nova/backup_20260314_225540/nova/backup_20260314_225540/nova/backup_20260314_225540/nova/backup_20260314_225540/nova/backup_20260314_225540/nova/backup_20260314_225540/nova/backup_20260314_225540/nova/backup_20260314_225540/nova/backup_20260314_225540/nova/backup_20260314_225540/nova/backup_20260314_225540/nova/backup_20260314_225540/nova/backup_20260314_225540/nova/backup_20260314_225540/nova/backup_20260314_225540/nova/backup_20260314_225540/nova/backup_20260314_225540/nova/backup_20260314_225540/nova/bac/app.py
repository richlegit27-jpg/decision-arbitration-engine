from fastapi import FastAPI, Request, UploadFile, File
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os, uuid

app = FastAPI()

# Serve static files
app.mount("/static", StaticFiles(directory="..\\static"), name="static")
templates = Jinja2Templates(directory="..\\templates")

# In-memory store
store = {
    "chats": [],
    "messages": {},
    "memoryItems": [],
    "pendingAttachments": []
}

# --------- API ---------
@app.get("/")
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api/chats")
async def get_chats():
    return {"chats": store["chats"]}

@app.post("/api/chats")
async def create_chat():
    chat_id = str(uuid.uuid4())
    store["chats"].append({"id": chat_id, "title": "New Chat"})
    store["messages"][chat_id] = []
    return {"id": chat_id, "title": "New Chat"}

@app.delete("/api/chats/{chat_id}")
async def del_chat(chat_id: str):
    store["chats"] = [c for c in store["chats"] if c["id"] != chat_id]
    store["messages"].pop(chat_id, None)
    return {"ok": True}

@app.get("/api/messages/{chat_id}")
async def get_messages(chat_id: str):
    return {"messages": store["messages"].get(chat_id, [])}

@app.post("/api/messages/{chat_id}")
async def post_message(chat_id: str, request: Request):
    body = await request.json()
    msg = {"id": str(uuid.uuid4()), "role": body.get("role"), "content": body.get("content")}
    store["messages"][chat_id].append(msg)
    return msg

@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    os.makedirs("..\\uploads", exist_ok=True)
    filename = f"{uuid.uuid4()}-{file.filename}"
    filepath = os.path.join("..\\uploads", filename)
    with open(filepath, "wb") as f:
        f.write(await file.read())
    return {"name": filename, "path": filepath}

@app.post("/api/logout")
async def logout():
    store["chats"].clear()
    store["messages"].clear()
    store["memoryItems"].clear()
    store["pendingAttachments"].clear()
    return {"ok": True}

@app.get("/api/memory")
async def get_memory():
    return {"memoryItems": store["memoryItems"]}

@app.post("/api/memory")
async def save_memory(request: Request):
    body = await request.json()
    store["memoryItems"].append(body.get("text"))
    return {"ok": True}