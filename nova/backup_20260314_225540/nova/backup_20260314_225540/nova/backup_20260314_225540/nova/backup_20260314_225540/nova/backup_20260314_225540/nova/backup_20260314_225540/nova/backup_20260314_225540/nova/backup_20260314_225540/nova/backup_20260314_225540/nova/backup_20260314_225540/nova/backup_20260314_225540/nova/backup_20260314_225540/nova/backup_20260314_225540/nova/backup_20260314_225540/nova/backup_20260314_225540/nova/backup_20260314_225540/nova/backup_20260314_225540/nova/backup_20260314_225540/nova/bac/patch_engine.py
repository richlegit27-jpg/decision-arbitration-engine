import os
import difflib

PROJECT_ROOT = r"C:\Users\Owner\nova"


def _safe_path(path: str) -> str:
    full = os.path.abspath(os.path.join(PROJECT_ROOT, path))

    if not full.startswith(PROJECT_ROOT):
        raise Exception("Invalid path outside project")

    return full


def read_file(path: str) -> str:
    full = _safe_path(path)

    try:
        with open(full, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as e:
        return f"ERROR reading file: {e}"


def apply_patch(path: str, new_content: str) -> str:
    full = _safe_path(path)

    if not os.path.exists(full):
        return "ERROR file does not exist"

    try:
        with open(full, "r", encoding="utf-8", errors="ignore") as f:
            old_content = f.read()

        diff = difflib.unified_diff(
            old_content.splitlines(),
            new_content.splitlines(),
            fromfile="old",
            tofile="new",
            lineterm=""
        )

        diff_text = "\n".join(diff)

        with open(full, "w", encoding="utf-8") as f:
            f.write(new_content)

        return f"PATCH APPLIED\n\n{diff_text}"

    except Exception as e:
        return f"ERROR applying patch: {e}"