from typing import Any, Dict, List

from .openai_service import openai_summarize_messages


# ---------------------------------------------------
# STRUCTURED SUMMARY TEMPLATE
# ---------------------------------------------------

SUMMARY_TEMPLATE = """
Summarize the conversation state using the structure below.

Return concise fields.

goal:
current_task:
decisions:
files_involved:
open_problems:
recent_progress:
next_step:
"""


# ---------------------------------------------------
# BUILD STRUCTURED SUMMARY
# ---------------------------------------------------

def build_structured_summary(messages: List[Dict[str, Any]]) -> str:

    if not messages:
        return ""

    # Convert messages into compact text
    lines = []

    for m in messages:

        role = m.get("role", "")
        content = m.get("content", "")

        if not content:
            continue

        lines.append(f"{role}: {content}")

    conversation_text = "\n".join(lines)

    prompt_messages = [
        {
            "role": "system",
            "content": SUMMARY_TEMPLATE,
        },
        {
            "role": "user",
            "content": conversation_text,
        },
    ]

    summary = openai_summarize_messages(prompt_messages)

    return summary


# ---------------------------------------------------
# MERGE SUMMARY
# ---------------------------------------------------

def merge_summary(old_summary: str, new_summary: str) -> str:

    if not old_summary:
        return new_summary

    return f"{old_summary}\n\n{new_summary}"


# ---------------------------------------------------
# SAFE SUMMARY BUILD
# ---------------------------------------------------

def safe_build_summary(messages: List[Dict[str, Any]]) -> str:

    try:

        return build_structured_summary(messages)

    except Exception:

        # Fallback summary if model fails
        if not messages:
            return ""

        last_messages = messages[-10:]

        lines = []

        for m in last_messages:

            role = m.get("role", "")
            content = m.get("content", "")

            if content:
                lines.append(f"{role}: {content[:120]}")

        return "Recent conversation summary:\n" + "\n".join(lines)