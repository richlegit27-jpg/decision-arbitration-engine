import os
import json
from typing import List, Dict

TASK_FILE = r"C:\Users\Owner\nova\runtime\tasks.json"


def _load():

    if not os.path.exists(TASK_FILE):
        return []

    try:
        with open(TASK_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _save(data):

    os.makedirs(os.path.dirname(TASK_FILE), exist_ok=True)

    with open(TASK_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def create_task(goal: str, steps: List[str]):

    tasks = _load()

    task = {
        "id": len(tasks) + 1,
        "goal": goal,
        "steps": [
            {"step": s, "done": False} for s in steps
        ]
    }

    tasks.append(task)

    _save(tasks)

    return task


def get_tasks():

    return _load()


def complete_step(task_id: int, step_index: int):

    tasks = _load()

    for task in tasks:

        if task["id"] == task_id:

            if step_index < len(task["steps"]):
                task["steps"][step_index]["done"] = True

    _save(tasks)

    return tasks