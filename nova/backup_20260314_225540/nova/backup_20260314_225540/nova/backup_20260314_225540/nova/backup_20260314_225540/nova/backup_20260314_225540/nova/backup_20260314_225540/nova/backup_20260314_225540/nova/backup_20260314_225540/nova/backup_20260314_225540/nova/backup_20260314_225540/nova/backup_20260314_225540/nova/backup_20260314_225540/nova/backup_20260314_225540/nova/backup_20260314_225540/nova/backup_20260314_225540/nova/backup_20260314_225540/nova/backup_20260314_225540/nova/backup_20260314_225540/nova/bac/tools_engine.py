import os
from typing import Any, Callable, Dict, List


BASE_WORKSPACE = os.getenv("NOVA_WORKSPACE", r"C:\Users\Owner\nova")


# ---------------------------------------------------
# PATH SAFETY
# ---------------------------------------------------

def _workspace_root() -> str:
    return os.path.abspath(BASE_WORKSPACE)


def _safe_path(path: str) -> str:
    if not isinstance(path, str) or not path.strip():
        raise ValueError("Path is required")

    normalized = os.path.abspath(os.path.normpath(path))
    base = _workspace_root()

    try:
        common = os.path.commonpath([normalized, base])
    except ValueError:
        raise ValueError("Invalid path")

    if common != base:
        raise ValueError("Path outside workspace")

    return normalized


# ---------------------------------------------------
# READ FILE
# ---------------------------------------------------

def read_file(path: str) -> Dict[str, Any]:
    try:
        full = _safe_path(path)

        if not os.path.exists(full):
            return {"ok": False, "error": "File not found"}

        if os.path.isdir(full):
            return {"ok": False, "error": "Path is a directory, not a file"}

        with open(full, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        return {
            "ok": True,
            "path": full,
            "content": content,
        }

    except Exception as e:
        return {"ok": False, "error": str(e)}


# ---------------------------------------------------
# WRITE FILE
# ---------------------------------------------------

def write_file(path: str, content: str) -> Dict[str, Any]:
    try:
        full = _safe_path(path)

        parent = os.path.dirname(full)
        if parent:
            os.makedirs(parent, exist_ok=True)

        with open(full, "w", encoding="utf-8") as f:
            f.write(content if content is not None else "")

        return {
            "ok": True,
            "path": full,
            "bytes_written": len((content if content is not None else "").encode("utf-8")),
        }

    except Exception as e:
        return {"ok": False, "error": str(e)}


# ---------------------------------------------------
# LIST FILES
# ---------------------------------------------------

def list_files(path: str) -> Dict[str, Any]:
    try:
        full = _safe_path(path)

        if not os.path.exists(full):
            return {"ok": False, "error": "Path not found"}

        if not os.path.isdir(full):
            return {"ok": False, "error": "Path is not a directory"}

        items: List[Dict[str, Any]] = []

        for name in sorted(os.listdir(full), key=lambda value: value.lower()):
            p = os.path.join(full, name)

            items.append(
                {
                    "name": name,
                    "path": p,
                    "type": "dir" if os.path.isdir(p) else "file",
                }
            )

        return {
            "ok": True,
            "path": full,
            "items": items,
            "count": len(items),
        }

    except Exception as e:
        return {"ok": False, "error": str(e)}


# ---------------------------------------------------
# TOOL REGISTRY
# ---------------------------------------------------

ToolHandler = Callable[..., Dict[str, Any]]

TOOLS: Dict[str, ToolHandler] = {
    "read_file": read_file,
    "write_file": write_file,
    "list_files": list_files,
}


def get_available_tools() -> Dict[str, Any]:
    return {
        "ok": True,
        "tools": sorted(TOOLS.keys()),
    }


# ---------------------------------------------------
# TOOL EXECUTION
# ---------------------------------------------------

def execute_tool(name: str, args: Dict[str, Any] | None = None) -> Dict[str, Any]:
    try:
        if not isinstance(name, str) or not name.strip():
            return {"ok": False, "error": "Tool name is required"}

        tool_name = name.strip()
        tool_args = args or {}

        if tool_name not in TOOLS:
            return {
                "ok": False,
                "error": f"Unknown tool: {tool_name}",
                "available_tools": sorted(TOOLS.keys()),
            }

        if not isinstance(tool_args, dict):
            return {"ok": False, "error": "Tool args must be an object"}

        handler = TOOLS[tool_name]
        result = handler(**tool_args)

        if not isinstance(result, dict):
            return {
                "ok": False,
                "error": f"Tool returned invalid result: {tool_name}",
            }

        return {
            "tool": tool_name,
            **result,
        }

    except TypeError as e:
        return {
            "ok": False,
            "error": f"Invalid arguments for tool '{name}': {str(e)}",
        }
    except Exception as e:
        return {
            "ok": False,
            "error": str(e),
        }


# ---------------------------------------------------
# TOOL SCHEMAS
# ---------------------------------------------------

def get_tool_schemas() -> List[Dict[str, Any]]:
    return [
        {
            "name": "read_file",
            "description": "Read a UTF-8 text file from the Nova workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Absolute path to a file inside the Nova workspace.",
                    }
                },
                "required": ["path"],
                "additionalProperties": False,
            },
        },
        {
            "name": "write_file",
            "description": "Write text content to a file inside the Nova workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Absolute path to a file inside the Nova workspace.",
                    },
                    "content": {
                        "type": "string",
                        "description": "Full text content to write into the file.",
                    },
                },
                "required": ["path", "content"],
                "additionalProperties": False,
            },
        },
        {
            "name": "list_files",
            "description": "List files and folders inside a workspace directory.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Absolute path to a directory inside the Nova workspace.",
                    }
                },
                "required": ["path"],
                "additionalProperties": False,
            },
        },
    ]