from typing import List, Dict

from .model_router import choose_model
from .openai_service import openai_chat, extract_response_text


def run_model(messages: List[Dict], user_text: str):

    model = choose_model(user_text)

    response = openai_chat(
        model=model,
        messages=messages
    )

    return extract_response_text(response)
