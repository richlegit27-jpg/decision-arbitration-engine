from __future__ import annotations

import json
import os
from typing import Any, Dict

from .config import (
    BASE_RUNTIME_DIR,
    CHAT_STORE_FILE,
    MEMORY_STORE_FILE,
    RUNTIME_BACKUPS_DIR,
    RUNTIME_LOGS_DIR,
    RUNTIME_MEMORY_DIR,
    RUNTIME_TASKS_DIR,
    RUNTIME_UPLOADS_DIR,
    TASKS_STORE_FILE,
    WORKSPACE_STATE_FILE,
)


DEFAULT_CHAT_STORE: Dict[str, Any] = {
    "chats": {}
}

DEFAULT_MEMORY_STORE = []

DEFAULT_TASKS_STORE = []

DEFAULT_WORKSPACE_STATE: Dict[str, Any] = {
    "active_project": "Nova",
    "current_subsystem": "",
    "current_task": "",
    "current_blocker": "",
    "next_step": "",
    "files_in_play": [],
    "recent_tasks": [],
    "last_user_intent": "",
    "last_mode": "",
}


def _safe_write_json(path: str, data: Any) -> None:
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


def _safe_read_json(path: str) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def ensure_runtime_directories() -> None:
    os.makedirs(BASE_RUNTIME_DIR, exist_ok=True)
    os.makedirs(RUNTIME_UPLOADS_DIR, exist_ok=True)
    os.makedirs(RUNTIME_MEMORY_DIR, exist_ok=True)
    os.makedirs(RUNTIME_TASKS_DIR, exist_ok=True)
    os.makedirs(RUNTIME_LOGS_DIR, exist_ok=True)
    os.makedirs(RUNTIME_BACKUPS_DIR, exist_ok=True)


def ensure_chat_store() -> None:
    if not os.path.exists(CHAT_STORE_FILE):
        _safe_write_json(CHAT_STORE_FILE, DEFAULT_CHAT_STORE)
        return

    data = _safe_read_json(CHAT_STORE_FILE)
    if not isinstance(data, dict) or "chats" not in data:
        _safe_write_json(CHAT_STORE_FILE, DEFAULT_CHAT_STORE)


def ensure_memory_store() -> None:
    if not os.path.exists(MEMORY_STORE_FILE):
        _safe_write_json(MEMORY_STORE_FILE, DEFAULT_MEMORY_STORE)
        return

    data = _safe_read_json(MEMORY_STORE_FILE)
    if not isinstance(data, list):
        _safe_write_json(MEMORY_STORE_FILE, DEFAULT_MEMORY_STORE)


def ensure_tasks_store() -> None:
    if not os.path.exists(TASKS_STORE_FILE):
        _safe_write_json(TASKS_STORE_FILE, DEFAULT_TASKS_STORE)
        return

    data = _safe_read_json(TASKS_STORE_FILE)
    if not isinstance(data, list):
        _safe_write_json(TASKS_STORE_FILE, DEFAULT_TASKS_STORE)


def ensure_workspace_state() -> None:
    if not os.path.exists(WORKSPACE_STATE_FILE):
        _safe_write_json(WORKSPACE_STATE_FILE, DEFAULT_WORKSPACE_STATE)
        return

    data = _safe_read_json(WORKSPACE_STATE_FILE)
    if not isinstance(data, dict):
        _safe_write_json(WORKSPACE_STATE_FILE, DEFAULT_WORKSPACE_STATE)


def bootstrap_runtime() -> None:
    ensure_runtime_directories()
    ensure_chat_store()
    ensure_memory_store()
    ensure_tasks_store()
    ensure_workspace_state()