import os
import json
from datetime import datetime
from typing import List, Dict

from .openai_service import openai_chat, extract_response_text
from .config import OPENAI_MODEL

LOG_FILE = r"C:\Users\Owner\nova\runtime\self_improvement_log.json"
PROMPT_FILE = r"C:\Users\Owner\nova\runtime\adaptive_prompt.txt"


def _load_log():

    if not os.path.exists(LOG_FILE):
        return []

    try:
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _save_log(data):

    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

    with open(LOG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def record_interaction(user_text: str, assistant_text: str):

    log = _load_log()

    log.append({
        "time": datetime.utcnow().isoformat(),
        "user": user_text,
        "assistant": assistant_text
    })

    if len(log) > 200:
        log = log[-200:]

    _save_log(log)


ANALYSIS_PROMPT = """
Analyze the following conversation history.

Find weaknesses such as:
- repeated mistakes
- missing context
- poor reasoning
- opportunities to improve instructions

Return a short list of improvements that would help the AI perform better.
"""


def analyze_history():

    log = _load_log()

    if not log:
        return ""

    text = ""

    for item in log[-50:]:
        text += f"User: {item['user']}\nAssistant: {item['assistant']}\n\n"

    response = openai_chat(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": ANALYSIS_PROMPT},
            {"role": "user", "content": text}
        ]
    )

    return extract_response_text(response)


def update_adaptive_prompt():

    improvements = analyze_history()

    if not improvements:
        return ""

    os.makedirs(os.path.dirname(PROMPT_FILE), exist_ok=True)

    with open(PROMPT_FILE, "w", encoding="utf-8") as f:
        f.write(improvements)

    return improvements


def get_adaptive_prompt():

    if not os.path.exists(PROMPT_FILE):
        return ""

    try:
        with open(PROMPT_FILE, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""