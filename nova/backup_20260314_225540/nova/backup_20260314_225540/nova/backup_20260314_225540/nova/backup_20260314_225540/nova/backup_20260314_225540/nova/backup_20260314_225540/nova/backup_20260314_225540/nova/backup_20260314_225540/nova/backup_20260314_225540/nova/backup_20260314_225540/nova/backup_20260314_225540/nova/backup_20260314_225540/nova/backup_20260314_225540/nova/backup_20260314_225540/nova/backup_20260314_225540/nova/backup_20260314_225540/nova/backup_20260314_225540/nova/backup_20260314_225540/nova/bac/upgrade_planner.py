from typing import List

UPGRADE_AREAS = [
    "model reasoning",
    "autonomous coding",
    "workspace intelligence",
    "task planning",
    "long-term memory",
    "agent orchestration"
]


def generate_upgrade_plan():

    steps = []

    for i, area in enumerate(UPGRADE_AREAS):

        steps.append({
            "priority": i + 1,
            "area": area
        })

    return steps