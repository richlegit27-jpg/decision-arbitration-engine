from __future__ import annotations

import importlib
import os
from pathlib import Path
from typing import Dict, List


BASE_DIR = Path(__file__).resolve().parent.parent
BACKEND_DIR = BASE_DIR / "backend"
STATIC_DIR = BASE_DIR / "static"
TEMPLATES_DIR = BASE_DIR / "templates"
RUNTIME_DIR = BASE_DIR / "runtime"

REQUIRED_IMPORTS = [
    "fastapi",
    "uvicorn",
    "jinja2",
]

OPTIONAL_IMPORTS = [
    "multipart",
    "openai",
]

REQUIRED_TEMPLATE_FILES = [
    TEMPLATES_DIR / "index.html",
    TEMPLATES_DIR / "login.html",
]


def _check_imports(names: List[str]) -> List[Dict[str, str]]:
    results: List[Dict[str, str]] = []

    for name in names:
        try:
            importlib.import_module(name)
            results.append(
                {
                    "name": name,
                    "status": "ok",
                    "detail": "imported",
                }
            )
        except Exception as exc:
            results.append(
                {
                    "name": name,
                    "status": "error",
                    "detail": str(exc),
                }
            )

    return results


def _check_paths() -> List[Dict[str, str]]:
    results: List[Dict[str, str]] = []

    required_paths = [
        ("BASE_DIR", BASE_DIR),
        ("BACKEND_DIR", BACKEND_DIR),
        ("STATIC_DIR", STATIC_DIR),
        ("TEMPLATES_DIR", TEMPLATES_DIR),
    ]

    for label, path in required_paths:
        results.append(
            {
                "name": label,
                "status": "ok" if path.exists() else "error",
                "detail": str(path),
            }
        )

    for template_file in REQUIRED_TEMPLATE_FILES:
        results.append(
            {
                "name": template_file.name,
                "status": "ok" if template_file.exists() else "error",
                "detail": str(template_file),
            }
        )

    return results


def _ensure_runtime() -> List[Dict[str, str]]:
    results: List[Dict[str, str]] = []

    runtime_children = [
        RUNTIME_DIR,
        RUNTIME_DIR / "uploads",
        RUNTIME_DIR / "memory",
        RUNTIME_DIR / "tasks",
        RUNTIME_DIR / "logs",
        RUNTIME_DIR / "backups",
    ]

    for path in runtime_children:
        try:
            path.mkdir(parents=True, exist_ok=True)
            results.append(
                {
                    "name": path.name or "runtime",
                    "status": "ok",
                    "detail": str(path),
                }
            )
        except Exception as exc:
            results.append(
                {
                    "name": path.name or "runtime",
                    "status": "error",
                    "detail": str(exc),
                }
            )

    return results


def _check_mode() -> Dict[str, str]:
    openai_key = os.getenv("OPENAI_API_KEY", "").strip()
    openai_required = os.getenv("NOVA_OPENAI_REQUIRED", "0").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }

    has_openai_package = True
    try:
        importlib.import_module("openai")
    except Exception:
        has_openai_package = False

    if openai_key and has_openai_package:
        return {
            "name": "app_mode",
            "status": "ok",
            "detail": "OPENAI mode active (OPENAI_API_KEY present)",
        }

    if openai_required and not openai_key:
        return {
            "name": "app_mode",
            "status": "error",
            "detail": "OPENAI required but OPENAI_API_KEY is missing",
        }

    if openai_required and openai_key and not has_openai_package:
        return {
            "name": "app_mode",
            "status": "error",
            "detail": "OPENAI required but openai package is not installed",
        }

    return {
        "name": "app_mode",
        "status": "ok",
        "detail": "FALLBACK mode active (no OPENAI_API_KEY)",
    }


def run_preflight() -> Dict[str, object]:
    required_imports = _check_imports(REQUIRED_IMPORTS)
    optional_imports = _check_imports(OPTIONAL_IMPORTS)
    path_checks = _check_paths()
    runtime_checks = _ensure_runtime()
    mode_check = _check_mode()

    all_required_ok = all(item["status"] == "ok" for item in required_imports)
    all_paths_ok = all(item["status"] == "ok" for item in path_checks)
    all_runtime_ok = all(item["status"] == "ok" for item in runtime_checks)
    mode_ok = mode_check["status"] == "ok"

    ok = all_required_ok and all_paths_ok and all_runtime_ok and mode_ok

    return {
        "ok": ok,
        "required_imports": required_imports,
        "optional_imports": optional_imports,
        "path_checks": path_checks,
        "runtime_checks": runtime_checks,
        "mode_check": mode_check,
    }


def format_preflight_report(report: Dict[str, object]) -> str:
    lines: List[str] = []

    lines.append("=== NOVA PREFLIGHT ===")
    lines.append(f"OVERALL: {'OK' if report.get('ok') else 'FAIL'}")
    lines.append("")

    for section_name in ("required_imports", "optional_imports", "path_checks", "runtime_checks"):
        lines.append(f"[{section_name}]")
        section = report.get(section_name) or []

        for item in section:
            status = str(item.get("status", "")).upper()
            name = str(item.get("name", ""))
            detail = str(item.get("detail", ""))
            lines.append(f"- {status:<5} {name} :: {detail}")

        lines.append("")

    lines.append("[mode_check]")
    mode_check = report.get("mode_check") or {}
    status = str(mode_check.get("status", "")).upper()
    name = str(mode_check.get("name", ""))
    detail = str(mode_check.get("detail", ""))
    lines.append(f"- {status:<5} {name} :: {detail}")

    return "\n".join(lines).strip()