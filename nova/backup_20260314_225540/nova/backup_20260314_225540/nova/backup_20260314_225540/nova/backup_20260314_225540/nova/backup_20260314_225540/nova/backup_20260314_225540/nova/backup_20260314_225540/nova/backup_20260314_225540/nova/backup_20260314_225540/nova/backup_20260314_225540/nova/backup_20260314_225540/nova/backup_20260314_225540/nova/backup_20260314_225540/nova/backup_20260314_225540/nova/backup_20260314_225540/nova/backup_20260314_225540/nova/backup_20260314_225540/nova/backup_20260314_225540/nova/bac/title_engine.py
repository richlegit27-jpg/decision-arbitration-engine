import re
from typing import Any, Dict, List


GENERIC_TITLES = {
    "",
    "new chat",
    "untitled",
    "chat",
    "conversation",
    "nova chat",
}


STOP_WORDS = {
    "a",
    "an",
    "and",
    "are",
    "at",
    "be",
    "but",
    "by",
    "do",
    "for",
    "from",
    "get",
    "got",
    "had",
    "has",
    "have",
    "help",
    "i",
    "if",
    "in",
    "into",
    "is",
    "it",
    "its",
    "just",
    "make",
    "me",
    "my",
    "need",
    "of",
    "on",
    "or",
    "our",
    "so",
    "that",
    "the",
    "this",
    "to",
    "up",
    "we",
    "with",
    "you",
    "your",
}


ACTION_HINTS = [
    ("fix", ["fix", "debug", "broken", "error", "issue", "bug", "404", "500", "fail", "failed"]),
    ("build", ["build", "create", "implement", "add", "wire", "setup", "set up", "refactor"]),
    ("summarize", ["summarize", "summary", "recap", "tldr", "tl;dr"]),
    ("analyze", ["analyze", "inspect", "review", "check"]),
]


TECH_HINTS = [
    "attachment",
    "attachments",
    "upload",
    "image",
    "vision",
    "memory",
    "summary",
    "context",
    "workspace",
    "title",
    "route",
    "routing",
    "stream",
    "streaming",
    "chat",
    "sidebar",
    "composer",
    "backend",
    "frontend",
    "flask",
    "fastapi",
    "api",
    "python",
    "javascript",
    "css",
    "html",
    "brain",
    "nova",
]


def _normalize_space(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def _is_generic_title(title: str) -> bool:
    normalized = _normalize_space(title).lower()
    return normalized in GENERIC_TITLES


def _extract_file_like_terms(text: str) -> List[str]:
    value = str(text or "")

    patterns = [
        r"[A-Za-z]:\\[^\n\r\t\"']+",
        r"(?:[A-Za-z0-9_\-\.]+\\)+[A-Za-z0-9_\-\.]+\.[A-Za-z0-9_]+",
        r"(?:[A-Za-z0-9_\-\.]+/)+[A-Za-z0-9_\-\.]+\.[A-Za-z0-9_]+",
        r"\b[A-Za-z0-9_\-]+\.(?:py|js|ts|tsx|jsx|html|css|json|md|txt|yml|yaml|xml|sql|ps1|sh|bat|java|cpp|c|go|rs|php|rb)\b",
    ]

    found: List[str] = []
    seen = set()

    for pattern in patterns:
        for match in re.findall(pattern, value):
            candidate = str(match).strip().strip("`")
            key = candidate.lower()
            if not candidate or key in seen:
                continue
            seen.add(key)
            found.append(candidate)

    return found[:6]


def _tokenize(text: str) -> List[str]:
    words = re.findall(r"[a-z0-9_]+", str(text or "").lower())
    return [word for word in words if word and word not in STOP_WORDS]


def _pick_action(text: str) -> str:
    lowered = str(text or "").lower()

    for label, signals in ACTION_HINTS:
        if any(signal in lowered for signal in signals):
            return label

    return ""


def _pick_topic(text: str) -> str:
    tokens = _tokenize(text)

    for hint in TECH_HINTS:
        if hint in tokens:
            return hint

    frequency: Dict[str, int] = {}

    for token in tokens:
        if len(token) < 3:
            continue
        frequency[token] = frequency.get(token, 0) + 1

    if not frequency:
        return ""

    ranked = sorted(frequency.items(), key=lambda item: (-item[1], item[0]))
    return ranked[0][0]


def _title_case_phrase(text: str) -> str:
    words = _normalize_space(text).split(" ")
    output: List[str] = []

    for word in words:
        if not word:
            continue

        if word.lower() in {"api", "ui", "css", "html", "json", "pdf", "ocr"}:
            output.append(word.upper())
        elif word.lower() in {"fastapi", "flask", "nova", "python", "javascript"}:
            output.append(word[0].upper() + word[1:])
        else:
            output.append(word.capitalize())

    return " ".join(output).strip()


def _clean_file_label(path_or_name: str) -> str:
    text = str(path_or_name or "").strip().strip("`")
    if not text:
        return ""

    text = text.replace("\\", "/")
    tail = text.split("/")[-1].strip()

    return tail or text


def generate_chat_title(
    user_message: str,
    assistant_message: str = "",
    attachments: List[Dict[str, Any]] | None = None,
    workspace_state: Dict[str, Any] | None = None,
) -> str:
    source_parts: List[str] = [
        str(user_message or ""),
        str(assistant_message or ""),
    ]

    workspace_state = workspace_state or {}
    attachments = attachments or []

    current_task = str(workspace_state.get("current_task") or "").strip()
    current_subsystem = str(workspace_state.get("current_subsystem") or "").strip()
    files_in_play = workspace_state.get("files_in_play") or []

    if current_task:
        source_parts.append(current_task)

    if current_subsystem:
        source_parts.append(current_subsystem)

    for item in attachments[:3]:
        name = str(item.get("name") or "").strip()
        if name:
            source_parts.append(name)

    combined = "\n".join(part for part in source_parts if part).strip()

    file_terms = _extract_file_like_terms(combined)
    action = _pick_action(combined)
    topic = _pick_topic(combined)

    if file_terms:
        file_label = _clean_file_label(file_terms[0])

        if action:
            return _title_case_phrase(f"{action} {file_label}")[:80]

        return _title_case_phrase(file_label)[:80]

    if files_in_play:
        file_label = _clean_file_label(str(files_in_play[0]))
        if file_label and action:
            return _title_case_phrase(f"{action} {file_label}")[:80]

    if current_subsystem and action:
        return _title_case_phrase(f"{action} {current_subsystem}")[:80]

    if action and topic:
        return _title_case_phrase(f"{action} {topic}")[:80]

    if current_task:
        cleaned = _normalize_space(current_task)
        if cleaned:
            return cleaned[:80]

    compact_user = _normalize_space(user_message)
    if compact_user:
        return compact_user[:80]

    return "New Chat"


def should_update_title(
    current_title: str,
    chat_messages: List[Dict[str, Any]],
    new_title: str,
) -> bool:
    candidate = _normalize_space(new_title)
    existing = _normalize_space(current_title)

    if not candidate:
        return False

    if len(chat_messages or []) < 2 and not _is_generic_title(existing):
        return False

    if _is_generic_title(existing):
        return True

    if existing.lower() == candidate.lower():
        return False

    if len(existing) < 8 and len(candidate) >= 8:
        return True

    existing_generic_words = len([w for w in _tokenize(existing) if w in {"chat", "conversation", "help"}])
    candidate_generic_words = len([w for w in _tokenize(candidate) if w in {"chat", "conversation", "help"}])

    if candidate_generic_words < existing_generic_words:
        return True

    return False