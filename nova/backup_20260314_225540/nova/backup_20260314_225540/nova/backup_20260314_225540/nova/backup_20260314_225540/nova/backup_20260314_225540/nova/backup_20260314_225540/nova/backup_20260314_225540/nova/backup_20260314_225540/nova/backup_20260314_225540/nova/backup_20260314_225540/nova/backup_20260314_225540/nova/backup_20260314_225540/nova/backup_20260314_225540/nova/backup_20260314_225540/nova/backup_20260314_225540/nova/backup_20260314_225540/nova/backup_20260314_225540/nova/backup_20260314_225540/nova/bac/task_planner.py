import re
from typing import Any, Dict, List


GENERIC_STEPS = {
    "look into it",
    "investigate",
    "check it",
    "work on it",
    "continue",
    "next",
    "do that",
    "fix it",
}


def _clean_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _first_meaningful_line(text: str) -> str:
    for raw_line in str(text or "").splitlines():
        line = raw_line.strip().strip("-• \t")
        if line:
            return _clean_text(line)
    return ""


def _extract_bullets(text: str) -> List[str]:
    bullets: List[str] = []

    for raw_line in str(text or "").splitlines():
        line = raw_line.strip()
        if not line:
            continue

        if line.startswith(("-", "*", "•")):
            cleaned = _clean_text(line[1:])
            if cleaned:
                bullets.append(cleaned)

    return bullets


def _extract_sentences(text: str) -> List[str]:
    value = _clean_text(text)
    if not value:
        return []

    parts = re.split(r"(?<=[\.\!\?])\s+", value)
    return [_clean_text(part) for part in parts if _clean_text(part)]


def _pick_goal(user_message: str, workspace_state: Dict[str, Any]) -> str:
    current_task = _clean_text(workspace_state.get("current_task"))
    next_step = _clean_text(workspace_state.get("next_step"))
    subsystem = _clean_text(workspace_state.get("current_subsystem"))

    user_text = _clean_text(user_message)

    if current_task:
        return current_task[:220]

    if user_text:
        return user_text[:220]

    if subsystem:
        return f"Advance {subsystem}"[:220]

    if next_step:
        return next_step[:220]

    return "Advance current work"


def _pick_blocker(
    user_message: str,
    assistant_message: str,
    workspace_state: Dict[str, Any],
) -> str:
    existing_blocker = _clean_text(workspace_state.get("current_blocker"))
    if existing_blocker:
        return existing_blocker[:220]

    text = f"{user_message}\n{assistant_message}".lower()

    blocker_patterns = [
        r"\b404\b",
        r"\b500\b",
        r"not found",
        r"not working",
        r"broken",
        r"exception",
        r"traceback",
        r"error",
        r"failed",
        r"cannot",
        r"can't",
        r"load local resource",
        r"refused to",
        r"missing",
    ]

    hits: List[str] = []

    for pattern in blocker_patterns:
        if re.search(pattern, text):
            hits.append(pattern.replace(r"\b", "").replace("\\", ""))

    if not hits:
        return ""

    return f"Active blocker signals: {', '.join(hits[:4])}"[:220]


def _pick_next_action(
    user_message: str,
    assistant_message: str,
    workspace_state: Dict[str, Any],
) -> str:
    existing_next = _clean_text(workspace_state.get("next_step"))
    if existing_next and existing_next.lower() not in GENERIC_STEPS:
        return existing_next[:220]

    bullets = _extract_bullets(assistant_message)
    if bullets:
        return bullets[0][:220]

    sentences = _extract_sentences(assistant_message)

    priority_prefixes = (
        "next",
        "replace",
        "create",
        "edit",
        "update",
        "wire",
        "add",
        "move",
        "refactor",
        "use",
        "change",
        "implement",
    )

    for sentence in sentences:
        lowered = sentence.lower()
        if lowered.startswith(priority_prefixes):
            return sentence[:220]

    first_line = _first_meaningful_line(assistant_message)
    if first_line:
        return first_line[:220]

    fallback = _clean_text(user_message)
    if fallback:
        return fallback[:220]

    return "Continue current task"


def _pick_current_step(
    assistant_message: str,
    workspace_state: Dict[str, Any],
) -> str:
    recent_tasks = workspace_state.get("recent_tasks") or []
    if recent_tasks:
        first = _clean_text(recent_tasks[0])
        if first:
            return first[:220]

    first_line = _first_meaningful_line(assistant_message)
    if first_line:
        return first_line[:220]

    current_task = _clean_text(workspace_state.get("current_task"))
    if current_task:
        return current_task[:220]

    return "Working current task"


def _pick_files(workspace_state: Dict[str, Any], attachments: List[Dict[str, Any]]) -> List[str]:
    files: List[str] = []
    seen = set()

    for value in workspace_state.get("files_in_play", []) or []:
        text = _clean_text(value)
        if not text:
            continue

        key = text.lower()
        if key in seen:
            continue

        seen.add(key)
        files.append(text)

        if len(files) >= 8:
            return files

    for attachment in attachments or []:
        name = _clean_text(attachment.get("name"))
        if not name:
            continue

        key = name.lower()
        if key in seen:
            continue

        seen.add(key)
        files.append(name)

        if len(files) >= 8:
            return files

    return files


def build_task_plan(
    user_message: str,
    assistant_message: str,
    workspace_state: Dict[str, Any],
    attachments: List[Dict[str, Any]] | None = None,
) -> Dict[str, Any]:
    attachments = attachments or []

    goal = _pick_goal(user_message, workspace_state)
    blocker = _pick_blocker(user_message, assistant_message, workspace_state)
    next_action = _pick_next_action(user_message, assistant_message, workspace_state)
    current_step = _pick_current_step(assistant_message, workspace_state)
    files_in_play = _pick_files(workspace_state, attachments)

    plan = {
        "goal": goal,
        "current_step": current_step,
        "blocker": blocker,
        "next_action": next_action,
        "files_in_play": files_in_play,
        "subsystem": _clean_text(workspace_state.get("current_subsystem")),
        "mode": _clean_text(workspace_state.get("last_mode")),
    }

    return plan


def build_task_plan_context(task_plan: Dict[str, Any]) -> str:
    if not isinstance(task_plan, dict):
        return ""

    lines: List[str] = []
    lines.append("Task plan:")

    goal = _clean_text(task_plan.get("goal"))
    current_step = _clean_text(task_plan.get("current_step"))
    blocker = _clean_text(task_plan.get("blocker"))
    next_action = _clean_text(task_plan.get("next_action"))
    subsystem = _clean_text(task_plan.get("subsystem"))
    mode = _clean_text(task_plan.get("mode"))
    files = task_plan.get("files_in_play") or []

    if goal:
        lines.append(f"- goal: {goal}")

    if current_step:
        lines.append(f"- current_step: {current_step}")

    if blocker:
        lines.append(f"- blocker: {blocker}")

    if next_action:
        lines.append(f"- next_action: {next_action}")

    if subsystem:
        lines.append(f"- subsystem: {subsystem}")

    if mode:
        lines.append(f"- mode: {mode}")

    if files:
        lines.append("- files_in_play:")
        for item in files[:6]:
            lines.append(f"  - {_clean_text(item)}")

    return "\n".join(lines)