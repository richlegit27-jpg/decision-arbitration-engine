import re

from datetime import datetime, timezone


class MemoryContextService:

    def __init__(
        self,
        data_dir,
        session_service,
    ):
        self.data_dir = data_dir
        self.session_service = session_service

    def read_json_file(self, path):
        try:
            if not path.exists():
                return None

            import json

            return json.loads(
                path.read_text(
                    encoding="utf-8"
                )
            )

        except Exception:
            return None

    def compact_text(
        self,
        value,
        *,
        limit=500,
    ):
        text_value = (
            str(value or "")
            .replace("\r", "\n")
            .strip()
        )

        while "\n\n\n" in text_value:
            text_value = text_value.replace(
                "\n\n\n",
                "\n\n",
            )

        if len(text_value) > limit:
            return (
                text_value[:limit]
                .rstrip()
                + "..."
            )

        return text_value

    def memory_text(self, item):
        if isinstance(item, str):
            return item.strip()

        if not isinstance(item, dict):
            return ""

        for key in (
            "text",
            "content",
            "memory",
            "summary",
            "value",
            "note",
            "description",
        ):
            value = item.get(key)

            if isinstance(value, str) and value.strip():
                return value.strip()

        return ""

    def normalize_key(self, value):
        text_value = (
            str(value or "")
            .strip()
            .lower()
        )

        text_value = re.sub(
            r"\s+",
            " ",
            text_value,
        )

        return text_value[:500]

    def memory_text_tokens(self, value):
        text_value = str(value or "").lower()

        return {
            token.strip(".,!?;:()[]{}\"'")
            for token in text_value.split()
            if len(
                token.strip(".,!?;:()[]{}\"'")
            ) >= 3
        }

    def memory_is_relevant_enough(
        self,
        item: dict,
        score: float,
        user_text: str,
    ) -> bool:
        text = self.memory_text(item)

        if not text:
            return False

        query = str(user_text or "").lower()

        if any(
            x in query
            for x in [
                "remember",
                "memory",
                "about me",
                "my project",
            ]
        ):
            return True

        query_tokens = self.memory_text_tokens(user_text)
        memory_tokens = self.memory_text_tokens(text)

        overlap = query_tokens.intersection(
            memory_tokens
        )

        if score >= 1.5:
            return True

        if len(overlap) >= 1:
            return True

        kind = self.memory_kind(item).lower()

        if kind in {
            "project",
            "preference",
            "profile",
            "goal",
        }:
            return True

        return False

    def format_memory_context(
        self,
        memory_items: list[dict],
        user_text: str = "",
        memory_limit: int = 12,
    ) -> str:
        if not isinstance(memory_items, list) or not memory_items:
            return ""

        lines = []

        for item in memory_items[:memory_limit]:
            if not isinstance(item, dict):
                continue

            text = self.compact_text(
                item.get("text"),
                limit=500,
            )

            kind = self.memory_kind(item)

            if not text:
                continue

            if kind:
                lines.append(f"- [{kind}] {text}")
            else:
                lines.append(f"- {text}")

        return "\n".join(lines).strip()

    def memory_kind_weight(self, kind: str) -> float:
        weights = {
            "profile": 5.0,
            "preference": 4.0,
            "user_fact": 4.0,
            "project_focus": 3.5,
            "note": 2.0,
            "memory": 1.0,
        }

        return weights.get(
            str(kind or "").strip().lower(),
            1.0,
        )


    def memory_time_bonus(self, item: dict) -> float:
        if not isinstance(item, dict):
            return 0.0

        timestamp = (
            item.get("created_at")
            or item.get("updated_at")
            or item.get("timestamp")
            or ""
        )

        if not timestamp:
            return 0.0

        try:
            parsed = datetime.fromisoformat(
                str(timestamp).replace(
                    "Z",
                    "+00:00",
                )
            )

            if parsed.tzinfo is None:
                parsed = parsed.replace(
                    tzinfo=timezone.utc
                )

            age_days = (
                datetime.now(timezone.utc)
                - parsed
            ).days

            if age_days <= 1:
                return 5.0

            if age_days <= 7:
                return 2.0

        except Exception:
            pass

        return 0.0


    def rank_memory_items(
        self,
        memories,
        user_text="",
        limit=12,
        priority_terms=None,
        is_execution_chat=False,
        casual_query=False,
        operational_query=False,
        has_real_state=False,
    ):
        memories = memories or []
        priority_terms = priority_terms or []

        text_lc = str(user_text or "").lower().strip()

        identity_query = any(
            phrase in text_lc
            for phrase in (
                "what is nova",
                "what's nova",
                "what is the nova project",
                "tell me about nova",
                "what is my name",
                "what's my name",
                "who am i",
                "who am i?",
                "tell me my name",
                "do you know my name",
                "what do you remember about me",
                "what do you know about me",
            )
        )

        ranked = []

        for index, memory in enumerate(memories):

            content = self.memory_text(memory)

            if not content:
                continue

            category = ""
            kind = ""

            if isinstance(memory, dict):
                category = str(
                    memory.get("category")
                    or memory.get("type")
                    or memory.get("kind")
                    or ""
                ).lower()

                kind = str(
                    memory.get("kind")
                    or memory.get("type")
                    or memory.get("category")
                    or ""
                ).lower()

            content_lc = content.lower()

            blocked_runtime_memory_patterns = [
                "big butts",
                "cannot lie",
                "joke memory",
                "meme memory",
                "temporary joke",
            ]

            if any(
                pattern in content_lc
                for pattern in blocked_runtime_memory_patterns
            ):
                continue

            raw_weight = 1

            if isinstance(memory, dict):
                raw_weight = memory.get(
                    "weight",
                    1,
                )

            try:
                score = float(raw_weight)

            except Exception:
                score = 1.0

            for word in text_lc.split():
                if len(word) >= 4 and word in content_lc:
                    score += 2.0

            for token in text_lc.split():
                if token.isdigit() and token in content_lc:
                    score += 10.0

            if (
                "profile" in category
                or "identity" in category
                or "preference" in category
            ):
                score += 10.0

            if (
                "name is" in content_lc
                or "user's name" in content_lc
                or "user is" in content_lc
            ):
                score += 18.0

            if (
                "prefers" in content_lc
                or "from now on" in content_lc
                or "always" in content_lc
            ):
                score += 12.0

            if identity_query:

                if any(
                    marker in content_lc
                    for marker in (
                        "my name is",
                        "user's name",
                        "called",
                        "i am ",
                        "i'm ",
                    )
                ):
                    score += 30.0

                if any(
                    marker in content_lc
                    for marker in (
                        "branch",
                        "launch testing",
                        "frontend-polish",
                        "post-frontend",
                        "port ",
                        "localhost",
                        "127.0.0.1",
                        "backend",
                        "frontend",
                        "server",
                        "api",
                        "endpoint",
                        "database",
                        "python",
                        "powershell",
                        "command",
                        "path",
                        "file",
                    )
                ):
                    score -= 15.0

            if (
                "nova" in text_lc
                or "project" in text_lc
                or "backend" in text_lc
                or "server" in text_lc
                or "api" in text_lc
            ):

                if any(
                    marker in content_lc
                    for marker in (
                        "port ",
                        "localhost",
                        "127.0.0.1",
                        "backend",
                        "frontend",
                        "server",
                        "api",
                        "endpoint",
                        "database",
                        "python",
                        "powershell",
                        "command",
                        "path",
                        "file",
                    )
                ):
                    score += 8.0

            if updated_at := (
                memory.get("updated_at")
                if isinstance(memory, dict)
                else None
            ):
                score += 1.0

            for term in priority_terms:
                if term and term in content_lc:
                    score += 20.0

            ranked.append(
                {
                    "score": score,
                    "index": index,
                    "content": content,
                    "memory": memory,
                }
            )

        ranked.sort(
            key=lambda item: (
                item["score"],
                -item["index"],
            ),
            reverse=True,
        )

        top = ranked[: max(1, int(limit or 12))]

        return top

    def is_junk_memory(
        self,
        text_value,
        kind="",
    ):
        raw = str(text_value or "").strip()
        lowered = raw.lower()
        item_kind = str(kind or "").strip().lower()

        if not lowered:
            return True

        junk_markers = (
            "project-aware context for nova:",
            "relevant persistent memory:",
            "session attachment memory:",
        )

        if sum(
            lowered.count(marker)
            for marker in junk_markers
        ) >= 2:
            return True

        stale_project_markers = (
            "remote push is still finishing",
            "expanding project-aware memory",
            "project focus recall cleanup committed",
            "backend intelligence context testing",
        )

        if item_kind in {
            "note",
            "user_fact",
            "project_focus",
        }:
            if any(
                marker in lowered
                for marker in stale_project_markers
            ):
                return True

        if lowered.strip() in {
            "say pong only",
            "user preference/correction: say pong only",
        }:
            return True

        if lowered.count("say pong only") >= 2:
            return True

        if lowered.count("what is my current task") >= 2:
            return True

        return False

    def score_penalty(
        self,
        text_value,
        kind="",
    ):
        lowered = str(text_value or "").strip().lower()
        item_kind = str(kind or "").strip().lower()

        penalty = 0

        if item_kind in {
            "project_focus",
            "user_fact",
            "note",
        }:
            if (
                "current task is" in lowered
                or "blocker:" in lowered
            ):
                penalty += 200

        if "project-aware context for nova:" in lowered:
            penalty += 500

        if "say pong only" in lowered:
            penalty += 1000

        return penalty

    def memory_kind(self, item):
        if not isinstance(item, dict):
            return "memory"

        return (
            str(
                item.get("kind")
                or item.get("type")
                or item.get("category")
                or "memory"
            ).strip()
            or "memory"
        )

    def memory_priority(self, item):
        if not isinstance(item, dict):
            return 0

        value = item.get(
            "priority",
            0,
        )

        try:
            return int(value)

        except Exception:
            return 0

    def extract_memory_items(self, payload):
        if isinstance(payload, list):
            return payload

        if not isinstance(payload, dict):
            return []

        for key in (
            "items",
            "memories",
            "memory",
            "records",
            "data",
        ):
            value = payload.get(key)

            if isinstance(value, list):
                return value

        return []



    def message_text(self, message):
        if isinstance(message, str):
            return message.strip()

        if not isinstance(message, dict):
            return ""

        for key in (
            "text",
            "content",
            "message",
            "body",
        ):
            value = message.get(key)

            if isinstance(value, str) and value.strip():
                return value.strip()

        return ""

    def get_memory_context(
        self,
        user_text,
        *,
        limit=12,
        char_limit=3500,
    ):
        payload = self.read_json_file(
            self.data_dir / "nova_memory.json"
        )

        items = self.extract_memory_items(
            payload
        )

        if not items:
            return []

        query_words = {
            word.strip(
                ".,!?;:()[]{}\"'"
            ).lower()
            for word in str(
                user_text or ""
            ).split()
            if len(
                word.strip(
                    ".,!?;:()[]{}\"'"
                )
            ) >= 4
        }

        scored = []

        for item in items:
            text_value = self.memory_text(item)

            if not text_value:
                continue

            kind = self.memory_kind(item)

            if self.is_junk_memory(
                text_value,
                kind,
            ):
                continue

            score = self.score_memory_item(
                item,
                user_text
            )

            score -= self.score_penalty(
                text_value,
                kind,
            )

            scored.append(
                (
                    score,
                    self.memory_priority(item),
                    text_value,
                    kind,
                )
            )

        scored.sort(
            key=lambda row: (
                row[0],
                row[1],
            ),
            reverse=True,
        )

        lines = []
        seen = set()
        used = 0

        for (
            _score,
            _priority,
            text_value,
            kind,
        ) in scored:

            compact = self.compact_text(
                text_value,
                limit=450,
            )

            key = self.normalize_key(
                compact
            )

            if key in seen:
                continue

            seen.add(key)

            line = (
                f"- [{kind}] {compact}"
            )

            if used + len(line) > char_limit:
                break

            lines.append(line)
            used += len(line)

            if len(lines) >= limit:
                break

        return lines

    def get_recent_session_context(
        self,
        session_id,
        *,
        limit=12,
        char_limit=3500,
    ):
        target_session_id = str(
            session_id or ""
        ).strip()

        if not target_session_id:
            return []

        try:
            session = self.session_service.get_session(
                target_session_id
            )

        except Exception:
            session = None

        if not isinstance(session, dict):
            return []

        messages = session.get(
            "messages"
        ) or []

        if not isinstance(messages, list):
            return []

        lines = []
        used = 0

        for message in messages[-limit:]:
            if not isinstance(message, dict):
                continue

            role = str(
                message.get("role")
                or "message"
            ).strip()

            text_value = self.message_text(
                message
            )

            if not text_value:
                continue

            compact = self.compact_text(
                text_value,
                limit=350,
            )

            line = (
                f"- [{role}] {compact}"
            )

            if used + len(line) > char_limit:
                break

            lines.append(line)
            used += len(line)

        return lines

